require([
    'lib/zepto.min',
    'com/storage',
    'com/host',
    'com/common',
    'com/tools',
    'com/GALocalStorage',
], function (a, storage,host,common,tool) {

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function getValidVersion() {
        var system = common.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3900';
        }
        else if (system == 'ios') {
            latestVersion = '3.8.0';
        }

        return common.compareVersion(latestVersion);
    }
    function init() {
        Daze.setTitle('服务详情');
        ga_storage._trackPageview('carService/smyc/service-detail', "汽车服务-上门保养-服务详情");
        render()
    }

    function render() {
        // 新版本
        if(getValidVersion()){
            console.log('新版本')
            var cityId
            var cityName
            var queryId = tool.getQueryString().cityId
            var queryName = tool.getQueryString().cityName
            queryId ? cityId = queryId : cityId = storage.getCurCity().id
            queryName ? cityName = queryName : cityName = storage.getCurCity().name
            getServiceArea({'cityId':cityId})
            // if (Daze && Daze.geolocation && Daze.geolocation.getCurrentPosition) { // 获取定位城市
            //     Daze.geolocation.getCurrentPosition(function (currentCity) {
            //         console.log(currentCity)
            //         currentCity.name = currentCity.city
            //         if(common.getSystem() == 'android'){
            //             cityId = currentCity.id
            //             cityName = currentCity.name
            //         }
            //         else if(common.getSystem() == 'ios'){
            //             currentCity.id = cityId = tool.getQueryString().cityId
            //             currentCity.city = currentCity.name = cityName = tool.getQueryString().cityName

            //         }
            //         storage.storeInfo('curCity', currentCity);
            //         getServiceArea({'cityId':cityId})
            //     });
            // }
        }
        // 旧版本
        else{
            console.log('旧版本')
            var cityId = storage.getItem('smby_city').id
            var cityName = storage.getItem('smby_city').name
            var notKalad = storage.getItem('smby_city').province
            if(notKalad){
                ajaxData = {
                    "cityId":cityId
                }
            }
            else{
                ajaxData = {
                    "kaladId":cityId
                }
            }
            console.log("ajaxData:"+ajaxData)
            getServiceArea(ajaxData)
        }

        var service_name = $('.js_service-name').text()
        var service_id = $('.js_service-name').data('id')
        var service_price = $('.js_service-price').find('.price-new').text()

        $('.consult').on('click',function(){
            Daze.chat({
                workgroupName: 'qichekefu',
                productInfo: '我正在看' + cityId + '的' + service_name + '，有些问题想要咨询'
            });
        })

        $('.js_received').on('click',function(){
            var $self = $(this)
            // common.login(
                // function(){
                    localStorage.setItem('smby_serveId',service_id)
                    localStorage.setItem('smby_serveName',service_name)
                    localStorage.setItem('smby_servePrice',service_price)
                    Daze.pushWindow('confirm-order.html');
                // }
            // )

        })

        Daze.showMsg({
            type: 'loading',
            visible: true
        });


        function getServiceArea(cityInfo){
            $.ajax({
                type:"get",
                url: host.HOST_URL + "/maintenance/queryServiceArea.htm",
                data:common.convertParams(cityInfo),
                dataType:"json",
                success: function(data){
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if(data.code){
                        Daze.showMsg(data.msg);
                        return
                    }
                    var support_city = ''
                    var data = data.data.list
                    $.each(data,function(i){
                        support_city =  support_city  + data[i].name + '、'
                    })

                    support_city=support_city.substr(0,support_city.length-1);

                    $('.support-area').text(cityName+"目前支持"+support_city)



                },
                error: function(xhr,type){

                }
            });
        }
    }


});
