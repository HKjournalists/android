require([
    'lib/zepto.min',
    'com/storage',
    'com/common',
    'com/host',
    'com/GALocalStorage',
    'lib/underscore'
], function (a, storage, DZ_COM,host) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);


    function init() {
        Daze.setTitle('选择车型');
        ga_storage._trackPageview('carService/smby/car-model', "汽车服务-上门保养-选择车型");
        FastClick.attach(document.body);
        render()
    }

	function render() {
		var car = {}
		var brandTmpl = _.template($('#car-brand').html())
		var modelTmpl = _.template($('#car-model').html())
		var letterTmpl = _.template($('#car-letter').html())
		var $brandLetter
		var carArray = []
		var letterPos = []
		var getCar = function(){
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
			$.ajax({
	            type:"get",
	            url: host.HOST_URL + "/maintenance/queryVehicleType.htm",
                data:DZ_COM.convertParams(),
	            dataType:"json",
	            success: function(data){
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if(data.code){
                        Daze.showMsg(data.msg);
                        return
                    }
                    data = JSON.parse(data.data.list)
	            	carArray = data
	            	car.group = _.groupBy(data, 'initial')
	            	car.brand = _.map(data, function(item){ return item.name });
	            	car.letter = _.uniq(_.pluck(data, 'initial'));

	            	var brandHtml = brandTmpl({carBrand : car.group})
	            	$('.car').html(brandHtml)

	            	var letterHtml = letterTmpl({carLetter : car.letter})
	            	$('.car-letter').html(letterHtml)


	            	var $brandLetter = $('.brand-letter')
	            	$brandLetter.each(function(){
	            		var $self = $(this)
	            		var _top = $self.offset().top
	            		letterPos.push(_top)
	            	})



	            },
	            error: function(xhr,type){

	            }
	        });
		}()






    	$('.car').on('click','.brand-item',function(){
    		$('.car-model-box').addClass('show')
    		$('body').addClass('model-show')
    		var $self = $(this)
    		var _text = $self.find('.brand-name').text()
    		var _model = _.find(carArray, function(item){ return item.name == _text; });
    		var modelHtml = modelTmpl({carModel : _model.ams})
    		$('.car-model').html(modelHtml)
    	})

        $('.car-model').on('click','.name',function(){
            var $self = $(this)
            $self.next().toggleClass('show')
            $self.toggleClass('rotate')

        })
        $('.car-model').on('click','.detail-item',function(){
            var $self = $(this)
            var smby_car_info = {}
            smby_car_info.vehicleId = $self.data('id')
            smby_car_info.name = $self.text()
            smby_car_info.fullname = $self.data('fullname')
            storage.setItem('smby_car_info',smby_car_info)
            Daze.pushWindow('fitting.html');
        })

    	$('.mask').on('click',function(){
    		$('.car-model-box').removeClass('show')
    		$('body').removeClass('model-show')
    	})


    	$('.car-letter').on('click','.letter-item',function(){
            $('body').css('visibility','hidden')
    		var $self = $(this)
    		var _index = $self.index()
            $('.baoyang').scrollTop(letterPos[_index])
            $('body').css('visibility','visible')

    	})
    }


});
