require([
    'lib/zepto.min',
    'com/GALocalStorage',
    'com/storage',
    'com/host',
    'com/common',
    'lib/underscore'
], function (a, b,storage,host,DZ_COM) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        DZ_COM.login(function(){
            DZ_COM.getCurCity(function(){
                init();
            });
        })
    }, false);

    function init() {
        Daze.setTitle('选择服务');
        ga_storage._trackPageview('carService/smby/index', "汽车服务-上门保养-选择服务");
        // FastClick.attach(document.body);
        render()
    }

	function render() {
        var cityTmpl = _.template($('#list-city').html())
        var cityName = storage.getCurCity().name

        $('.js_cur-city').text(cityName)
        $('.pop-cur-city').text(cityName)

        storage.clearItem('smby_city')
        storage.setItem('smby_city',storage.getCurCity())

        $('.pop-list-city').on('click','.city-item',function(e){
            var $self = $(this)
            var id = $self.data('id')
            var name = $self.text()
            var smby_city = {
                "id" : id,
                "name" : name
            }
            $('.pop-list-city').addClass('hide')
            $('.js_cur-city').text(name)
            if($(e.target).hasClass('pop-cur-city')){
                storage.setItem('smby_city',storage.getCurCity())
                return
            }
            storage.setItem('smby_city',smby_city)
        })

        $('.js_cur-city').on('click',function(e){
            $('.pop-list-city').removeClass('hide')
            e.stopPropagation()
        })

        $('.js_pop-close').on('click',function(){
            $('.pop-list-city').addClass('hide')
        })

        $.ajax({
                type:"get",
                url: host.HOST_URL + "/maintenance/queryServiceCity.htm",
                data:DZ_COM.convertParams(),
                dataType:"json",
                success: function(data){
                    data = JSON.parse(data.data.list)
                    var cityHtml = cityTmpl({citylist : data})
                    $('.list-city').html(cityHtml)
                },
                error: function(xhr,type){

                }
            });

		$('.service-list-box').on('click','.service-item',function(e){
            e.preventDefault()
			var _href = $(this).attr('href')
        	Daze.pushWindow(_href);
		})

        // $('#oldLink').on('click',function(){
        //     if(DZ_COM.getSystem() == 'android'){
        //         Daze.pushWindow({
        //             appId:10000001,
        //             url:'http://www.chengniu.com/home/HD0006/hb100.html#inApp'
        //         });
        //     }
        //     else{
        //         Daze.pushWindow({
        //             url:'http://www.chengniu.com/home/HD0006/hb100.html#inApp'
        //         });
        //     }
        // })
    }





});
