require([
    'lib/zepto.min',
    'com/storage',
    'com/common',
    'com/host',
    'com/tools',
    'com/GALocalStorage',
    'lib/underscore'
], function (a, storage,DZ_COM, host,tool) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);


    function init() {
        Daze.setTitle('选择配件');
        ga_storage._trackPageview('carService/smby/fitting', "汽车服务-上门保养-选择配件");
        FastClick.attach(document.body);
        render()
    }

	function render() {
        var isParts = false
        var couponList = [];
        var totalNum = 0;
        var noVoucherTotalNum = 0;
        var cityId = storage.getCurCity().id
        var vehicleId = storage.getItem('smby_car_info').vehicleId
        var vehicleFullName = storage.getItem('smby_car_info').fullname
        var serveName = localStorage.getItem('smby_serveName')
        var serveId = localStorage.getItem('smby_serveId')
        localStorage.removeItem('smby_coupon')




        $('.js_vehicleId').text(vehicleFullName)
        $('.js_serveName').text(serveName)

        var getLocal = function(){
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
                // debugger
            $.ajax({
                type:"get",
                url: host.HOST_URL + "/maintenance/queryFitting.htm",
                data:DZ_COM.convertParams({"cityId":cityId,"vehicleId":vehicleId,"serveId":serveId}),
                // url: "js/datatest/peijian.json",
                dataType:"json",
                success: function(data){
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if(data.code){
                        Daze.showMsg(data.msg);
                        return
                    }
                    var data = data.data.list
                    console.log(data)
                    $('.js_service-price').text('¥'+data.service_price)
                    localStorage.setItem('smby_servicePrice',data.service_price)
                    var parts = data.parts


                    var all_parts = data.applicable_parts
                    if(all_parts.length > 0){
                        isParts = true;
                    }
                    aboutCoupon()


                    if(!all_parts.length){
                        var fittingHtml = '<div class="fitting-info">'
                                        +     '<div class="info-title">'
                                        +        '<h1 class="no-fitting">暂无配件</h1>'
                                        +   '</div>'
                                        +'</div>'
                        $('.js_fitting-content').html(fittingHtml)
                        // $('.js_total-num').text('¥'+data.service_price)
                        total()
                        return
                    }
                    var fittingTmpl = _.template($('#fitting-info').html())
                    _.each(all_parts, function(item){
                        _.each(item,function(subItem){
                            _.each(subItem,function(subsubItem){
                                var all_subsubItem = subsubItem
                                _.each(parts,function(part_item){
                                    _.each(part_item,function(part_subItem){
                                        _.each(part_subItem,function(part_subsubItem){
                                            var isEqual = _.isEqual(part_subsubItem, all_subsubItem)
                                            if(isEqual){
                                                all_subsubItem.default = true
                                            }
                                        })
                                    })
                                })
                            })
                        })
                    });

                    console.log(all_parts)

                    var fittingHtml = fittingTmpl({allparts : all_parts})
                    $('.js_fitting-content').html(fittingHtml)

                    total()






                },
                error: function(xhr,type){

                }
            });
        }()
        function total(){
            totalNum = 0;
            $('.info-title').each(function(){
                if($(this).parent().hasClass('select')){
                    var price = $(this).find('.price').text() != '' ? parseInt($(this).find('.price').text().replace('¥','')) : 0
                    console.log(price)
                    totalNum = totalNum + price
                }
            })
            noVoucherTotalNum = totalNum + parseInt($('.js_service-price').text().replace('¥','')||0)
            totalNum = totalNum + parseInt($('.js_service-price').text().replace('¥','')||0) - parseInt($('.js_voucher-price').text().replace('¥','') || 0)
            if(totalNum < 0 ) {
                totalNum = 0
            }

            $('.js_total-num').text('¥'+totalNum)
        }

        $('.fitting').on('click','.js_item-toggle',function(e){
            var target = e.target
            if($(target).closest('.js_fitting-select').length){
                return
            }
            var $self = $(this)
            var _parent = $self.parent()
            var _height = _parent.find('.info-item').first().height()
            console.log(_height)
            var _len = _parent.find('.info-item').length
            if($self.hasClass('slidedown')){
                $self.removeClass('slidedown')
                _parent.removeClass('item-show')
                _parent.find('.info-content').css('height',0)
                return
            }
            $self.addClass('slidedown')
            _parent.addClass('item-show')
            _parent.find('.info-content').css('height',_height*_len)
            total()
        })

        $('.fitting').on('click','.js_fitting-select',function(e){
            var $self = $(this)
            $self.next().toggleClass('hide')
            $self.parents('.fitting-info').toggleClass('select')
            total()
        })

        $('.fitting').on('click','.info-item',function(e){
            var $self = $(this)
            var selfPrice = $self.find('.price').text()
            var titlePrice = $self.parent().siblings().find('.price')
            $self.addClass('select')
            $self.siblings().removeClass('select')
            titlePrice.text(selfPrice)
            total()
        })

        $('.js_go-order-confirm').on('click',function(){
            var parts = {}
            parts.parts = []
            $('.js_fitting-content').find('.info-item.select').each(function(){
                var $self = $(this)
                var $info = $self.parents('.fitting-info')
                if(!$info.hasClass('select')){
                    return
                }
                var obj = {}
                obj.brand = $self.find('.text').find('.brand').text()
                obj.number = $self.find('.text').data('number')
                obj.price = $self.find('.price').text().replace('¥','')
                parts.parts.push(obj)
            })
            localStorage.setItem('smby_parts_total',$('.js_total-num').text())
            storage.setItem('smby_parts',parts)
            Daze.pushWindow('confirm-order.html');
        })




        /**
         * @method getCoupons
         * @description 获取代金券列表
         */
    function aboutCoupon(){
        $('.js_vouchers').on('click',function(){
            Daze.showSelectWin(couponList, function (coupon) {
                couponChange(coupon);
            });
        })
        $coupon = $('.js_vouchers')

        // todo
        // storage.storeInfo('uid',7);
        function getCoupons() {
            DZ_COM.checkNetwork(null, function () {
                var params = {
                    orderTypeId: 2,
                    uid: storage.getUid(),
                    price: noVoucherTotalNum
                };
                $.ajax({
                    url: host.HOST_URL + '/coupon/getValidList.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(params),
                    success: function (r) {
                        if (r.code == 0) {
                            renderCoupon(r.data.list || []);
                        }
                        else {
                            Daze.showMsg(r.msg);
                        }
                        ga_storage._trackEvent('汽车服务-管家-确认订单', 'coupon/getValidList.htm', '成功');
                    },
                    error: function (r) {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-管家-确认订单', 'coupon/getValidList.htm', '失败');
                    }
                });
            });
        }
        getCoupons()
        function renderCoupon(list) {
            couponChange();
            for (var i = 0; i < list.length; i++) {
                var itemList = list[i].list || [];
                if (list[i].name == 36) {
                    couponList = itemList;
                }
                else if (list[i].name == 'all') {
                    couponList = couponList.concat(itemList);
                }
            }

            console.log(couponList)

            if (couponList.length) {
                for (var j = 0; j < couponList.length; j++) {
                    couponList[j].endTime = couponList[j].endTime.split(' ')[0];
                }

                //默认选中最近到期的代金券
                couponChange(couponList[0]);

                $coupon.removeClass('hidden');
            }
        }

        function couponChange(coupon) {
            if (!tool.isEmpty(coupon)) {
                localStorage.setItem('smby_coupon',coupon.id)
                $coupon.attr({
                    'data-id': coupon.id
                });
                $coupon.find('.name').text(coupon.name);
                $coupon.find('.price').text('¥' + coupon.amount);

                // var money = tool.convertNumber(orderMoney - coupon.amount);
                // money = money > 0 ? money : 0.01;
                console.log(1)
                total();
            }
            else {
                $coupon.attr({
                    'data-id': 0
                });
                $coupon.find('.name').text('请选择代金券');
                $coupon.find('.price').text('');
                total();
            }
        }


    }

        console.log(couponList)
    }





});
