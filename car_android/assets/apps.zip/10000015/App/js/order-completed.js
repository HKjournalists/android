require([
    'lib/zepto.min',
    'com/tools',
    'com/storage',
    'com/common',
    'com/host',
    'com/GALocalStorage',
    'lib/underscore'
], function (a, tool, storage, DZ_COM,host) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);


    function init() {
        Daze.setTitle('支付完成');
        ga_storage._trackPageview('carService/smby/order-completed', "汽车服务-上门保养-支付完成");
        render()
    }

	function render() {
        // if(window.location.hash == "#close"){
        //     Daze.popTo(-99)
        // }
        var orderId = tool.getQueryString().orderId
        $('.look').on('click',function(){
            // window.location.hash = '#close'
            // console.log(location.hash)
            Daze.pushWindow({
                appId:'10000009',
                url:'detail.html?orderId='+orderId
            });
        })
        $('.goback').on('click',function(){
            Daze.popTo(-99)
        })

    }





});
