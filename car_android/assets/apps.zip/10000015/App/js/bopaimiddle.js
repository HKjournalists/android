require([
    'lib/zepto.min',
    'com/GALocalStorage',
    'com/storage',
    'com/host',
    'com/common',
    'lib/underscore'
], function (a, b,storage,host,DZ_COM) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        Daze.setTitle('上门保养-博湃');
        ga_storage._trackPageview('carService/smby/index', "汽车服务-上门保养-博湃");
        render()
    }

	function render() {

        $('#btn').on('click',function(){
            Daze.pushWindow({
                url: 'http://erp.bopai.com/web/tp/preferential/index.aspx?service=c3000019267211&order_source=140-13FFA80FD79B5365&target=web'
            });
        })
        var scrollFn = function(){
            window.onscroll = function () {
                if (document.body.scrollTop + window.innerHeight > document.body.scrollHeight - 20) {
                     document.getElementById('btn').className='btn nobg'
                }
                else{
                    document.getElementById('btn').className='btn'
                }
            }
        }()
    }





});
