require([
    'com/storage',
    'com/common',
    'com/host',
    'com/tools',
    'lib/moment',
    'com/GALocalStorage',
    'lib/underscore'
], function ( storage, DZ_COM,host,tool,moment) {
    localStorage.removeItem('smby_coupon')
    var serviceName = tool.getQueryString().serviceName
    var servicePrice = tool.getQueryString().servicePrice
    var couponList = [];
	var noVoucherTotalNum;
    var $brandLetter
    var carServiceName
    var letterPos = []
    $('.js_service-name').text(serviceName)
    $('.js_package-price').text('¥'+parseFloat(servicePrice).toFixed(2))
    function total(){
        totalNum = (parseFloat($('.js_package-price').text().replace('¥','')||0) - parseFloat($('.js_voucher-price').text().replace('¥','') || 0)).toFixed(2)
        noVoucherTotalNum = parseFloat($('.js_package-price').text().replace('¥','')||0).toFixed(1)
        if(totalNum < 0 ) {
            totalNum = 0
        }
        console.log(noVoucherTotalNum)

        $('.js_total-num').text('¥'+totalNum)
    }

    total()

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        FastClick.attach(document.body);
        init();
    }, false);

    function carRender() {
        var car = {}
        var carArray = []
        var brandTmpl = _.template($('#car-brand').html())
        var modelTmpl = _.template($('#car-model').html())
        var letterTmpl = _.template($('#car-letter').html())
        var getCar = function(){

            if(serviceName == '经济车型小保养套餐'){
                carServiceName = '驾到经济车型'
            }
            else if(serviceName == '高档车型小保养套餐'){
                carServiceName = '驾到高档车型'
            }

            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                type:"get",
                url: host.HOST_URL + "/maintenance/queryModels.htm",
                // url: 'http://192.168.10.210:7080/car_client/maintenance/queryModels.htm',
                data:DZ_COM.convertParams({
                    typeName:carServiceName
                }),
                dataType:"json",
                success: function(data){
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if(data.code){
                        Daze.showMsg(data.msg);
                        return
                    }
                    data = JSON.parse(data.data.result)

                    var brandHtml = brandTmpl({carBrand : data})
                    $('.car').html(brandHtml)





                },
                error: function(xhr,type){

                }
            });
        }()




        $('.car').on('click','.brand-item',function(){
            var $self = $(this)
            var smby_car_info = {}
            smby_car_info.name = $self.data('name')
            storage.setItem('smby_car_info',smby_car_info)
            $('.js_car-model').find('.name').text(smby_car_info.name)
            $('.car-wrap').removeClass('show')
            $('.order-footer').addClass('show')

        })

        $('.car').on('click','.brand-letter',function(){
            var $self = $(this)
            $self.next().toggleClass('show')

        })

        $('.car-model').on('click','.name',function(){
            var $self = $(this)
            $self.next().toggleClass('show')
            $self.toggleClass('rotate')

        })
        $('.car-model').on('click','.detail-item',function(){
            var $self = $(this)
            var smby_car_info = {}
            smby_car_info.vehicleId = $self.data('id')
            smby_car_info.name = $self.text()
            smby_car_info.fullname = $self.data('fullname')
            storage.setItem('smby_car_info',smby_car_info)
            $('.js_car-model').find('.name').text(smby_car_info.fullname)
            $('.car-wrap').removeClass('show')
            $('.order-footer').addClass('show')
        })

        $('.mask').on('click',function(){
            $('.car-model-box').removeClass('show')
            $('body').removeClass('model-show')
        })


        $('.car-letter').on('click','.letter-item',function(){
            $('body').css('visibility','hidden')
            var $self = $(this)
            var _index = $self.index()
            $('.baoyang').scrollTop(letterPos[_index])
            $('body').css('visibility','visible')

        })
    }
    function getValidVersion() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3900';
        }
        else if (system == 'ios') {
            latestVersion = '3.8.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }

    function init() {
        Daze.setTitle('提交订单');
        ga_storage._trackPageview('carService/smby/confirm-order', "汽车服务-上门保养-提交订单");
        // FastClick.attach(document.body);

        carRender()
        render()
    }

	function render() {





        var nowDate = moment()
        var nowHour = nowDate.hour()
        var momentDateArr = []
        var momentTimeArr = []

        for(var _mi = 1; _mi < 8; _mi++ ){
            momentDateArr.push(moment().add(_mi, 'days').format('YYYY-MM-DD'))
        }



        var dateTmpl = _.template($('#service-date').html())
        var dateHtml = dateTmpl({dateList:momentDateArr})
        $('#order-date').html(dateHtml)

        var timeTmpl = _.template($('#service-time').html())
        var timeHtml = timeTmpl({timeList:momentTimeArr})
        $('#order-time').html(timeHtml)



        afterTime(1)

        function afterTime(today){
            if(nowHour >= 17 && today){
                momentTimeArr = ['12:00—13:00','13:00—14:00','14:00—15:00','15:00—16:00','16:00—17:00','17:00—18:00']
                timeHtml = timeTmpl({timeList:momentTimeArr})
                $('#order-time').html(timeHtml)
            }
            else{
                momentTimeArr = ['9:00—10:00','10:00—11:00','11:00—12:00','12:00—13:00','13:00—14:00','14:00—15:00','15:00—16:00','16:00—17:00','17:00—18:00']
                timeHtml = timeTmpl({timeList:momentTimeArr})
                $('#order-time').html(timeHtml)
            }
        }

        $('#order-date').on('change',function(){
            var serviceTime = $(this).val()
            var _firstTime = $(this).find('option').first().val()
            if(serviceTime == _firstTime ) {
                afterTime(1)
            }
            else{
                afterTime(0)
            }
        })


        $('.js_car-model').on('click',function(){
            $('.car-wrap').addClass('show')
            $('.order-footer').removeClass('show')
        })

        if(DZ_COM.getSystem()=='android'){
            //
        }
        function isTel(val){
            return /^(\+86([\s-])?)?1\d{10}$/.test(val);
        }

        if(window.location.hash == '#isConfirm'){
           $('.js_confirm-order').addClass('disabled')
        }
        // 新版本
        var cityId = tool.getQueryString().cityId
        var cityName = tool.getQueryString().cityName

        // $('.js_city-list').find('option').first().text(cityName)
        // getServiceArea({cityId:cityId})


        $.ajax({
            type:"get",
            url: host.HOST_URL + "/user/getUserInfo.htm",
            data:DZ_COM.convertParams({"uid":storage.getUid()}),
            dataType:"json",
            success: function(data){
                if(data.code){
                    Daze.showMsg(data.msg);
                    return
                }
                console.log(data)
                var phone = data.data.userInfo.accounts[0].userName
                $('#order-phone').val(phone)
            },
            error: function(xhr,type){
                Daze.showMsg('请求数据失败');
            }
        });
        // $('.js_total-num').text(total)

        var areaTmpl = _.template($('#area-list').html())

        function getServiceArea(cityInfo){
            $.ajax({
                type:"get",
                url: host.HOST_URL + "/maintenance/queryServiceArea.htm",
                data:DZ_COM.convertParams(cityInfo),
                dataType:"json",
                success: function(data){
                    if(data.code){
                        Daze.showMsg(data.msg);
                        return
                    }
                    console.log(data)
                    var areaHtml = areaTmpl({areaList : data.data.list})
                    console.log(areaHtml)
                    $('.area-list').html(areaHtml)


                },
                error: function(xhr,type){
                    Daze.showMsg('请求数据失败');
                }
            });
        }

        $('.js_confirm-order').on('click',function(){
            var $self = $(this)
            // var optionSelect = $('option').not(function(){ return !this.selected })
            if(!isTel($('#order-phone').val())){
                Daze.showMsg('请填写正确的手机号码格式')
                return false;
            }
            else if($('#order-phone').val() == ''){
                Daze.showMsg('请填写手机')
                return false;
            }
            else if($('.js_car-model').find('.name').text() == '请选择您的车型'){
                Daze.showMsg('请选择车型')
                return false;
            }
            else if($('#order-date').val() == ''){
                Daze.showMsg('请填写时间')
                return false;
            }
            else if($('#order-time').val() == '选择时间'){
                Daze.showMsg('请填写日期')
                return false;
            }
            else if($('.js_city-list').val() == '请选择您要前往的门店'){
                Daze.showMsg('请选择您要前往的门店')
                return false;
            }


            Daze.showMsg({
                type: 'loading',
                visible: true
            });

            $('.js_confirm-order').addClass('disabled')

            $.ajax({
                type:"get",
                url: host.HOST_URL + "/maintenance/createOrder.htm",
                // url: "http://192.168.10.210:7080/car_client/maintenance/createOrder.htm",
                data:DZ_COM.convertParams({
                        "vehicleName":storage.getItem('smby_car_info').name,
                        "commodityId":tool.getQueryString().prodId,
                        "price":noVoucherTotalNum,
                        "uid":storage.getUid(),
                        "cityId":cityId,
                        "couponId":JSON.stringify({
                            benjin:localStorage.getItem('smby_coupon')
                        }),
                        "name":$('#order-name').val(),
                        "address":$('.js_city-list').val(),
                        "phoneNum":$('#order-phone').val(),
                        "serviceTime":$('#order-date').val(),
                        "period":$('#order-time').find("option:selected").text(),
                        "recieptType":$('.invoice').hasClass('select') ? 1 : 0,
                        "recieptTitle":$('.js_invoice-title').find('input').val(),
                        "remark":$('#order-remark').val(),
                        "userId":storage.getUserId()
                    }),
                dataType:"json",
                success: function(data){
                    console.log(data)
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if(data.code){
                        Daze.showMsg(data.msg);

                        $('.js_confirm-order').removeClass('disabled')
                        return
                    }

                        var link = JSON.parse(data.data.list).orderId
                        var price = $('.js_total-num').text().replace('¥','')
                        localStorage.setItem('smby_orderId',link)
                        if(window.location.hash == ''){
                            window.location.hash = '#isConfirm'
                        }
                        Daze.pushWindow('payment.html?orderId='+link+'&price='+price);

                },
                error: function(xhr,type){
                    Daze.showMsg('请求数据失败');
                }
            });
        })




        $('.invoice').on('click',function(){
            $(this).toggleClass('select')
            $(this).next().toggleClass('hide')
        })

        /**
         * @method getCoupons
         * @description 获取代金券列表
         */
    aboutCoupon()
    function aboutCoupon(){
        console.log(1)
        $('.js_vouchers').on('click',function(){
            Daze.showSelectWin(couponList, function (coupon) {
                couponChange(coupon);
            });
        })
        $coupon = $('.js_vouchers')

        // todo
        // storage.storeInfo('uid',7);
        function getCoupons() {
            DZ_COM.checkNetwork(null, function () {
                var params = {
                    orderTypeId: 2,
                    uid: storage.getUid(),
                    price: noVoucherTotalNum
                };
                $.ajax({
                    url: host.HOST_URL + '/coupon/getValidList.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(params),
                    success: function (r) {
                        if (r.code == 0) {
                            renderCoupon(r.data.list || []);
                        }
                        else {
                            Daze.showMsg(r.msg);
                        }
                        ga_storage._trackEvent('汽车服务-管家-确认订单', 'coupon/getValidList.htm', '成功');
                    },
                    error: function (r) {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-管家-确认订单', 'coupon/getValidList.htm', '失败');
                    }
                });
            });
        }
        getCoupons()
        function renderCoupon(list) {
            couponChange();
            for (var i = 0; i < list.length; i++) {
                var itemList = list[i].list || [];
                if (list[i].name == 36) {
                    couponList = itemList;
                }
                else if (list[i].name == 'all') {
                    couponList = couponList.concat(itemList);
                }
            }

            console.log(couponList)

            if (couponList.length) {
                for (var j = 0; j < couponList.length; j++) {
                    couponList[j].endTime = couponList[j].endTime.split(' ')[0];
                }

                //默认选中最近到期的代金券
                couponChange(couponList[0]);

                $coupon.removeClass('hidden');
            }
        }

        function couponChange(coupon) {
            if (!tool.isEmpty(coupon)) {
                localStorage.setItem('smby_coupon',coupon.id)
                $coupon.attr({
                    'data-id': coupon.id
                });
                $coupon.find('.name').text(coupon.name);
                $coupon.find('.price').text('¥' + coupon.amount);

                // var money = tool.convertNumber(orderMoney - coupon.amount);
                // money = money > 0 ? money : 0.01;
                console.log(1)
                total();
            }
            else {
                localStorage.removeItem('smby_coupon')
                $coupon.attr({
                    'data-id': 0
                });
                $coupon.find('.name').text('请选择代金券');
                $coupon.find('.price').text('');
                total();
            }
        }


    }

    }




});
