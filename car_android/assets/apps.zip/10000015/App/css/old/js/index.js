require([
    'lib/zepto.min'
], function (a) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function renderHeader() {
        Daze.setTitle('上门保养');
    }



    function bindEvents() {
        $('#link').click(function(){
            Daze.pushWindow('city.html')
        })
    }

    function init() {
        renderHeader();
        bindEvents();
        // ga_storage._trackPageview('carService/smyc/old', "汽车服务-上门养车-首页");
    }
});
