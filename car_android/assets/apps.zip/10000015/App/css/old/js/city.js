require([
    'lib/zepto.min'
], function (a) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function renderHeader() {
        Daze.setTitle('服务城市');
    }



    function bindEvents() {
        $('#link').click(function(){
            Daze.pushWindow('city.html')
        })
    }

    function init() {
        renderHeader();
        bindEvents();
    }
});
