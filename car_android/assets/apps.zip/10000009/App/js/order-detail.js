require([
    'lib/zepto.min',
    'com/tools',
    'com/storage',
    'com/common',
    'com/host',
    'com/GALocalStorage',
    'lib/underscore'
], function (a, tool, storage, DZ_COM,host) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);


    function init() {
        Daze.setTitle('订单详情');
        ga_storage._trackPageview('carService/smyc/service-detail', "汽车服务-订单详情");
        render()
    }

	function render() {
        // if(DZ_COM.getSystem() == 'ios'){
        //     Daze.showOptionMenu(
        //         {"items":[
        //            {
        //                "title":"返回",
        //                "id":"item1",
        //                "side": 'left'

        //            }
        //       ]},function(){
        //         Daze.popTo(-99)
        //       })
        // }


        var price

        var firstRender = true;

        var orderId = tool.getQueryString().orderId

        var orderTmpl = _.template($('#order-content').html())

        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        (function getOrderInfo(){

            $.ajax({
                type:"get",
                url: host.HOST_URL + '/dealService/getOrderDetail.htm',
                data:DZ_COM.convertParams({"orderId":orderId}),
                dataType:"json",
                success: function(data){
                    if(data.code){
                        Daze.showMsg(data.msg);
                        return
                    }
                    data= data.data.serviceOrderDetail

                    if(firstRender){
                        renderTmpl(data)
                        firstRender = false;
                    }

                    if(data.status == 2){
                        if(data.payStatus){
                            $('.js_orderStatus').text('支付处理中')
                            $('.footer').css('display','none')
                            setTimeout(function(){
                                getOrderInfo()
                            },5000)
                        }
                    }
                    else{
                        function statusTransform (status) {
                            var s;
                            switch (status) {
                                case -1:
                                    s = '已删除';
                                    break;
                                case 1:
                                    s = '无法支付';
                                    break;
                                case 2:
                                    s = '待支付';
                                    break;
                                case 3:
                                    s = '已支付';
                                    break;
                                case 4:
                                    s = '审核信息';
                                    break;
                                case 5:
                                    s = '待审核';
                                    break;
                                case 6:
                                    s = '审核失败';
                                    break;
                                case 7:
                                    s = '审核通过';
                                    break;
                                case 10:
                                    s = '处理中';
                                    break;
                                case 11:
                                    s = '处理失败';
                                    break;
                                case 12:
                                    s = '处理成功';
                                    break;
                                case 13:
                                    s = '待退款';
                                    break;
                                case 14:
                                    s = '已退款';
                                    break;
                                case 15:
                                    s = '确认完成';
                                    break;
                                case 16:
                                    s = '已评价';
                                    break;
                                case 20:
                                    s = '已关闭';
                                    break;
                            }
                            return s;
                        }
                        var statusText = statusTransform(data.status)
                        localStorage.removeItem(orderId+'Status')
                        $('.js_orderStatus').text(statusText)
                        $('.footer').css('display','none')
                    }
                },
                error: function(xhr,type){

                }
            });

            function renderTmpl(data){
                price = parseFloat(data.totalPrice - data.vouchers).toFixed(2)
                orderNum = data.orderNum
                var orderHtml = orderTmpl(data)
                $('#order-confirm').html(orderHtml)
                $('.js_orderId').text(orderNum)
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });

                price>0 ? price : parseFloat(0.01).toFixed(2)
            }

        })();

        $('#order-confirm').on('click','.js_go-order-confirm',function(){
            Daze.pushWindow({
                appId:'10000015',
                url:'payment.html?orderId='+orderId+'&price='+price
            });
            if(DZ_COM.getSystem() == 'android'){
                Daze.popTo(-99)
            }
        })

    }





});
