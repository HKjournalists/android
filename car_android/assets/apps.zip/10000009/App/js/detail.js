require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, host, tool, storage, common) {
    var $wrapOrderDetail = $('#wrapOrderDetail'),
        $btnPay = $('#btnPay'),
        $btnClose = $('#btnClose'),
        $btnConfirm = $('#btnConfirm'),
        $btnComplain = $('#btnComplain'),
        $btnGrade = $('#btnGrade'),
        $wrapRefund = $('#wrapRefund'),
        level = $('#level'),

        $wrapSelect = $('#wrapSelect'),
        $cashAccount = $('#cashAccount'),
        $payOnline = $('#payOnline'),
        $cbOfCashAccount = $('#cbOfCashAccount'),
        $cbOfPayOnline = $('#cbOfPayOnline'),

        $wrapBtns = $('#wrapBtns');

    var orderMoney = 0,//订单金额
        cashBalance = 0;//现金账户余额

    var refundInfo = null;
    var orderId = tool.getQueryString().orderId
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {

        if(window.location.hash == "#isJump"){
            setTimeout(function(){
                Daze.popTo(-99)
            },10)
            return false;
        }
        renderHeader();
        var queryObj = tool.getQueryString(),
            orderId = queryObj.orderId;
        if (orderId) {
            common.login(function () {
                getOrderDetail(orderId);
                bindEvents(orderId);
            });
        }
        else {
            Daze.showMsg('订单不存在');
            setTimeout(function () {
                Daze.popWindow();
            }, 2100);
            return false;
        }
        ga_storage._trackPageview('carService/order/detail', "汽车服务-订单-详情");
    }

    function bindEvents(orderId) {
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });
        $btnConfirm.click(function () {
            common.confirm({
                title: '确认完成',
                content: '确认完成后，您的款项将由橙牛担保账户转入服务商账户。',
                yesFn: function () {
                    confirmHandler(orderId);
                    ga_storage._trackEvent('汽车服务-订单-详情', '点击', '确认完成');
                }
            });
        });
        $btnGrade.click(function () {
            common.confirm({
                title: '请打星级评价',
                yesFn: function () {
                    gradeHandler(orderId);
                    ga_storage._trackEvent('汽车服务-订单-详情', '点击', '评价');
                }
            });
            var level = $('<div class="level" id="level">');
            level.raty({
                score: 5,
                width: 'auto',
                path: 'images'
            });
            $('#winConfirm').find('.content').append(level, $('<div>').text($('#supplier').text()));
        });
        $btnPay.click(function () {
            storage.storeInfo('curSupplier', {
                name: $('#supplier').text(),
                tel: $('#tel').text()
            });

            var useBalance = $cbOfCashAccount.is(':checked'),
                payOnline = $cbOfPayOnline.is(':checked');
            var serviceName = $('#serviceName').text();
            Daze.pay({
                orderId: orderId,
                useBalance: useBalance,
                payOnline: payOnline
            }, function (resp) {
                if (resp.isSuccess) {
                    $.ajax({
                        url:host.HOST_URL + '/formOrder/updatePayStatus.htm',
                        type: 'post',
                        data: common.convertParams({
                            orderId:orderId
                        }),
                        success:function(data){
                            if(payOnline){
                                Daze.showMsg({
                                    type: 'loading',
                                    visible: true,
                                    text : '订单处理中'
                                });
                                setTimeout(function () {
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: true,
                                        text : ''
                                    });
                                    paySuccess();
                                }, 5000);
                            }else{
                                paySuccess();
                            }
                            function paySuccess(){
                                Daze.showMsg('支付成功');
                                setTimeout(function() {
                                    location.reload();
                                }, 2000);
                            }
                        }
                    })

                }
                else {
                    Daze.showMsg('支付失败');
                }
            });
            ga_storage._trackEvent('汽车服务-订单-详情', '点击', '确认前往付款');
        });
        $btnClose.click(function () {
            common.confirm({
                content: '确定取消订单？',
                yesFn: function () {
                    common.login(function () {
                        closeOrder(orderId);
                        ga_storage._trackEvent('汽车服务-订单-详情', '点击', '取消订单');
                    });
                }
            });
        });
        $('.box-confirm .btn-cancel').click(function () {
            $(this).parents('.box-confirm').addClass('hidden');
        });

        //cash balance
        $cbOfCashAccount.change(function () {
            var isChecked = $(this).is(':checked');
            if (orderMoney > cashBalance) {
                if (isChecked) {
                    $cashAccount.find('.pay-balance').removeClass('hidden');
                    $payOnline.find('.pay-balance .balance').text(tool.convertNumber(orderMoney - cashBalance));
                }
                else {
                    $cashAccount.find('.pay-balance').addClass('hidden');
                    $payOnline.find('.pay-balance .balance').text(orderMoney);
                }
            }
            else {
                if (isChecked) {
                    $cbOfCashAccount.prop('disabled', true);
                    $cashAccount.find('.pay-balance').removeClass('hidden');
                    $cbOfPayOnline.prop('checked', false);
                    $cbOfPayOnline.prop('disabled', false);
                    $payOnline.find('.pay-balance').addClass('hidden');
                }
            }
            renderBtn();
        });

        //pay online
        $cbOfPayOnline.change(function () {
            var isChecked = $(this).is(':checked');
            if (orderMoney <= cashBalance) {
                if (isChecked) {
                    $cbOfCashAccount.prop('checked', false);
                    $cbOfCashAccount.prop('disabled', false);
                    $cashAccount.find('.pay-balance').addClass('hidden');
                    $cbOfPayOnline.prop('disabled', true);
                    $payOnline.find('.pay-balance').removeClass('hidden');
                }
            }
            renderBtn();
        });

        //添加/修改收款账号
        $wrapRefund.on('click', '#btnFill,#btnMod', function () {
            document.addEventListener('updateRefundInfoEvent', updateRefundInfo);
            require(['com/modules/refund'], function (module_refund) {
                module_refund.init(refundInfo);
            });
        });

        //投诉
        $btnComplain.click(function () {
            ga_storage._trackEvent('汽车服务-订单-详情', '点击', '投诉');
        });

        // 活动
        var $shareBtn = $('#shareBtn');
        $shareBtn.click(function () {
            getReward();
        });
    }

    function renderHeader() {
        Daze.setTitle('订单详情');
    }

    function renderBtn() {
        var $btnPay = $('#btnPay'),
            useBalance = $('#cbOfCashAccount').is(':checked'),
            payOnline = $('#cbOfPayOnline').is(':checked');

        //按钮可用情况1：订单金额大于现金余额，使用在线支付或者在线支付和现金余额共用
        //按钮可用情况2：订单金额小于等于现金余额，使用在线支付或者现金余额
        var available = false;
        if (orderMoney > cashBalance) {
            if (payOnline) {
                available = true;
            }
        }
        else {
            if (useBalance || payOnline) {
                available = true;
            }
        }
        if (available) {
            $btnPay.removeAttr('disabled');
        }
        else {
            $btnPay.attr('disabled', true);
        }
    }

    function getOrderDetail(orderId) {
        var domId = 'infoOrder';
        common.checkNetwork(domId, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/dealService/getOrderDetail.htm',
                type: 'post',
                data: common.convertParams({
                    orderId: orderId
                }),
                success: function (r) {
                    if (r.code == 0) {
                        if(r.data.serviceOrderDetail.subType == 0){
                            window.location.href = "smby_order.html?orderId="+orderId
                            window.location.hash = "#isJump"
                            return
                        }
                        var data = convertData(r.data.serviceOrderDetail);




                        renderOrderDetail(data);
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-订单-详情', 'dealService/getOrderDetail.htm', '成功');
                },
                error: function (r) {
                    common.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-订单-详情', 'dealService/getOrderDetail.htm', '失败');
                }
            });
        });
    }

    function renderOrderDetail(data) {
        if (data.couponPrice) {
            orderMoney = data.price - data.couponPrice > 0 ? tool.convertNumber(data.price - data.couponPrice) : 0.01;
        }
        else {
            orderMoney = data.price;
        }
        data.orderMoney = orderMoney;
        $wrapOrderDetail.html(template('detailTmpl', data));
        // render by status
        if (data.statusText == '待支付') {
            if(data.payStatus){
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
                $('#wrapOrderDetail').find('.status').text('支付处理中')
                setTimeout(function(){
                    getOrderDetail(orderId)
                },5000)
                return
            }
            $btnPay.removeClass('hidden');
            $btnClose.removeClass('hidden');

            //render cash balance
            var globalData = storage.getGlobalData();
            if (globalData.uid) {
                getBalance();
            }
            else {
                payInit();
            }
        }
        else if (data.statusText == '已支付') {
            $wrapBtns.removeClass('hidden');
            $btnConfirm.removeClass('hidden');
            $btnComplain.removeClass('hidden');
        }
        else if (data.statusText == '待评价') {
            $wrapBtns.removeClass('hidden');
            $btnGrade.removeClass('hidden');
        }
        else if (data.statusText == '待退款') {
            var arr = [1, 2, 6, 7];
            if ($.inArray(data.payType, arr) == -1) {
                getAccount();
            }
        }

        // 8.1活动
        var today = common.getToday();
        if (data.content == '油卡充值' && data.status >= 2 && today == '2015-08-01') {
            judgeHandler();
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function getAccount() {
        $.ajax({
            url: host.HOST_URL + '/refund/getRefundAccount.htm',
            type: 'post',
            data: common.convertParams({
                uid: storage.getGlobalData().uid
            }),
            success: function (r) {
                if (r.code == 0) {
                    refundInfo = r.data.refund;
                    renderRefund();
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
                ga_storage._trackEvent('汽车服务-订单-详情', 'refund/getRefundAccount.htm', '成功');
            },
            error: function (r) {
                common.renderNetworkTip(null, 1);
                ga_storage._trackEvent('汽车服务-订单-详情', 'refund/getRefundAccount.htm', '失败');
            }
        });
    }

    function renderRefund() {
        $wrapRefund.html(template('refundTmpl', {
            data: refundInfo
        }));
    }

    function updateRefundInfo() {
        document.removeEventListener('updateRefundInfoEvent', updateRefundInfo);
        getAccount();
    }

    function convertData(data) {
        var s = common.convertStatus(data.status).status,
            c = common.convertStatus(data.status).color,
            bc = common.convertStatus(data.status).backgroundColor,
            tel = data.serviceProviderPhone,
            telArr = [];
        data.statusText = s;
        data.color = c;
        data.backgroundColor = bc;

        if (data.serviceName == '油卡充值' || data.serviceName == '罚单代缴') {
            switch (data.statusText) {
                case '已支付':
                    data.statusText = '处理中';
                    break;
                case '待评价':
                    data.statusText = '处理成功';
                    break;
            }
        }

        // convert coupon name
        data.couponName = JSON.parse(data.couponName).benjin;

        // convert card type
        var cardType = '';
        switch (data.cardType) {
            case 0:
                cardType = '中国石化';
                break;
            case 1:
                cardType = '中国石油';
                break;
        }
        data.cardType = cardType;

        if (tel.indexOf('/') >= 0) {
            telArr = tel.split('/');
        }
        else {
            telArr[0] = tel;
        }
        data.telArr = telArr;

        return data;
    }

    function getBalance() {
        common.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getUserInfo.htm',
                type: 'post',
                data: common.convertParams({
                    uid: storage.getGlobalData().uid
                }),
                success: function (r) {
                    if (r.code == 0) {
                        // 支付部分初始化
                        cashBalance = r.data.userInfo.cashBalance || 0;
                        payInit();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        cashBalance = 0;
                        payInit();
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-订单-详情', 'user/getUserInfo.htm', '成功');
                },
                error: function (r) {
                    common.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-订单-详情', 'user/getUserInfo.htm', '失败');
                }
            });
        });
    }

    function payInit() {
        $cashAccount.find('.balance').text(cashBalance);
        if (cashBalance) {
            $cashAccount.removeClass('hidden');
        }
        if (orderMoney > cashBalance) {
            $cbOfPayOnline.attr({'checked': true, 'disabled': true});
            $payOnline.find('.pay-balance .balance').text(orderMoney);
            $payOnline.find('.pay-balance').removeClass('hidden');
        }
        else {
            $cbOfCashAccount.attr({'checked': true, 'disabled': true});
            $cashAccount.find('.pay-balance .balance').text(orderMoney);
            $payOnline.find('.pay-balance .balance').text(orderMoney);
            $cashAccount.find('.pay-balance').removeClass('hidden');
        }
        $wrapSelect.removeClass('hidden');
    }

    /**
     * @method confirmHandler
     * @description 确认订单操作
     */
    function confirmHandler(orderId) {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var params = {
            orderId: orderId,
            serviceName: $('#serviceName').text(),
            providerPhone: $('#tel').text(),
            providerName: $('#supplier').text()
        };
        common.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/dealService/confirm.htm',
                type: 'post',
                data: common.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('确认成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2100);
                        }
                        else {
                            Daze.showMsg('确认失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-订单-详情', 'dealService/confirm.htm', '成功');
                },
                error: function (r) {
                    common.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-订单-详情', 'dealService/confirm.htm', '失败');
                }
            });
        });
    }

    /**
     * @method gradeHandler
     * @description 评价操作
     */
    function gradeHandler(orderId) {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });

        var score = $('#level').find('input').val();
        common.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/dealService/evaluate.htm',
                type: 'post',
                data: common.convertParams({
                    orderId: orderId,
                    evaluationScore: score
                }),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {

                            Daze.showMsg('评价成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2100);
                        }
                        else {

                            Daze.showMsg('评价失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-订单-详情', 'dealService/evaluate.htm', '成功');
                },
                error: function (r) {
                    common.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-订单-详情', 'dealService/evaluate.htm', '失败');
                }
            });
        });
    }

    /**
     * @method closeOrder
     * @description 关闭订单
     * @param orderId
     */
    function closeOrder(orderId) {
        common.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var pid = storage.getGlobalData().pid;
            $.ajax({
                url: host.HOST_URL + '/formOrder/closeOrder.htm',
                type: 'post',
                data: common.convertParams({
                    orderId: orderId,
                    pId: pid
                }),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('取消成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2100);
                        }
                        else {
                            Daze.showMsg('取消失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-订单-详情', 'formOrder/closeOrder.htm', '成功');
                },
                error: function (r) {
                    common.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-订单-详情', 'formOrder/closeOrder.htm', '失败');
                }
            });
        });
    }

    function judgeHandler() { // 判断活动HD0001是否已领取过
        $.ajax({
            url: host.HOST_URL + '/user/hasQualified.htm',
            type: 'post',
            data: common.convertParams({
                uid: storage.getUid(),
                type: 37
            }),
            success: function (r) {
                if (r.code == 0) {
                    var canShare = r.data && r.data.canShare;
                    if (canShare) {
                        $('#entranceOfHD0001').removeClass('hidden');
                    }
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-HD0001', 'user/hasQualified.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-HD0001', 'user/hasQualified.htm', '失败');
            }
        });
    }

    function getReward() { // 领取奖励
        $.ajax({
            url: host.HOST_URL + '/user/dismantle.htm',
            type: 'post',
            data: common.convertParams({
                uid: storage.getUid(),
                type: 37
            }),
            success: function (r) {
                if (r.code == 0) {
                    Daze.share({
                        from: 37,
                        type: 37,
                        to: '2'
                    }, function (result) {
                        if (result.isSuccess || result.status == '成功') {
                            var $entranceOfHD0001 = $('#entranceOfHD0001'),
                                $result = $('#result'),
                                amount = r.data.amount;
                            if (amount) {
                                $result.find('img').attr('src', 'images/c_' + amount + 'y.png');
                                $entranceOfHD0001.addClass('hidden');
                                $result.removeClass('hidden');
                            }
                            else {
                                Daze.showMsg(r.msg);
                            }
                        }
                    });
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-8.1特惠日', 'user/dismantle.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-8.1特惠日', 'user/dismantle.htm', '失败');
            }
        });
    }
});
