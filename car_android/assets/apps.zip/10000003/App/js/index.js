require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM) {
    var serviceTypes = null;

    var $info = $('#info'),
        $wrapSelectCoupon = $('#wrapSelectCoupon'),
        $listCoupon = $('#listCoupon'),
        $btnOrder = $('#btnOrder');

    var curServiceType = null,
        couponList = [];
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        DZ_COM.login(function(){
            DZ_COM.getCurCity(function(){
                init();
            });
        })
    }, false);


    var queryObj = tool.getQueryString(),
        serviceId = queryObj.serviceId,
        serviceName = queryObj.serviceName;

    if(serviceId && serviceName){
        storage.storeInfo('curService',{
            serviceId:serviceId,
            id:serviceId,
            name:serviceName
        })
    }

    function init() {
        renderHeader();
        Daze.showMsg({
            type: 'loading',
            visible: true
        });

        renderService();
        getServiceTypes();
        bindEvents();
        ga_storage._trackPageview('carService/self_supporting/index', "汽车服务-自营服务-首页");
    }

    function bindEvents() {
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });

        $info.on('click', '#infoServiceTypes li', function () {
            var isCur = $(this).hasClass('cur');
            if (!isCur) {
                $wrapSelectCoupon.addClass('hidden');
                $(this).addClass('cur').siblings().removeClass('cur');

                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
                var serviceTypeId = $(this).data('id');
                curServiceType = getSecondInfoByServiceType(serviceTypeId);
                renderSecondInfo(curServiceType);
                ga_storage._trackEvent('汽车服务-自营服务-首页', '点击', $(this).data('name'));
            }
            else {
                return false;
            }
        });

        $info.on('click', '#btnPay', function () {
            DZ_COM.login(function () {
                getCouponList();
                ga_storage._trackEvent('汽车服务-自营服务-首页', '点击', '立即缴费');
            });
        }).on('click','#payMent',function(){
            Daze.pushWindow('payMent.html');
        });

        $listCoupon.click(function () {
            Daze.showSelectWin(couponList, function (coupon) {
                if (tool.isEmpty(coupon)) {
                    couponReset();
                }
                else {
                    couponSelected(coupon);
                }
            });
        });

        $btnOrder.click(function () {
            addOrder();
            ga_storage._trackEvent('汽车服务-自营服务-首页', '点击', '提交订单');
        });

        $info.on('click', '#consult', function () {
            var city = storage.getCurCity().name,
                service = storage.getCurService().name;

            DZ_COM.login(function () {
                $.ajax({
                    url: host.HOST_URL + '/fw/callStatistics.htm',
                    type: 'post',
                    data: DZ_COM.convertParams({
                        optype : 6,
                        userId: storage.getUserId(),
                        uid: storage.getUid(),
                        serviceId: storage.getCurServiceOfBMW().id,
                        cityId: storage.getCurCity().id
                    }),
                    success: function () {
                        Daze.chat({
                            workgroupName: 'qichekefu',
                            productInfo: '我正在看' + city + '的' + service + '，有些问题想要咨询'
                        });
                        ga_storage._trackEvent('汽车服务-自营服务-首页', '点击', '在线客服');
                    },
                    error: function () {
                        ga_storage._trackEvent('汽车服务-自营服务-首页', '点击', '在线客服');
                    }
                });
            });
        });
    }

    function renderHeader() {
        var name = storage.getCurService().name;
        Daze.setTitle(name);
    }

    function renderService() {
        var curService = storage.getCurService();
        $info.append(template('serviceTmpl', curService));
    }

    function getServiceTypes() {
        var domId = 'info';
        DZ_COM.checkNetwork(domId, function () {
            $.ajax({
                url: host.HOST_URL + '/dealService/getServiceItems.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    serviceId: storage.getCurService().id,
                    cityId: storage.getCurCity().id
                }),
                success: function (r) {
                    if (r.code == 0) {
                        serviceTypes = r.data && r.data.list.length ? convertData(r.data.list) : [];
                        renderServiceTypes();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-自营服务-首页', 'dealService/getServiceItems.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-自营服务-首页', 'dealService/getServiceItems.htm', '失败');
                }
            });
        });
    }

    function convertData(list) {
        for (var j = 0; j < list.length; j++) {
            if (list[j].stuff) {
                list[j].stuff = list[j].stuff.split('\n');
            }
        }
        return list;
    }

    function getSecondInfoByServiceType(id) {
        for (var i = 0; i < serviceTypes.length; i++) {
            if (serviceTypes[i].id == id) {
                return serviceTypes[i];
            }
        }
        return {};
    }

    function renderServiceTypes() {
        var curService = storage.getCurService(),
            deadLine = curService.serviceTime;
        $info.append(
            template('serviceTypesTmpl', {
                serviceId: curService.id,
                deadLine: deadLine,
                serviceTypes: serviceTypes
            })
        );
        if(curService.id == 2){
            require(['animate'],function(){
                (function(){
                    $.fn.textSlider = function(settings){
                        settings = $.extend({
                            speed : "normal",
                            line : 2,
                            timer : 5000
                        }, settings);
                        return this.each(function() {
                            $.fn.textSlider.scllor( $(this), settings );
                        });
                    };
                    $.fn.textSlider.scllor = function($this, settings){
                        var dl = $( "dl:eq(0)", $this );
                        var _html = '';
                        for(var s = 0; s< settings.line *2 ; s++){
                           _html +='<dd>'+recordRound()+'</dd>';
                        }
                        dl.append(_html);
                        $this.removeClass('hidden');
                        var timerID;
                        var dd = dl.children();
                        var liHight=dd.height();
                        var upHeight=0-settings.line*liHight;
                        var scrollUp=function(){
                            dl.animate({marginTop:upHeight},settings.speed,function(){
                                var html = '';
                                for(i=0;i<settings.line;i++){
                                  dl.find('dd:eq(0)').remove();
                                  html +='<dd>'+recordRound()+'</dd>';
                                }
                                dl.append(html);
                                dl.css({marginTop:0});
                            });
                        };
                        var scrollDown=function(){
                            dl.css({marginTop:upHeight});
                            for(i=0;i<settings.line;i++){
                                dl.find("dd:last").prependTo(dl);
                            }
                            dl.animate({marginTop:0},settings.speed);
                        };
                        var autoPlay=function(){
                            timerID = window.setInterval(scrollUp,settings.timer);
                        };
                        var autoStop = function(){
                            window.clearInterval(timerID);
                        };
                        autoPlay();
                    };
                })();
                function recordRound(){
                    var arr = [130,131,132,133,134,135,136,137,138,139,150,151,152,153,155,156,157,158,159,170,176,177,178,180,181,182,183,184,185,186,187,188,189],
                        arr2 = [-2,-1,0],
                        roundNumber = function(start, end){
                            var total = end - start + 1;
                            return Math.floor(Math.random() * total + start);
                        },
                        getDateStr = function(num) {
                            var dd = new Date();
                            dd.setDate(dd.getDate()+num);
                            var y = dd.getFullYear();
                            var m = dd.getMonth()+1;
                            var d = dd.getDate();
                            if(m<10){
                                m = '0'+m;
                            }
                            if(d<10){
                                d = '0'+d;
                            }
                            return y+"/"+m+"/"+d;
                        },
                        str = '';
                        str += getDateStr(arr2[roundNumber(0,arr2.length-1)]);
                        str += '  车主：';
                        str += arr[roundNumber(0,arr.length-1)];
                        str += '****';
                        str += roundNumber(0,9);
                        str += roundNumber(0,9);
                        str += roundNumber(0,9);
                        str += roundNumber(0,9);
                        str += ' 已成功办理年检';
                    return str;
                }
                $('#scrollText').textSlider();
            });
        }

        curServiceType = serviceTypes[0];
        if (curServiceType) {
            renderSecondInfo(curServiceType);
        }
        else {
            Daze.showMsg({
                type: 'loading',
                visible: false
            });
        }
    }

    function renderSecondInfo(info) {
        var $infoSecond = $('#infoSecond'),
            $wrapTotal = $('#wrapTotal');
        if ($infoSecond) {
            $infoSecond.remove();
        }
        if ($wrapTotal) {
            $wrapTotal.remove();
        }
        $info.append(template('secondTmpl', info));

        Daze.showMsg({
            type: 'loading',
            visible: false
        });

        //render consult
        if (Daze.chat) {
            $('#consult').removeClass('hidden');
        }
        $('#btnTel').removeClass('hidden');
    }

    function getCouponList() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var params = {
                orderTypeId: 2,
                uid: storage.getUid(),
                price: curServiceType.price
            };
            $.ajax({
                url: host.HOST_URL + '/coupon/getValidList.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    var list = [];
                    if (r) {
                        if (r.code == 0) {
                            list = r.data.list;
                        }
                        else {
                            Daze.showMsg(r.msg);
                        }
                    }
                    renderSelectCoupon(list);
                    ga_storage._trackEvent('汽车服务-自营服务-首页', 'coupon/getValidList.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-自营服务-首页', 'coupon/getValidList.htm', '失败');
                }
            });
        });
    }

    function renderSelectCoupon(list) {
        var curService = storage.getCurService(),
            serviceName = curService.name,
            serviceId = curService.serviceId;

        $wrapSelectCoupon.find('.service .value').text(serviceName);
        $wrapSelectCoupon.find('.service-type .key').text(curServiceType.props);
        $wrapSelectCoupon.find('.price').text(curServiceType.price);
        couponReset();

        for (var i = 0; i < list.length; i++) {
            var itemList = list[i].list || [];
            if (list[i].name == serviceId) {
                couponList = itemList;
            }
            else if (list[i].name == 'all') {
                couponList = couponList.concat(itemList);
            }
        }
        if (couponList.length) {
            for (var j = 0; j < couponList.length; j++) {
                couponList[j].endTime = couponList[j].endTime.split(' ')[0];
            }
            $listCoupon.show();

            //排序
            couponList.sort(function (a, b) {
                return new Date(a.endTime) - new Date(b.endTime);
            });

            //默认选中最近到期的代金券
            couponSelected(couponList[0]);
        }
        else {
            couponList = [];
            $listCoupon.hide();
        }
        $wrapSelectCoupon.removeClass('hidden');

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function couponReset() {
        $listCoupon.attr({
            'data-id': 0
        }).text('请选择代金券');
        $wrapSelectCoupon.find('.coupon-price').text('');
        $wrapSelectCoupon.find('.order-money span').text(curServiceType.price);
    }

    function couponSelected(coupon) {
        $listCoupon.attr({
            'data-id': coupon.id
        }).text(coupon.name + '(' + coupon.endTime + ')');
        $wrapSelectCoupon.find('.coupon-price').text(' -' + coupon.amount);
        var money = curServiceType.price - coupon.amount > 0 ? curServiceType.price - coupon.amount : 0.01;
        $wrapSelectCoupon.find('.order-money span').text(tool.convertNumber(money));
    }

    function addOrder() {
        var curItem = $('#infoServiceTypes li.cur'),
            price = curItem.data('price'),
            desc = curItem.data('name');
        var params = {
            pId: storage.getPid(),
            uid: storage.getUid(),
            userId: storage.getUserId(),
            cityId: storage.getCurCity().id,
            serviceId: storage.getCurService().id,
            serviceProviderId: 39,
            price: price,
            descr: desc
        };

        var couponId = $listCoupon.data('id');
        if (couponId) {
            params.couponId = {
                benjin: couponId
            };
        }

        //验证
        var result = DZ_COM.validateParams(params, function () {
            addOrder();
        });
        if (result.eligible) {
            DZ_COM.checkNetwork(null, function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
                $.ajax({
                    url: host.HOST_URL + '/dealService/add.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(params),
                    success: function (r) {
                        if (r.code == 0) {
                            Daze.showMsg({
                                type: 'loading',
                                visible: false
                            });
                            $wrapSelectCoupon.addClass('hidden');
                            Daze.pushWindow({
                                appId:'10000009',
                                url:'detail.html?orderId='+r.data.orderId
                            });
                        }
                        else {
                            Daze.showMsg(r.msg);
                            return false;
                        }
                        ga_storage._trackEvent('汽车服务-自营服务-首页', 'dealService/add.htm', '成功');
                    },
                    error: function (r) {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-自营服务-首页', 'dealService/add.htm', '失败');
                    }
                });
            });
        }
        else {
            Daze.showMsg(result.msg);
        }
    }
});
