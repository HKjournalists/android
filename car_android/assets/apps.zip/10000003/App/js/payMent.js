require([
    'com/GALocalStorage'
], function () {

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        ga_storage._trackPageview('carService/self_supporting/payMent', "汽车服务-自营服务-赔付详情");
    }

    function renderHeader() {
        Daze.setTitle('赔付');
    }
});
