require(['lib/zepto.min', 'com/storage'], function (a, storage) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('self supporting completed init');
        bindEvents();
        renderHeader();
        renderServiceName();
    }

    function bindEvents() {
        var toIndex = $('#toIndex'),
            myOrder = $('#myOrder');

        toIndex.click(function () {
            Daze.popTo(-2);
        });
        myOrder.click(function () {
            Daze.pushWindow({
                appId: '10000009',
                url: 'detail.html?orderId=' + orderId
            });
        });
    }

    function renderHeader() {
        Daze.setTitle('支付成功');
    }

    function renderServiceName() {
        var serviceName = storage.getCurService().name;
        $('.serviceName').text(serviceName);
    }
});