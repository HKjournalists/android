require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM) {
    var $agentServices = $('#agentServices'),
        cityId = storage.getGlobalData().curCity.id;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        getServices();
        bindEvents();
        ga_storage._trackPageview('carService/index/agent-services', "汽车服务-首页-橙牛代办");
    }

    function bindEvents() {
        /* 车务代办 */
        $agentServices.on('touchstart', 'li', function () {
            var isValid = $(this).data('isvalid');
            if (isValid) {
                var $img = $(this).find('img');
                var src = $img.attr('src'),
                    imgName = src.split('.')[0];
                $img.attr('src', imgName + '-active.png');

                setTimeout(function () {
                    $img.attr('src', src);
                }, 400);
            }
        });

        $agentServices.on('click', 'li', function () {
            validateService($(this));
            ga_storage._trackEvent('汽车服务-首页-橙牛代办', '点击', $(this).find('.tit').text());
        });
    }

    function renderHeader() {
        Daze.setTitle('橙牛代办');
    }

    /**
     * @method getServices
     * @description 获取服务列表
     */
    function getServices() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var domId = 'services';
        DZ_COM.checkNetwork(domId, function () {
            $.ajax({
                url: host.HOST_URL + '/dealService/getCityService.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    cityId: cityId
                }),
                success: function (r) {
                    if (r.code == 0) {
                        storage.storeInfo('serviceList', r.data.list);
                        renderServices(r.data.list);
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-首页-橙牛代办', 'dealService/getCityService.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-首页-橙牛代办', 'dealService/getCityService.htm', '失败');
                }
            });
        });
    }

    /**
     * @method renderServices
     * @description 渲染服务列表
     * @param serviceList
     */
    function renderServices(serviceList) {
        var agentServiceNames = [],
            agentServices = [];
        var hasInspection = false;
        for (var i = 0; i < serviceList.length; i++) {
            if (!serviceList[i].selfOperate || serviceList[i].serviceId == 1 || serviceList[i].serviceId == 22) {
                continue;
            }

            if (serviceList[i].serviceId == 19 || serviceList[i].serviceId == 7) {
                if(cityId == 92){
                    continue;
                }
            }

            // service sort
            var serviceId = Number(serviceList[i].serviceId),
                mainArr = [8, 9, 10, 23, 24, 26, 27 , 35 , 36 , 37 ,38 , 60];

            if ($.inArray(serviceId, mainArr) == -1) {
                agentServiceNames.push(serviceList[i].name);
                agentServices.push(serviceList[i]);
            }

            //convert tag
            var tag = '';
            switch (serviceList[i].flag) {
                case 1:
                    tag = 'new';
                    break;
                case 2:
                    tag = 'discount';
                    break;
                case 3:
                    tag = 'free';
                    break;
                case 4:
                    tag = 'hot';
                    break;
            }
            serviceList[i].tag = tag;

            //是否有年检服务
            if (serviceId == 2) {
                hasInspection = true;
            }
        }

        if (agentServices.length % 2 == 1) {
            agentServices.push({});
        }

        var remainder = agentServices.length % 3,
            sub = remainder ? 3 - remainder : 0;
        if (sub) {
            for (var j = 0; j < sub; j++) {
                agentServices.push({});
            }
        }

        $agentServices.append(
            template('agentServiceTmpl', {
                agentServices: agentServices
            })
        );

        Daze.showMsg({
            type: 'loading',
            visible: false
        });

        //reset layout
        resetLayout();
    }

    function resetLayout() {
        var items = $agentServices.find('li');
        var windowWidth = $(window).width(),
            width = windowWidth / 3,
            height = width * 4 / 3;
        for (var i = 0; i < items.length; i++) {
            var $item = $(items[i]);
            $item.width(width);
            $item.height(height);
        }
    }

    function validateService($this) {
        var serviceId = $this.data('id'),
            isValid = $this.data('isvalid');

        if (!serviceId) {
            return false;
        }
        else if (!isValid) {
            Daze.showMsg('服务不可用');
            return false;
        }
        else {
            DZ_COM.setCurService(serviceId);
            goService(serviceId);
        }
    }

    function goService(serviceId) {
        var globalData = storage.getGlobalData(),
            curService = globalData.curService,
            appId = curService.comId,
            selfOperate = curService.selfOperate;

        if ($.inArray(serviceId, [8, 9, 10, 15, 17, 20, 23]) >= 0) {
            switch (serviceId) {
                case 8://罚单代缴
                    Daze.pushWindow({
                        appId: appId,
                        url: 'index.html'
                    });
                    break;
                case 9://道路救援
                    Daze.pushWindow({
                        appId: appId,
                        url: 'index.html'
                    });
                    break;
                case 10://油卡充值
                    Daze.pushWindow({
                        appId: appId,
                        url: 'index.html'
                    });
                    break;
                case 15:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://gm.akmob.cn/index.aspx?qdh=3'
                    });
                    //Daze.pushWindow('http://gm.akmob.cn/index.aspx?qdh=3');
                    break;
                case 17:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://auto.news18a.com/m/price/chengniuchaweizhang/'
                    });
                    //Daze.pushWindow('http://auto.news18a.com/m/price/chengniuchaweizhang/');
                    break;
                case 20:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://s.mapbar.com/p0LoAr4'
                    });
                    //Daze.pushWindow('http://s.mapbar.com/p0LoAr4');
                    break;
                case 23:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://h5.edaijia.cn/app/index.html?#!cLocation'
                    });
                    //Daze.pushWindow('http://h5.edaijia.cn/app/index.html?#!cLocation');
                    break;
            }
        }
        else {
            if (selfOperate) {//self supporting
                storage.storeInfo('curSupplier', {
                    id: curService.serviceProviderId
                });
                Daze.pushWindow({
                    appId: '10000003',
                    url: 'index.html'
                });
            }
            else {
                Daze.pushWindow({
                    appId: appId,
                    url: 'index.html'
                });
            }
        }
    }
});
