require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/md5.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/city-list',
    'com/modules/city',
    'com/modules/banner',
    'com/GALocalStorage'
], function(a, b, md5, host, tool, storage, DZ_COM, list, module_city, module_banner) {

    var $mainServices = $('#mainServices'),
        isloading = false,
        mainArr = [2 , 8 , 9 , 10 , 24 , 26 , 34 , 35 , 36 , 37 , 38 , 52 , 60],
        servicedArr = [8, 9, 10, 15, 17, 20, 24, 26, 27, 34, 35, 36, 37, 38 ,52, 60, 995, 996, 997, 998, 999];
        if (Daze.system && Daze.system.carWash) {
            mainArr.push(27);
        }
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        bindEvents();
        Daze.network.getType(function (typeObj) {
            var curCity = storage.getCurCity();
            var indexServiceList = storage.getGlobalData().indexServiceList;
            if (!typeObj.isOnline) {
                if(!tool.isEmpty(curCity)&&!tool.isEmpty(indexServiceList)&&curCity.id==indexServiceList.cityId&&indexServiceList.data&&indexServiceList.data.length){
                    renderContent();
                    errNetWorkTip();
                }else{
                    renderErrorType('errorNetwork');
                }
                return false;
            }else {
                init();
            }
        });
    }, false);

    function init() {
        document.addEventListener('loginEvent', function(e) {
            var data = e.data;
            storage.storeInfo('userId', data[0]);
            storage.storeInfo('uid', data[1]);
            storage.storeInfo('pid', data[2]);
        });

        document.addEventListener('logoutEvent', function() {
            storage.removeInfo('pid');
            storage.removeInfo('uid');
        });

        document.addEventListener('cityChangeEvent', function(e) {
            var data = e.data || {},
                curCity = storage.getCurCity(),
                _system = DZ_COM.getSystem();
            if(isloading && _system == 'ios'){
                return;
            }
            isloading = true;
            if (!tool.isEmpty(data) && data.cityId && data.cityName && data.province) {
                storage.storeInfo('curCity', {
                    id: data.cityId,
                    name: data.cityName,
                    province: data.province
                });
                location.reload();
            }else{
                if (_system == 'ios') {
                    location.reload();
                }
            }
        });

        document.addEventListener('selectEvent', function() {
            renderContent();
        });

        renderHeader();
        module_city.getCurrentCity(function(isSuccess) {
            if (isSuccess) {
                renderContent();
            } else {
                renderLeftMenu('menuCity');
            }
        });
        ga_storage._trackPageview('carService/index', "汽车服务-首页");
    }

    /**
     * @method convertParamsRpb
     * @description 人品宝获取code参数拼装
     */
    function convertParamsRpb(params,type) {
        type = type || 'rpb';
        var appkey = 0 , appsecret = 0;
        if(type == 'rpb'){
            appkey = '7537bc25b1';
            appsecret = '21bb0cf7e95cfe22';
        }
        if(type == 'tqyx'){
            appkey = 'f095b85215d2c46bc64cbfd1b5af539a';
            appsecret = 'fe46feaf754c96ce7c99d3e2c13010d0';
        }

        if (tool.isEmpty(params)) {
            params = {};
        }
        // get date , format:yyyy-MM-dd HH:mm:ss
        var date = new Date(),
            year = date.getFullYear(),
            month = date.getMonth() + 1,
            day = date.getDate(),
            hour = date.getHours(),
            minute = date.getMinutes(),
            second = date.getSeconds(),
            timestamp = year + '-' + month + '-' + day + ' ' + hour + ':' + minute + ':' + second;
        params.appkey = appkey;
        params.timestamp = timestamp;
        params.v = '1.0';
        // params array
        var arr = [];
        for (var i in params) {
            if (params[i] === null || params[i] === undefined) {
                params[i] = '';
            }
            arr.push(i + params[i]);
        }
        // sort by word
        arr.sort();
        // params string
        var str = '';
        for (var j in arr) {
            str += arr[j];
        }
        // params string splice secret
        str = appsecret + str + appsecret;
        params.sign = md5(str).toUpperCase();
        return params;
    }

    function bindEvents() {
        $mainServices.on('click', '.item', function() {
            validateService($(this));
            ga_storage._trackEvent('汽车服务-首页', '点击', $(this).find('i').text());
        }).on('click','#reLoader',function(){
            location.reload();
        }).on('click','#changeCity',function(){
            module_city.init();
        }).on('click','#checkNetwork',function(){
            Daze.pushWindow('netWork.html');
        });
    }

    function errNetWorkTip(){
        $('.errNetWorkTip').remove();
        $mainServices.prepend(
            $('<div class="errNetWorkTip">').html('网络请求失败，请检查您的网络设置')
        );
        $('.errNetWorkTip').click(function(){
            Daze.pushWindow('netWork.html');
            $(this).remove();
        });
    }

    function renderHeader() {
        Daze.setTitle('汽车服务');
    }

    // 渲染页面内容
    function renderContent() {
        renderLeftMenu('menuCity');
        $mainServices.html('');
        renderServiceCacha();
    }

    /**
     * @method renderServiceCacha
     * @description 读取本地存储的服务列表
     */

    function renderServiceCacha(){
        var curCity = storage.getCurCity();
        var indexServiceList = storage.getGlobalData().indexServiceList;
        if(!tool.isEmpty(curCity)&&!tool.isEmpty(indexServiceList)&&curCity.id==indexServiceList.cityId&&indexServiceList.data&&indexServiceList.data.length){
            renderServices(indexServiceList.data);
            getServices(0);
        }else{
            getServices(1);
        }
        module_banner.init(['serviceHead', 'serviceBodyLeft', 'serviceBodyRight']);
    }

    function renderErrorType(type){
        $mainServices.html(
            template('errorTips', {
                type : type
            })
        );
    }

    function renderLeftMenu(menuId) {
        var curCity = storage.getCurCity();
        var title = '';
        if (menuId == 'menuCity') {
            if (curCity && curCity.name) {
                title = curCity.name + ' ν';
            } else {
                module_city.init();
                renderErrorType('errorGps');
            }
        } else if (menuId == 'menuClose') {
            title = '关闭';
        }

        Daze.showOptionMenu({
            items: [{
                title: title,
                id: menuId,
                side: 'left'
            }]
        }, function() {
            if (menuId == 'menuCity') {
                renderLeftMenu('menuClose');
                module_city.init();
            } else if (menuId == 'menuClose') {
                renderLeftMenu('menuCity');
                module_city.closeWin();
            }
        });
    }

    function errXHR(){
        var curCity = storage.getCurCity();
        var indexServiceList = storage.getGlobalData().indexServiceList;
        if(!tool.isEmpty(curCity)&&!tool.isEmpty(indexServiceList)&&curCity.id==indexServiceList.cityId&&indexServiceList.data&&indexServiceList.data.length){
            //renderServices(indexServiceList.data);
            errNetWorkTip();
        }else{
            renderErrorType('errorXHR');
        }
    }

    function resultFn(data){
        var curCity = storage.getCurCity();
        var indexServiceList = storage.getGlobalData().indexServiceList;
        var _data = indexServiceList.data,
            result = contrast(data,_data);
            if(result.remove.length || result.add.length){
                if(result.remove.length){
                    $mainServices.find('.item').each(function(){
                        var _id = $(this).data('id');
                        if($.inArray(_id, result.remove) >= 0){
                            $(this).remove();
                        }
                    });
                }
                if(result.add.length){
                    var _ar = [];
                    for(var w = 0 ; w < result.add.length ; w++){
                        _ar.push(data[result.add[w].index]);
                    }
                    $mainServices.prepend(
                        template('mainServiceTmpl', {
                            mainServices: _ar
                        })
                    );
                }
            }
        storage.storeInfo('indexServiceList', {
            cityId : curCity.id,
            data : data
        });
        isloading = false;
    }

    function contrast(dataNew,dataOld){
        var _arrCache = [],//缓存的serviceId
            _arrNew = [],
            result = {
                'add' : [],
                'remove' : []
            },
            t = 0,
            s = 0,
            i = 0;
        for(; t < dataNew.length ; t++){
            _arrNew.push(dataNew[t].serviceId);
        }
        for(; s < dataOld.length ; s++){
            var chache_serviceId = dataOld[s].serviceId;
                if($.inArray(chache_serviceId, _arrNew) < 0){
                    result.remove.push(chache_serviceId);
                }
            _arrCache.push(dataOld[s].serviceId);
        }
        for(; i < dataNew.length ; i++){
            var _serviceId = dataNew[i].serviceId;
            for(var d = 0; d < dataOld.length ; d++){
                var _chache_serviceId = dataOld[d].serviceId;
                if(_chache_serviceId == _serviceId){
                    var _a = dataNew[i],
                        _b = dataOld[d];
                    for(var m in _a){
                        if(m in _b){
                            if(m == 'isValid'){
                                if(_a[m] != _b[m]){
                                    if(!_a[m]){
                                        result.remove.push(_serviceId);
                                    }else{
                                        if($.inArray(_serviceId, mainArr) >= 0){
                                            var o = {};
                                                o.index = i;
                                                o.serviceId = _serviceId;
                                            result.add.push(o);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if($.inArray(_serviceId, _arrCache) < 0 && $.inArray(_serviceId, mainArr) >= 0){
                var o = {};
                    o.index = i;
                    o.serviceId = _serviceId;
                result.add.push(o);
            }
        }
        return result;
    }

    /**
     * @method getServices
     * @description 获取服务列表
     */
    function getServices(show) {
        console.log(show);
        if(show == 1){
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
        }
        DZ_COM.checkNetwork(null, function() {
            var curCity = storage.getCurCity();
            var cityId = curCity.id;
            $.ajax({
                url: host.HOST_URL + '/dealService/getCityService.htm',
                type: 'post',
                timeout : 8000,
                data: DZ_COM.convertParams({
                    cityId: cityId
                }),
                success: function(r) {
                    if(show == '1'){
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                    }
                    if (r.code == '0') {
                        if(r.data.list.length == 0){
                            renderErrorType('errorCity');
                        }else{
                            if(show == 1){
                                renderServices(r.data.list);
                                storage.storeInfo('serviceList', r.data.list);
                                storage.storeInfo('indexServiceList', {
                                    cityId : cityId,
                                    data : r.data.list
                                });
                            }else{
                                resultFn(r.data.list);
                            }
                        }
                    } else {
                        if(show == '1'){
                            Daze.showMsg({
                                type: 'loading',
                                visible: false
                            });
                        }
                        errXHR();
                    }
                    ga_storage._trackEvent('汽车服务-首页', 'dealService/getCityService.htm', '成功');
                },
                error: function(r) {
                    if(show == '1'){
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                    }
                    errXHR();
                    ga_storage._trackEvent('汽车服务-首页', 'dealService/getCityService.htm', '失败');
                }
            });
        });
    }

    /**
     * @method renderServices
     * @description 渲染服务列表
     * @param serviceList
     */
    function renderServices(serviceList) {
        var mainServices = [],
            curCity = storage.getCurCity(),
            agentServices = [];
        var hasInspection = false;
        for (var i = 0; i < serviceList.length; i++) {
            // service sort
            var serviceId = Number(serviceList[i].serviceId);
            var isValid = serviceList[i].isValid;
            if ($.inArray(serviceId, mainArr) >= 0 && isValid) {
                mainServices.push(serviceList[i]);
            } else {
                if (serviceId == 2) {
                    //mainServices.push(serviceList[i]);
                } else {
                    agentServices.push(serviceList[i]);
                }
            }

            //convert tag
            var tag = '';
            switch (serviceList[i].flag) {
                case 1:
                    tag = 'new';
                    break;
                case 2:
                    tag = 'discount';
                    break;
                case 3:
                    tag = 'free';
                    break;
                case 4:
                    tag = 'hot';
                    break;
            }
            switch (serviceList[i].serviceId) {
                case 8: //罚款代缴
                    tag = 'freeb';
                    break;
                case 10: //加油卡
                    tag = 'zhe';
                    break;
                case 27: //上门洗车
                    tag = 'xg';
                    break;
            }
            serviceList[i].tag = tag;
            if(serviceList[i].serviceId == 8 || serviceList[i].serviceId == 10 || serviceList[i].serviceId == 27){
                serviceList[i].flag = 5;
            }

            //是否有年检服务
            /*if (serviceId == 2) {
                hasInspection = true;
            }*/
        }

        //橙牛代办
        mainServices.splice(mainServices.length-1, 0, {
            serviceId: 999,
            name: '车务代办',
            info: '车管业务，橙牛为您保驾护航',
            icon: 'images/icon-agent.png',
            isValid: 1
        });

        //滴滴
        mainServices.splice(3, 0, {
            serviceId: 998,
            name: '加入专车快速通道',
            info: '月入轻松过万',
            icon: 'images/icon-didi.png',
            isValid: 1
        });

        /*if(curCity.id == 92){
            //淘汽云修
            mainServices.splice(5, 0, {
                serviceId: 997,
                name: '淘汽云修轮胎',
                info: '2条轮胎+1次保养+保险=788元',
                icon: 'images/icon-didi.png',
                isValid: 1
            });
        }*/

        if (agentServices.length % 2 == 1) {
            agentServices.push({});
        }

        var remainder = agentServices.length % 3,
            sub = remainder ? 3 - remainder : 0;
        if (sub) {
            for (var j = 0; j < sub; j++) {
                agentServices.push({});
            }
        }

        $mainServices.append(
            template('mainServiceTmpl', {
                mainServices: mainServices
            })
        );
        isloading = false;
    }

    function validateService($this) {
        var serviceId = $this.data('id'),
            isValid = $this.data('isvalid');

        if (!serviceId) {
            return false;
        } else if (!isValid) {
            Daze.showMsg('服务不可用');
            return false;
        } else {
            DZ_COM.setCurService(serviceId);
            goService(serviceId);
        }
    }

    function goService(serviceId) {
        var curService = storage.getCurService(),
            appId = curService.comId,
            selfOperate = curService.selfOperate;

        if ($.inArray(serviceId, servicedArr) >= 0) {
            switch (serviceId) {
                case 8: //罚单代缴
                case 9: //道路救援
                case 10: //油卡充值
                    Daze.pushWindow({
                        appId: appId,
                        url: 'index.html'
                    });
                    break;
                case 15:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://gm.akmob.cn/index.aspx?qdh=3'
                    });
                    // Daze.pushWindow('http://gm.akmob.cn/index.aspx?qdh=3');
                    break;
                case 17:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://auto.news18a.com/m/price/chengniuchaweizhang/'
                    });
                    // Daze.pushWindow('http://auto.news18a.com/m/price/chengniuchaweizhang/');
                    break;
                case 20:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://s.mapbar.com/p0LoAr4'
                    });
                    // Daze.pushWindow('http://s.mapbar.com/p0LoAr4');
                    break;
                case 24: // 车险超市
                    (function() {
                        goToUrl();
                        function goToUrl() {
                            var url = 'http://mobile.wxb.com.cn/mobile/?channelNo=B10002&channelSite=s01';
                            if (DZ_COM.getSystem() == 'ios') {
                                url += '&target=web';
                            }
                            Daze.pushWindow(url);
                        }
                    })();
                    break;
                case 26:
                    Daze.rescue();
                    break;
                case 27: // 上门洗车
                    Daze.system.carWash();
                    break;
                case 34:
                    DZ_COM.login(function() {
                        DZ_COM.checkNetwork(null, function() {
                            Daze.showMsg({
                                type: 'loading',
                                visible: true
                            });
                            $.ajax({
                                url: 'http://open.chengniu.com/auth/auth_code',
                                data: convertParamsRpb({
                                    uid: storage.getUid()
                                }),
                                success: function(r) {
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: false
                                    });
                                    if (r.code == '0') {
                                        if (r.data && r.data.code) {
                                            Daze.pushWindow('https://www.u51.com/51rp/h5/thirdpart/index.html?channel=chengniu&code=' + r.data.code);
                                        }
                                    } else {
                                        Daze.showMsg(r.msg);
                                        return false;
                                    }
                                    ga_storage._trackEvent('汽车服务-人品宝用户授权', '/auth/auth_code', '成功');
                                },
                                error: function() {
                                    errNetWorkTip();
                                    ga_storage._trackEvent('汽车服务-人品宝用户授权', '/auth/auth_code', '失败');
                                }
                            });
                        });
                    });
                    break;
                case 35: //在线车险
                    Daze.pushWindow({
                        appId: '10000018',
                        url: 'index.html'
                    });
                    break;
                case 36: //卡拉丁上门养车
                    DZ_COM.login(function() {
                        Daze.pushWindow({
                            appId: '10000019',
                            url: 'index.html'
                        });
                    });
                    break;
                case 52: //博湃上门养车
                    DZ_COM.login(function() {
                        Daze.pushWindow({
                            appId: '10000015',
                            url: 'bopaimiddle.html'

                        });
                    });
                    break;
                case 37: //摇号查询
                    DZ_COM.login(function() {
                        Daze.showMsg({
                            type: 'loading',
                            visible: true
                        });
                        $.ajax({
                            type:'post',
                            url: host.HOST_URL+'/yaohao/count.htm',
                            data:DZ_COM.convertParams({
                                uid: storage.getUid()
                            }),
                            dataType:'json',
                            success:function(r){
                                Daze.showMsg({
                                    type: 'loading',
                                    visible: false
                                });
                                var data = r.count,
                                    _utl = '';
                                if (!data) {
                                    _url = 'index.html';
                                }else {
                                    _url ="result.html";
                                }
                                Daze.pushWindow({
                                    appId: '10000016',
                                    url: _url
                                });
                                ga_storage._trackEvent('汽车服务-摇号查询', 'yaohao/list', '成功');
                            },
                            error: function() {
                                errNetWorkTip();
                                ga_storage._trackEvent('汽车服务-摇号查询', 'yaohao/list', '失败');
                            }
                        });
                    });
                    break;
                case 38: //车猫卖车
                    DZ_COM.login(function() {
                        Daze.pushWindow({
                            appId: '10000017',
                            url: 'index.html'
                        });
                    });
                    break;
                 case 60: //乐车帮
                    Daze.pushWindow({
                        appId: '10000001',
                        url: "http://m.lechebang.com/webapp/?alliance_id=17&site_id=18&act_id=18"
                    });
                    break;
                /*case 997: //淘汽云修
                    DZ_COM.login(function() {
                        var userId = storage.getUserId();
                        var coords = storage.getCoords();
                        var data = {lng:0, lat:0};

                        if (!tool.isEmpty(coords)) {
                            data.lng = coords.longitude;
                            data.lat = coords.latitude;
                        }
                        DZ_COM.checkNetwork(null, function() {
                            Daze.showMsg({
                                type: 'loading',
                                visible: true
                            });
                            $.ajax({
                                url: 'http://open.chengniu.com/auth/auth_code',
                                data: convertParamsRpb({
                                    uid: storage.getUid()
                                },'tqyx'),
                                success: function(r) {
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: false
                                    });
                                    if (r.code == '0') {
                                        if (r.data && r.data.code) {
                                            Daze.pushWindow({
                                                appId: '10000001',
                                                url: 'http://czapp.yunqixiu.com/activity/ocow/index.html?lat=' + data.lat + '&lng=' + data.lng + '&deviceid=' + userId + '&code=' + r.data.code
                                            });
                                        }
                                    } else {
                                        Daze.showMsg(r.msg);
                                        return false;
                                    }
                                    ga_storage._trackEvent('汽车服务-淘汽云修用户授权', '/auth/auth_code', '成功');
                                },
                                error: function() {
                                    errNetWorkTip();
                                    ga_storage._trackEvent('汽车服务-淘汽云修用户授权', '/auth/auth_code', '失败');
                                }
                            });
                        });
                    });
                    break;*/
                case 998:
                    Daze.pushWindow({
                        appId: '10000001',
                        url: 'http://file.chengniu.com/sj/index.html?cityId=' + storage.getCurCity().id
                    });
                    // Daze.pushWindow('http://www.udache.com/app/mDriverReg/index?channel=10&channelId=20401@needUploadImage');
                    break;
                case 999:
                    Daze.pushWindow('agent-services.html');
                    break;
            }
        } else {
            if (selfOperate) { //self supporting
                storage.storeInfo('curSupplier', {
                    id: curService.serviceProviderId
                });
                Daze.pushWindow({
                    appId: '10000003',
                    url: 'index.html'
                });
            } else {
                Daze.pushWindow({
                    appId: appId,
                    url: 'index.html'
                });
            }
        }
    }
});
