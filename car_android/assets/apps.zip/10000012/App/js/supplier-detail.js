require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, host, tool, storage, DZ_COM) {

    var $detail = $('#detail'),

        $mask = $('#mask'),
        $payWrap = $('#payWrap'),
        $priceIpt = $('#priceIpt'),
        $payBtn = $('#payBtn'),
        $cancelBtn = $('#cancelBtn');

    var queryObj = tool.getQueryString(),
        providerId = queryObj.id,
        serviceId = queryObj.serviceId,
        cityId = queryObj.cityId,
        userId = queryObj.userId,
        html = '';
        for(var s in queryObj){
            html += s + ':' + queryObj[s]+',';
        }
        alert(html);
    var system = null;
    var providerInfo = null;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        // 查找服务商跳转进入服务商详情
        var hash = location.hash;
        if (hash == '#noCache') {
            storage.removeInfo('curServiceOfBMW');
        }

        system = DZ_COM.getSystem();
        renderHeader();
        if (providerId) {
            getDetail();
            bindEvents();
        }
        else {
            Daze.showMsg('供应商不存在');
            setTimeout(function () {
                Daze.popWindow();
            }, 2100);
            return false;
        }
        // 保存userId
        if (userId) {
            storage.storeInfo('userId', userId);
        }
        ga_storage._trackPageview('carService/bmw/supplier-detail', "汽车服务-管家-服务商详情");
    }

    function bindEvents() {
        $detail.on('click', '.btn-follow', function () {
            DZ_COM.login(function () {
                followHandler();
                ga_storage._trackEvent('汽车服务-管家-服务商详情', '点击', '关注');
            });
        });
        $detail.on('click', '.btn-unfollow', function () {
            unfollowHandler();
            ga_storage._trackEvent('汽车服务-管家-服务商详情', '点击', '取消关注');
        });
        //认证
        $detail.on('click', '#auth', function () {
            Daze.pushWindow('auth.html');
        });
        //评论
        $detail.on('click', '#linkToComment', function () {
            Daze.pushWindow('comment.html');
        });
        //流程
        $detail.on('click', '#process', function () {
            Daze.pushWindow('process.html');
        });
        //说明
        $detail.on('click', '#conditions', function () {
            var $wrapServiceIntro = $('#wrapServiceIntro');

            $mask.removeClass('hidden');
            $wrapServiceIntro.removeClass('hidden');

            var windowHeight = $(window).height(),
                height = $wrapServiceIntro.height();

            $wrapServiceIntro.css('top', (windowHeight - height) / 2);
        });
        //服务介绍
        $detail.on('click', '#wrapServiceIntro', function () {
            return false;
        });
        $mask.click(function () {
            $('#wrapServiceIntro').addClass('hidden');
            $payWrap.addClass('hidden');
            $mask.addClass('hidden');
        });
        //地址
        $detail.on('click', '#address', function () {
            Daze.pushWindow('address.html');
        });

        //在线咨询
        $detail.on('click', '#consultBtn', function () {
            if (system == 'android') {
                var validVersion = DZ_COM.compareVersion('3.0.0.0');
                if (!validVersion) {
                    Daze.showMsg('当前版本暂不支持在线咨询功能，请升级到最新版本后进行操作');
                    return false;
                }
            }
            DZ_COM.login(function () {
                $.ajax({
                    url: host.HOST_URL + '/fw/callStatistics.htm',
                    type: 'post',
                    data: DZ_COM.convertParams({
                        optype: 6,
                        userId: storage.getUserId(),
                        uid: storage.getUid(),
                        serviceId: serviceId || storage.getCurServiceOfBMW().id,
                        cityId: storage.getCurCity().id || cityId
                    }),
                    success: function () {
                        Daze.feedback.openIM({
                            openUserId: providerInfo.providerDetail.openUserId,
                            providerName: encodeURI(providerInfo.providerDetail.fullName)
                        });
                        ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/callStatistics.htm', '成功');
                    },
                    error: function () {
                        ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/callStatistics.htm', '失败');
                    }
                });
            });
            ga_storage._trackEvent('汽车服务-管家-服务商详情', '点击', '在线咨询');
        });

        //电话
        $detail.on('click', '#callBtn', function () {
            ga_storage._trackEvent('汽车服务-管家-服务商详情', '点击', '电话');
            DZ_COM.login(function () {
                $.ajax({
                    url: host.HOST_URL + '/fw/callStatistics.htm',
                    type: 'post',
                    data: DZ_COM.convertParams({
                        userId: storage.getUserId(),
                        optype: 5,
                        providerId: providerId,
                        uid: storage.getUid(),
                        serviceId: serviceId || storage.getCurServiceOfBMW().id,
                        cityId: storage.getCurCity().id || cityId
                    }),
                    success: function () {
                        ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/callStatistics.htm', '成功');
                    },
                    error: function () {
                        ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/callStatistics.htm', '失败');
                    }
                });
            });
            if (!storage.getUid()) {
                return false;
            }
        });

        $detail.on('click', '#servicesSection .item', function () {
            var serviceId = $(this).data('id'),
                serviceName = $(this).find('.name').text();
            storage.storeInfo('curServiceOfBMW', {
                id: serviceId,
                name: serviceName
            });
            location.reload();
        });

        //担保支付
        $detail.on('click', '#showPayWrap', function () {
            $mask.removeClass('hidden');
            $payWrap.find('.service').text(providerInfo.serviceName);
            $payWrap.find('.supplier').text(providerInfo.providerDetail.fullName);
            $payWrap.removeClass('hidden');
            ga_storage._trackEvent('汽车服务-管家-服务商详情', '点击', '担保支付');
        });
        $priceIpt.click(function () {
            return false;
        });
        $priceIpt.focus(function () {
            setTimeout(function () {
                $payWrap.css('bottom', 0);
            }, 100);
        });
        $payBtn.click(function () {
            var price = $priceIpt.val();
            if (/^\+?[1-9][0-9]*$/.test(price)) {
                $mask.addClass('hidden');
                $payWrap.addClass('hidden');

                providerInfo.price = price;
                storage.setItem('providerInfo', providerInfo);

                DZ_COM.login(function () {
                    Daze.pushWindow('order-confirm.html');
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', '点击', '立即支付');
                });
            }
            else {
                Daze.showMsg('请输入正确的服务价格');
            }
        });
        //取消支付
        $cancelBtn.click(function () {
            $mask.addClass('hidden');
            $payWrap.addClass('hidden');
        });
        $payWrap.click(function () {
            return false;
        });
    }

    function renderHeader() {
        Daze.setTitle(storage.getCurServiceOfBMW().name || '详情');
    }

    function getDetail() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var domId = 'detail';
        DZ_COM.checkNetwork(domId, function () {
            var data = {
                providerId: providerId,
                cityId: storage.getCurCity().id || cityId,
                userId: storage.getUserId()
            };
            var serviceId = serviceId || storage.getCurServiceOfBMW().id,
                uid = storage.getUid();
            if (serviceId) {
                data.serviceId = serviceId;
            }
            if (uid) {
                data.uid = uid;
            }

            $.ajax({
                url: host.HOST_URL + '/fw/providersDetail.htm',
                type: 'post',
                data: DZ_COM.convertParams(data),
                success: function (r) {
                    if (r.code == 0) {
                        providerInfo = r.data;
                        storage.setItem('providerInfo', providerInfo);
                        renderDetail();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        if (r.code == 433) {
                            setTimeout(function () {
                                Daze.popTo(-1);
                            }, 2000);
                        }
                    }
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/providersDetail.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/providersDetail.htm', '失败');
                }
            });
        });
    }

    function renderDetail() {
        var data = convertData();
        $detail.html(template('detailTmpl', data));

        getServices();

        if (tool.isEmpty(storage.getCurServiceOfBMW())) {
            $detail.find('.section-price').addClass('hidden');
        }

        //头像缩放
        var $img = $detail.find('.avatar');
        DZ_COM.setImg($img, 80, 56);

        //ios系统下，app版本小于3.0.0时，隐藏在线咨询按钮
        if (system == 'ios') {
            var validVersion = DZ_COM.compareVersion('3.0.0');
            if (!validVersion) {
                $('#consultBtn').addClass('hidden');
            }
        }
    }

    function convertData() {
        var regionArr = [],
            serviceRegions = providerInfo.serviceRegions || [];
        for (var i = 0; i < serviceRegions.length; i++) {
            regionArr.push(serviceRegions[i].cityRegionName);
        }

        providerInfo.regionStr = regionArr.join('/');

        return providerInfo;
    }

    function renderRaty() {
        var $raty = $('.raty');
        $raty.raty({
            score: function () {
                return $(this).attr('data-score');
            },
            width: '100%',
            path: 'images',
            readOnly: true
        });
    }

    function getServices() {
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/fw/services.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    providerId: providerId,
                    cityId: storage.getCurCity().id || cityId
                }),
                success: function (r) {
                    if (r.code == 0) {
                        renderServices(r.data);
                    }
                    else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/services.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/services.htm', '失败');
                }
            });
        });
    }

    function renderServices(data) {
        var $servicesSection = $('#servicesSection');
        $servicesSection.html(template('serviceTmpl', data));
        renderRaty();

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function followHandler() {
        DZ_COM.checkNetwork(null, function () {
            var data = {
                uid: storage.getUid(),
                providerId: providerId
            };
            $.ajax({
                url: host.HOST_URL + "/fw/attention.htm",
                data: DZ_COM.convertParams(data),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.system.postObserver({name: 'daze_followEvent'});
                            Daze.showMsg('关注成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2000);
                        }
                        else {
                            Daze.showMsg('关注失败');
                        }
                    }
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/attention.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/attention.htm', '失败');
                }
            });
        });
    }

    function unfollowHandler() {
        DZ_COM.checkNetwork(null, function () {
            var data = {
                uid: storage.getUid(),
                providerId: providerId
            };
            $.ajax({
                url: host.HOST_URL + "/fw/cancelAttention.htm",
                data: DZ_COM.convertParams(data),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.system.postObserver({name: 'daze_followEvent'});
                            Daze.showMsg('取消关注成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2000);
                        }
                        else {
                            Daze.showMsg('取消关注失败');
                        }
                    }
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/cancelAttention.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-服务商详情', 'fw/cancelAttention.htm', '失败');
                }
            });
        });
    }
});
