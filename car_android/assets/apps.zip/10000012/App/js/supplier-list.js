require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, host, tool, storage, DZ_COM) {
    'use strict';

    var $itemCity = $('#itemCity'),
        $city = $('#city'),
        $itemAdvantage = $('#itemAdvantage'),
        $advantage = $('#advantage'),
        $listCity = $('#listCity'),
        $listAdvantage = $('#listAdvantage'),

        $list = $('#list'),
        $moreBtn = $('#moreBtn'),
        $noMoreTip = $('#noMoreTip');

    var pageSize = 10,
        pageIndex = 1,
        total = 0,
        loadedLength = 0;

    var curCity = null,
        curService = null;

    var districtsLoaded = false;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        curCity = storage.getCurCity();
        curService = storage.getCurServiceOfBMW();
        renderHeader();
        $('#service').text(curService.name);
        getDistricts();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/supplier-list', "汽车服务-管家-服务商列表");
    }

    function bindEvents() {
        //展开城市选择列表
        $itemCity.click(function () {
            if (!$listAdvantage.hasClass('hidden')) {
                $listAdvantage.addClass('hidden');
            }
            if (!districtsLoaded) {
                getDistricts();
            }
            $listCity.toggleClass('hidden');
        });
        //选择城市区域
        $listCity.on('click', 'li', function () {
            $(this).addClass('active').siblings().removeClass('active');
            var value = $(this).find('i.name').text(),
                id = $(this).data('regionid');
            $city.text(value).attr('data-regionid', id);

            resetList();
            getProviders();
            ga_storage._trackEvent('汽车服务-管家-服务商列表', '点击', value);
        });
        //展开条件选择列表
        $itemAdvantage.click(function () {
            if (!$listCity.hasClass('hidden')) {
                $listCity.addClass('hidden');
            }
            $listAdvantage.toggleClass('hidden');
        });
        //选择条件
        $listAdvantage.on('click', 'li', function () {
            $(this).addClass('active').siblings().removeClass('active');
            var value = $(this).text(),
                type = $(this).data('type');
            $advantage.text(value).attr('data-type', type);

            resetList();
            getProviders();
            ga_storage._trackEvent('汽车服务-管家-服务商列表', '点击', value);
        });
        //选择供应商
        $list.on('click', '.item', function (e) {
            var className = e.target.className;
            switch (className) {
                case 'auth':
                    Daze.pushWindow('auth.html');
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', '点击', '认证服务商');
                    break;
                case 'icon-call':
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', '点击', '电话');
                    break;
                default:
                    var id = $(this).data('id');
                    Daze.pushWindow('supplier-detail.html?id=' + id);
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', '点击', '服务商详情');
            }
        });

        //加载更多
        $moreBtn.click(function () {
            getProviders();
        });
    }

    function renderHeader() {
        Daze.setTitle(curService.name);
    }

    function getDistricts() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + "/fw/getRPCount.htm",
                data: DZ_COM.convertParams({
                    cityId: curCity.id,
                    serviceId: curService.id
                }),
                success: function (r) {
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if (r.code == 0) {
                        districtsLoaded = true;
                        var list = r.data.list;
                        renderDistricts(list);
                    }
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', 'fw/getRPCount.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', 'fw/getRPCount.htm', '失败');
                }
            });
        });
    }

    function renderDistricts(list) {
        $listCity.find('ul').html(template('cityTmpl', {
            list: list
        }));
        initFilter();
    }

    function initFilter() {
        var district_name = $listCity.find('li:first').children().text(),
            district_id = $listCity.find('li:first').data('regionid');
        $city.text(district_name).attr('data-regionid', district_id);

        var advantage_name = $listAdvantage.find('li').eq(0).text(),
            advantage_type = $listAdvantage.find('li').eq(0).data('type');
        $advantage.text(advantage_name).attr('data-type', advantage_type);

        getProviders();
    }

    function resetList() {
        $list.empty();
        pageIndex = 1;
    }

    function getProviders() {
        var domId = 'list';
        DZ_COM.checkNetwork(domId, function () {
            var coords = storage.getCoords();
            var data = {
                cityId: curCity.id,
                serviceId: curService.id,
                userId: storage.getUserId(),
                regionId: $city.data('regionid'),
                sortType: $advantage.data('type'),
                pageIndex: pageIndex,
                pageSize: pageSize
            };
            if (!tool.isEmpty(coords)) {
                data.longitude = coords.longitude;
                data.latitude = coords.latitude;
            }
            $.ajax({
                url: host.HOST_URL + "/fw/providers.htm",
                data: DZ_COM.convertParams(data),
                success: function (r) {
                    if (r.code == 0) {
                        var list = r.data.list;
                        total = r.data.total;
                        loadedLength += list.length;
                        pageIndex++;
                        renderProviders(list);
                    }
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', 'fw/providers.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-管家-服务商列表', 'fw/providers.htm', '失败');
                }
            });
        });
    }

    function renderProviders(list) {
        $list.append(template('listTmpl', {
            list: list
        }));

        //scale img
        var $img = $list.find('.avatar');
        $img.each(function (i, item) {
            DZ_COM.setImg($(item), 80, 56);
        });

        if (loadedLength < total) {
            $moreBtn.show();
            $noMoreTip.hide();
        }
        else {
            $moreBtn.hide();
            $noMoreTip.show();
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });

        renderRaty();
    }

    function renderRaty() {
        var $raty = $('.raty');
        $raty.raty({
            score: function () {
                return $(this).attr('data-score');
            },
            width: '100%',
            path: 'images',
            readOnly: true
        });
    }
});
