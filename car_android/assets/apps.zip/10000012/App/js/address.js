require([
    'lib/zepto.min',
    'com/tools',
    'com/storage',
    'com/GALocalStorage'
], function (a, tool, storage) {

    var providerInfo = storage.getItem('providerInfo'),
        name = providerInfo.providerDetail.fullName,
        address = providerInfo.providerDetail.address;

    var $infoWrap = $('#infoWrap'),
        $name = $('#name'),
        $address = $('#address');

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        if (!address) {
            Daze.showMsg('获取地址失败');
            setTimeout(function () {
                Daze.popTo(-1);
            }, 2000);
            return false;
        }
        renderMap();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/address', "汽车服务-管家-服务商地址");
    }

    function bindEvents() {
        var $showNav = $('#showNav'),
            $mask = $('#mask'),
            $navWrap = $('#navWrap');

        $showNav.click(function () {
            $mask.removeClass('hidden');
            $navWrap.removeClass('hidden');
            return false;
        });

        $(document).click(function (e) {
            if ($.inArray($navWrap[0], e.path) == -1) {
                $mask.addClass('hidden');
                $navWrap.addClass('hidden');
            }
        });

        $('.ipt-amap').click(function () {
            //todo
        });

        $('.ipt-baidu').click(function () {
            //todo
        });

        $('.ipt-others').click(function () {
            //todo
        });
    }

    function renderHeader() {
        Daze.setTitle('');
    }

    function renderMap() {
        $name.text(name);
        $address.text(address);
        $infoWrap.removeClass('hidden');

        var map = new BMap.Map("map");
        // 创建地址解析器实例
        var myGeo = new BMap.Geocoder();
        // 将地址解析结果显示在地图上,并调整地图视野
        myGeo.getPoint(address, function (point) {
            if (point) {
                map.centerAndZoom(point, 16);

                //添加标注
                var marker = new BMap.Marker(point);
                map.addOverlay(marker);
                marker.addEventListener('click', function () {
                });
            }
            else {
                var point = new BMap.Point(116.331398, 39.897445);
                map.centerAndZoom(point, 12);
                Daze.showMsg('地址解析失败');
            }
        });
    }
});