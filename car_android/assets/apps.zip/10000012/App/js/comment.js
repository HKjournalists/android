require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, host, storage, DZ_COM) {

    var pageIndex = 1,
        pageSize = 10,
        total = 0,
        loadedLength = 0;

    var $top = $('#top'),
        $list = $('#list'),
        $moreBtn = $('#moreBtn');

    var providerInfo = storage.getItem('providerInfo');

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        renderTop();
        getList();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/comment', "汽车服务-管家-评论");
    }

    function bindEvents() {
        //加载更多
        $moreBtn.click(function () {
            getList();
        });
    }

    function renderHeader() {
        Daze.setTitle('评论');
    }

    function renderTop() {
        $top.html(template('totalTmpl', providerInfo));
    }

    function getList() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var domId = 'list';
        DZ_COM.checkNetwork(domId, function () {
            $.ajax({
                url: host.HOST_URL + "/fw/getProviderComment.htm",
                data: DZ_COM.convertParams({
                    providerId: providerInfo.providerDetail.id,
                    pageIndex: pageIndex,
                    pageSize: pageSize
                }),
                success: function (r) {
                    if (r.code == 0) {
                        var list = convertData(r.data.list);
                        total = r.data.total;
                        loadedLength += list.length;
                        pageIndex++;
                        renderList(r.data);
                    }
                    ga_storage._trackEvent('汽车服务-管家-评论', 'fw/getProviderComment.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-管家-评论', 'fw/getProviderComment.htm', '失败');
                }
            });
        });
    }

    function convertData(list) {
        for (var i = 0; i < list.length; i++) {
            var date = list[i].createDatetime.split(' ')[0];
            list[i].createDatetime = date.replace(/-/g, '.');
        }

        return list;
    }

    function renderList(list) {
        $list.append(template('listTmpl', list));
        if (loadedLength < total) {
            $moreBtn.show();
        }
        else {
            $moreBtn.hide();
        }
        renderRaty();
        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function renderRaty() {
        var $raty = $('.raty');
        $raty.raty({
            score: function () {
                return $(this).attr('data-score');
            },
            width: '100%',
            path: 'images',
            readOnly: true
        });
    }
});