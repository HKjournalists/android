require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, tool, storage, DZ_COM) {

    var $supplier = $("#supplier"),
        $recruitBtn = $('#recruitBtn');

    var queryObj = tool.getQueryString(),
        noApply = queryObj.noApply;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        renderSupplier();

        // 根据noApply判断是否提供申请入驻操作
        if (noApply) {
            $recruitBtn.parents('.filler').addClass('hidden');
        }

        bindEvents();
        ga_storage._trackPageview('carService/bmw/auth', "汽车服务-管家-认证服务商");
    }

    function bindEvents() {
        $('#recruitBtn').click(function () {
            Daze.pushWindow('http://121.41.118.32/vendor/recruit.html');
            ga_storage._trackEvent('汽车服务-管家-认证服务商', '点击', ' 申请入驻');
        });
    }

    function renderHeader() {
        Daze.setTitle('认证服务商');
    }

    function renderSupplier() {
        var providerInfo = storage.getItem('providerInfo');
        if (tool.isEmpty(providerInfo)) {
            return false;
        }
        $supplier.html(template('supplierTmpl', providerInfo));
        //scale img
        var $img = $supplier.find('.avatar');
        DZ_COM.setImg($img, 80, 56);

        renderRaty();
    }

    function renderRaty() {
        var $raty = $('.raty');
        $raty.raty({
            score: function () {
                return $(this).attr('data-score');
            },
            width: '100%',
            path: 'images',
            readOnly: true
        });
    }
});