require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/common',
    'com/modules/refund',
    'com/GALocalStorage'
], function (a, b, host, tool, DZ_COM, module_refund) {

    var queryObj = tool.getQueryString(),
        orderId = queryObj.id,
        uid = queryObj.uid,
        pid = queryObj.pid;

    var $providerInfo = $('#providerInfo'),
        $orderInfo = $('#orderInfo'),

        $coupon = $('#coupon'),
        $payTypes = $('#payTypes'),
        $radioItem = $payTypes.find('.item-radio'),
        $checkboxItem = $payTypes.find('.item-new'),
        $balance = $('#balance'),

        $actionWrap = $('#actionWrap'),
        $payBtn = $('#payBtn'),
        $closeBtn = $('#closeBtn'),
        $refundBtn = $('#refundBtn'),
        $cancelRefundBtn = $('#cancelRefundBtn'),
        $addAccountBtn = $('#addAccountBtn'),
        $modifyAccountBtn = $('#modifyAccountBtn'),
        $completeBtn = $('#completeBtn'),
        $delayBtn = $('#delayBtn'),
        $evaluateBtn = $('#evaluateBtn');

    var orderInfo = null;

    var orderMoney = 0,//订单金额
        cashBalance = 0;//现金账户余额

    var localStatus = localStorage.getItem(orderId + 'Status')

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        getOrderInfo();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/order-detail', "汽车服务-管家-订单详情");
    }

    function bindEvents() {
        $payBtn.live('click', function () {
            payHandler();
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '立即支付');
        });

        $closeBtn.live('click', function () {
            closeHandler();
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '关闭订单');
        });

        $refundBtn.live('click', function () {
            refundHandler(0);
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '申请退款');
        });

        $cancelRefundBtn.live('click', function () {
            refundHandler(1);
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '取消退款');
        });

        $addAccountBtn.live('click', function () {
            renderRefund();
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '填写退款账号');
        });

        $modifyAccountBtn.live('click', function () {
            renderRefund(orderInfo.refundInfo);
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '修改退款账号');
        });

        $completeBtn.live('click', function () {
            completeHandler();
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '确认完成');
        });

        // 延长时间
        $delayBtn.live('click', function () {
            DZ_COM.confirm({
                content: '确定要延长服务的期限为17日？',
                yesFn: function () {
                    delayHandler();
                    ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '延长期限');
                }
            });
        });

        $evaluateBtn.live('click', function () {
            document.addEventListener('daze_evaluateEvent', evaluateEventHandler);
            Daze.system.addObserver({name: 'daze_evaluateEvent'});
            Daze.pushWindow('order-evaluate.html?orderId=' + orderId + '&uid=' + uid + '&provider=' + orderInfo.providerName);
            ga_storage._trackEvent('汽车服务-管家-订单详情', '点击', '评价有礼');
        });


        //选择支付方式
        $payTypes.on('click', '.item-radio', function () {
            if (orderMoney > cashBalance) {
                $(this).toggleClass('checked');
            }
            else {
                var $checkbox = $payTypes.find('.item-checkbox');
                $(this).addClass('checked');
                $checkbox.removeClass('checked');
            }
        });
        $payTypes.on('click', '.item-checkbox', function () {
            if (orderMoney > cashBalance) {
                if ($(this).hasClass('checked')) {
                    return false;
                }
                else {
                    $(this).addClass('checked').siblings('.item-checkbox').removeClass('checked');
                }
            }
            else {
                $(this).addClass('checked').siblings().removeClass('checked');
            }
        });
    }

    function renderHeader() {
        Daze.setTitle('订单详情');
    }

    function getOrderInfo() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/fw/detailOrders.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    orderId: orderId
                }),
                success: function (r) {
                    if (r.code == 0) {
                        orderInfo = convertData(r.data);
                        orderMoney = orderInfo.price;
                        renderInfo();
                    }
                    else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/detailOrders.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/detailOrders.htm', '失败');
                }
            });
        });
    }

    function convertData(orderInfo) {
        var temp = DZ_COM.convertStatus(orderInfo.status);
        orderInfo.statusTxt = temp.status;
        orderInfo.statusColor = temp.color;

        var refundApplyTime = orderInfo.refundApplyTime,
            refundCancelTime = orderInfo.refundCancelTime;

        orderInfo.refundApplyTimestamp = refundApplyTime ? +new Date(orderInfo.refundApplyTime.slice(0, -4).replace(/-/g, "/")) : 0; //replace方法兼容ios
        orderInfo.refundCancelTimestamp = refundCancelTime ? +new Date(orderInfo.refundCancelTime.slice(0, -4).replace(/-/g, "/")) : 0;

        return orderInfo;
    }

    function renderInfo() {
        $providerInfo.html(template('providerInfoTmpl', orderInfo));
        $orderInfo.html(template('orderInfoTmpl', orderInfo));
        $actionWrap.html(template('actionTmpl', orderInfo));

        //coupon
        var coupon = orderInfo.userCouponInfo;
        if (!tool.isEmpty(coupon)) {
            $coupon.attr({
                'data-id': coupon.id
            });
            $coupon.find('.name').text(coupon.name);
            $coupon.find('.price').text('¥' + coupon.amount);
            $coupon.removeClass('hidden');

            var temp = tool.convertNumber(orderMoney - coupon.amount);
            orderMoney = temp > 0 ? temp : 0.01;
        }

        if (orderInfo.status == 2) {
            if (localStatus) {
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
                $('.provider-info').find('.body1.name').find('.fr').text('支付处理中');
                setTimeout(function () {
                    getOrderInfo();
                }, 5000);
                return;
            }
            $payTypes.removeClass('hidden');
            renderPayType();
            getBalance();
        }
        else {
            localStorage.removeItem(orderId+'Status')
            Daze.showMsg({
                type: 'loading',
                visible: false
            });
        }
    }

    function renderPayType() {
        var system = DZ_COM.getSystem(),
            validVersion = getValidVersion(),
            validVersion1 = getValidVersion1(),
            validVersion2 = getValidVersion2();

        //旧版本兼容 3.0.0.0 Android & ios
        if (!validVersion) { // 低于版本处理
            $payTypes.find('.item-old').removeClass('hidden');
            $payTypes.find('.item-new').addClass('hidden');

            $checkboxItem = $payTypes.find('.item-old');
        }

        //旧版本兼容 3.2.0.0 Android
        if (validVersion1) { // 高于版本处理
            if (system == 'android') {
                $('.item-card').attr('data-type', 12);
                $('.item-wechat').removeClass('hidden');
            }
            else if (system == 'ios') {
                //3.2.0 ios
                $('.item-card').attr('data-type', 12);
                $('.item-alipay').attr('data-type', 16);
                $('.item-wechat').removeClass('hidden');
            }
        }

        // 旧版本兼容 3.2.1.0 Android
        if (validVersion2 && system == 'android') { // 高于版本处理
            $('.item-alipay').attr('data-type', 16);
        }
    }

    /**
     * @method getBalance
     * @description 获取账户余额
     */
    function getBalance() {
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getUserInfo.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    uid: uid
                }),
                success: function (r) {
                    if (r.code == 0) {
                        cashBalance = r.data.userInfo.cashBalance || 0;
                        payInit();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        cashBalance = 0;
                        payInit();
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'user/getUserInfo.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'user/getUserInfo.htm', '失败');
                }
            });
        });
    }

    function payInit() {
        if (cashBalance) {
            $balance.text(cashBalance);
            $radioItem.removeClass('hidden');
        }
        if (cashBalance >= orderMoney) {
            $radioItem.addClass('checked');
        }
        else {
            $radioItem.addClass('checked');
            $checkboxItem.eq(0).addClass('checked');
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function payHandler() {
        var validVersion = getValidVersion();
        var payType = getPayType();

        var payObj = {
            orderId: orderId,
            useBalance: payType.useBalance,
            payOnline: payType.payOnline
        };

        if (validVersion) {
            if (!payType.type) {
                Daze.showMsg('请选择支付方式');
                return false;
            }
            payObj.payType = payType.type;
        }

        Daze.pay(payObj, function (resp) {
            if (resp.isSuccess) {
                setTimeout(function () {
                    location.reload();
                }, 3000);
            }
            else {
                Daze.showMsg('支付失败');
            }
        });
    }

    function closeHandler() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/formOrder/closeOrder.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    orderId: orderId,
                    pId: pid
                }),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('关闭成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2000);
                        }
                        else {
                            Daze.showMsg('关闭失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'formOrder/closeOrder.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'formOrder/closeOrder.htm', '失败');
                }
            });
        });
    }

    function refundHandler(type) {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var params = {
            orderId: orderId,
            type: type
        };
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/fw/doRefund.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg(type ? '取消退款成功' : '申请退款成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2000);
                        }
                        else {
                            Daze.showMsg(type ? '取消退款失败' : '申请退款失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/doRefund.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/doRefund.htm', '失败');
                }
            });
        });
    }

    function renderRefund(refundInfo) {
        document.addEventListener('updateRefundInfoEvent', updateRefundInfoCallback);
        module_refund.init(refundInfo);
    }

    function completeHandler() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var params = {
            orderId: orderId
        };
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/fw/confirm.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('确认成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2000);
                        }
                        else {
                            Daze.showMsg('确认失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/confirm.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/confirm.htm', '失败');
                }
            });
        });
    }

    function delayHandler() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var params = {
            orderId: orderId
        };
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/fw/delayedOrder.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('延长期限成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2000);
                        }
                        else {
                            Daze.showMsg('延长期限失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/delayedOrder.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-订单详情', 'fw/delayedOrder.htm', '失败');
                }
            });
        });
    }

    function updateRefundInfoCallback() {
        console.log('updateRefundInfoCallback');
        location.reload();
    }

    function getPayType() {
        var type = 0,
            useBalance = false,
            payOnline = false;
        if (cashBalance) {
            useBalance = $radioItem.hasClass('checked');
        }

        $checkboxItem.each(function (i, item) {
            if ($(item).hasClass('checked')) {
                type = $(item).data('type');
                payOnline = true;
            }
        });

        type = Number(type);
        if (useBalance) {
            switch (type) {
                case 3: // 银行卡
                    type = 8;
                    break;
                case 1: // 支付宝
                    type = 6;
                    break;
                case 10: // 微信
                    type = 11;
                    break;
                case 12: // 连连
                    type = 14;
                    break;
                case 16: // OpenTrade
                    type = 17;
                    break;
                default:
                    type = 5;
                    break;
            }
        }

        return {
            type: type,
            useBalance: useBalance,
            payOnline: payOnline
        };
    }

    function evaluateEventHandler() {
        document.removeEventListener('daze_evaluateEvent', evaluateEventHandler);
        location.reload();
    }

    function getValidVersion() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3.0.0.0';
        }
        else if (system == 'ios') {
            latestVersion = '3.0.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }

    function getValidVersion1() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3.2.0.0';
        }
        else if (system == 'ios') {
            latestVersion = '3.2.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }

    function getValidVersion2() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3.2.1.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }
});