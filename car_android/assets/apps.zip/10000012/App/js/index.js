require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/city-list',
    'com/modules/city',
    'com/modules/banner',
    'com/GALocalStorage'
], function (a, b, c, host, tool, storage, DZ_COM, list, module_city, module_banner) {
    'use strict';

    var $main = $('#main'),
        isloading = false,
        $serviceList = $('#serviceList'),
        $followCount = $('#followCount'),
        $supplierList = $('#supplierList'),
        $moreBtn = $('#moreBtn'),
        $supplierTip = $("#supplierTip"),
        $joinUs = $('#joinUs'),

        $filter = $('#filter'),
        $itemCity = $('#itemCity'),
        $city = $('#city'),
        $itemAdvantage = $('#itemAdvantage'),
        $advantage = $('#advantage'),
        $listCity = $('#listCity'),
        cachaObj = {},
        bmwserviceList = storage.getGlobalData().bmwserviceList,
        $listAdvantage = $('#listAdvantage');

    var _versin
    var _system

    var type = null, // follow or service
        districtsLoaded = false;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        _versin = DZ_COM.compareVersion('3.8.0'),
        _system = DZ_COM.getSystem(),
        init();
    }, false);


    function init() {
        if(tool.isEmpty(storage.getItem('cityNowPage'))){
            storage.setItem('cityNowPage',{
                page : 'bmw'
            });
        }
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });

        document.addEventListener('cityChangeEvent', function (e) {
            if(_system === 'ios' && _versin){
                //ios3.8版本城市选择兼容
                return;
            }
            var data = e.data || {},
                curCity = storage.getCurCity();
            if(isloading && _system == 'ios'){
                return;
            }
            isloading = true;
            if (!tool.isEmpty(data) && data.cityId && data.cityName && data.province) {
                storage.storeInfo('curCity', {
                    id: data.cityId,
                    name: data.cityName,
                    province: data.province
                });
                location.reload();
            }
            //if (_system == 'ios') {
                location.reload();
            //}
        });

        document.addEventListener('selectEvent', function () {
            renderContent();
        });

        renderHeader();
        renderLeftMenu('menuCity');
        module_city.getCurrentCity(function (isSuccess) {
            if (isSuccess) {
                renderContent();
            }
            else {
                renderLeftMenu('menuCity');
            }
        });
        renderRecruit();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/index', "汽车服务-管家-首页");
    }

    function bindEvents() {
        //listen event
        document.addEventListener('logoutEvent', logoutEventHandler);
        document.addEventListener('loginEvent', function (e) {
            var data = e.data;
            storage.storeInfo('userId', data[0]);
            storage.storeInfo('uid', data[1]);
            storage.storeInfo('pid', data[2]);
            getList();
        });

        //选择服务
        $serviceList.on('click', 'li', function () {
            var isActive = $(this).hasClass('active');
            if (!isActive) {
                type = $(this).data('type');
                $(this).addClass('active').siblings().removeClass('active');
                setCurService();
                if (type == 'follow') {
                    getList();
                }
                else if (type == 'service') {
                    getDistricts();
                }
                ga_storage._trackEvent('汽车服务-管家-首页', '点击', $.trim($(this).text()));
            }
            else {
                return false;
            }
        });

        //选择服务商
        $supplierList.on('click', '.item', function (e) {
            var $this = $(this);
            var providerId = $this.data('id');
            var className = e.target.className;

            if (className == 'btn-follow') {
                DZ_COM.login(function () {
                    followHandler($this, providerId);
                    ga_storage._trackEvent('汽车服务-管家-首页', '点击', '关注');
                });
            }
            else {
                document.addEventListener('daze_followEvent', followEventHandler);
                Daze.system.addObserver({name: 'daze_followEvent'});
                Daze.pushWindow('supplier-detail.html?id=' + providerId);
                ga_storage._trackEvent('汽车服务-管家-首页', '点击', '服务商详情');
            }
        });

        //login
        $supplierList.on('click', '.btn-login', function () {
            DZ_COM.login(function () {
                getList();
            });
        });

        //加载更多
        $moreBtn.click(function () {
            Daze.pushWindow('supplier-list.html');
        });

        //进入橙牛代办
        $main.on('click', '.btn-forward', function () {
            Daze.pushWindow({
                appId: '10000001',
                url: 'agent-services.html'
            });
        });

        // 申请成为管家
        $joinUs.click(function () {
            if ($joinUs.hasClass('rotate')) {
                $joinUs.removeClass('rotate');
                rotateHandler();
            }
            else {
                Daze.pushWindow('http://121.41.118.32/vendor/recruit.html');
            }
        });

        // 展开城市选择列表
        $itemCity.click(function () {
            if (!$listAdvantage.hasClass('hidden')) {
                $listAdvantage.addClass('hidden');
            }
            if (!districtsLoaded) {
                getDistricts();
            }
            $listCity.toggleClass('hidden');
            if ($listCity.hasClass('hidden')) {
                $('#mask').addClass('hidden');
            }
            else {
                $('#mask').removeClass('hidden');
            }
        });

        //选择城市区域
        $listCity.on('click', 'li', function () {
            $(this).addClass('active').siblings().removeClass('active');
            $listCity.addClass('hidden');
            $('#mask').addClass('hidden');
            var value = $(this).find('i.name').text(),
                id = $(this).data('regionid');
            $city.text(value).attr('data-regionid', id);

            resetList();
            getList();
            ga_storage._trackEvent('汽车服务-管家-首页', '点击', value);
        });

        // 展开条件选择列表
        $itemAdvantage.click(function () {
            if (!$listCity.hasClass('hidden')) {
                $listCity.addClass('hidden');
            }
            $listAdvantage.toggleClass('hidden');
            if ($listAdvantage.hasClass('hidden')) {
                $('#mask').addClass('hidden');
            }
            else {
                $('#mask').removeClass('hidden');
            }
        });

        //选择条件
        $listAdvantage.on('click', 'li', function () {
            $(this).addClass('active').siblings().removeClass('active');
            $listAdvantage.addClass('hidden');
            $('#mask').addClass('hidden');
            var value = $(this).text(),
                type = $(this).data('type');
            $advantage.text(value).attr('data-type', type);

            resetList();
            getList();
            ga_storage._trackEvent('汽车服务-管家-首页', '点击', value);
        });

        $('#mask').click(function () {
            $(this).addClass('hidden');
            $listCity.addClass('hidden');
            $listAdvantage.addClass('hidden');
        });
    }

    function renderHeader() {
        Daze.setTitle('管家');
    }

    // 渲染页面内容
    function renderContent() {
        renderLeftMenu('menuCity');
        module_banner.init('providerHead', function () {
            renderMainHeight();
        });
        getServices();
    }

    function renderMainHeight() {
        var h = $(window).height() - $('#banner').height();
        $main.height(h);
    }

    function renderLeftMenu(menuId) {
        var curCity = storage.getCurCity(),
            title = '';

        if (menuId == 'menuCity') {
            if (curCity && curCity.name) {
                title = curCity.name + ' ν';
            }
            else {
                title = '请选择';
            }
        }
        else if (menuId == 'menuClose') {
            title = '关闭';
        }

        Daze.showOptionMenu({
            items: [
                {
                    title: title,
                    id: menuId,
                    side: 'left'
                }
            ]
        }, function () {
            if (menuId == 'menuCity') {
                renderLeftMenu('menuClose');
                module_city.init();
            }
            else if (menuId == 'menuClose') {
                renderLeftMenu('menuCity');
                module_city.closeWin();
            }
        });
    }

    function getServices() {
        DZ_COM.checkNetwork(null, function () {
            var curCity = storage.getCurCity();
            var data = {
                cityId: curCity.id
            };
            $.ajax({
                url: host.HOST_URL + "/fw/getCityService.htm",
                data: DZ_COM.convertParams(data),
                timeout : 7000,
                success: function (r) {
                    if (r.code == 0) {
                        var list = r.data.list || [];
                        cachaObj.services = list;
                        storage.storeInfo('bmwserviceList', cachaObj);
                        renderServices(list);
                    }else{
                        if(!tool.isEmpty(bmwserviceList)){
                            renderServices(bmwserviceList.services);
                        }
                    }
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/getCityService.htm', '成功');
                },
                error: function (r) {
                    if(!tool.isEmpty(bmwserviceList)){
                        renderServices(bmwserviceList.services);
                    }
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/getCityService.htm', '失败');
                }
            });
        });
    }

    function renderServices(list) {
        if (list.length) {
            $serviceList.children('ul').append(template('serviceTmpl', {
                list: list
            }));

            $serviceList.find('li').eq(1).addClass('active');
            type = $serviceList.find('li.active').data('type');

            setCurService();
            getDistricts();
            isloading = false;
        }
        else {
            $main.html(template('noServiceTmpl'));
        }
    }

    function getDistricts() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        DZ_COM.checkNetwork(null, function () {
            var cityId = storage.getCurCity().id,
                serviceId = storage.getCurServiceOfBMW().id;

            $.ajax({
                url: host.HOST_URL + "/fw/getRPCount.htm",
                data: DZ_COM.convertParams({
                    cityId: cityId,
                    serviceId: serviceId
                }),
                timeout : 7000,
                success: function (r) {
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if (r.code == 0) {
                        districtsLoaded = true;
                        var list = r.data.list;
                        cachaObj.districts = list;
                        storage.storeInfo('bmwserviceList', cachaObj);
                        renderDistricts(list);
                    }
                    else {
                        getSuppliers();
                    }
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/getRPCount.htm', '成功');
                },
                error: function (r) {
                    if(!tool.isEmpty(bmwserviceList)){
                        renderDistricts(bmwserviceList.districts);
                        getSuppliers();
                    }
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/getRPCount.htm', '失败');
                }
            });
        });
    }

    function renderDistricts(list) {
        $listCity.find('ul').html(template('cityTmpl', {
            list: list
        }));
        initFilter();
    }

    function initFilter() {
        var district_name = $listCity.find('li:first').children().text(),
            district_id = $listCity.find('li:first').data('regionid');
        $city.text(district_name).attr('data-regionid', district_id);

        var advantage_name = $listAdvantage.find('li').eq(0).text(),
            advantage_type = $listAdvantage.find('li').eq(0).data('type');
        $advantage.text(advantage_name).attr('data-type', advantage_type);

        getList();
    }

    function getList() {
        resetList();
        switch (type) {
            case 'follow':
                getFollows();
                break;
            case 'service':
                var uid = storage.getUid();
                if (uid) {
                    getFollows(true);
                }
                getSuppliers();
                break;
        }
    }

    function resetList() {
        $filter.addClass('hidden');
        $supplierList.empty();
        $supplierTip.addClass('hidden');
        $moreBtn.addClass('hidden');
    }

    function getFollows(totalOnly) {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });

        var domId = 'supplierList';
        DZ_COM.checkNetwork(domId, function () {
            var uid = storage.getUid(),
                coords = storage.getCoords();
            if (uid) {
                var data = {
                    uid: uid
                };
                if (!tool.isEmpty(coords)) {
                    data.longitude = coords.longitude;
                    data.latitude = coords.latitude;
                }
                $.ajax({
                    url: host.HOST_URL + "/fw/getAttentionList.htm",
                    data: DZ_COM.convertParams(data),
                    success: function (r) {
                        if (r.code == 0) {
                            $followCount.text(r.data.total).removeClass('hidden');
                            if (totalOnly) {
                                return false;
                            }
                            var list = convertFollows(r.data.list);
                            renderSuppliers(list);
                        }
                        else {
                            Daze.showMsg(r.msg);
                            return false;
                        }
                        ga_storage._trackEvent('汽车服务-管家-首页', 'fw/getAttentionList.htm', '成功');
                    },
                    error: function (r) {
                        DZ_COM.renderNetworkTip(domId, 1);
                        ga_storage._trackEvent('汽车服务-管家-首页', 'fw/getAttentionList.htm', '失败');
                    }
                });
            }
            else {
                $followCount.text(0).addClass('hidden');
                var $btn = $('<input type="button" class="btn-login" value="请登录">');
                $supplierList.append($btn);
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
            }
        });
    }

    function convertFollows(list) { //关注列表数据的二次处理，与某服务下的服务商列表数据保持一致
        var arr = [];
        for (var i = 0; i < list.length; i++) {
            var o = list[i].provider;
            o.full_name = o.fullName;
            delete o.fullName;
            o.comment = list[i].commentCount;
            o.distance = list[i].distance;
            o.attention = true;
            arr.push(o);
        }

        return arr;
    }

    function getSuppliers() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });

        var domId = 'supplierList';
        DZ_COM.checkNetwork(domId, function () {
            var curCity = storage.getCurCity(),
                coords = storage.getCoords(),
                uid = storage.getUid();
            var data = {
                cityId: curCity.id,
                serviceId: storage.getCurServiceOfBMW().id,
                userId: storage.getUserId(),
                regionId: $city.data('regionid'),
                sortType: $advantage.data('type'),
                pageIndex: 1,
                pageSize: 10
            };
            if (uid) {
                data.uid = uid;
            }
            if (!tool.isEmpty(coords)) {
                data.longitude = coords.longitude;
                data.latitude = coords.latitude;
            }
            $.ajax({
                url: host.HOST_URL + "/fw/providers.htm",
                data: DZ_COM.convertParams(data),
                timeout : 7000,
                success: function (r) {
                    if (r.code == 0) {
                        var list = r.data.list;
                        cachaObj.suppliers = list;
                        storage.storeInfo('bmwserviceList', cachaObj);
                        renderSuppliers(list);
                    }
                    else {
                        if(!tool.isEmpty(bmwserviceList)){
                            renderSuppliers(bmwserviceList.suppliers);
                        }
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/providers.htm', '成功');
                },
                error: function (r) {
                    if(!tool.isEmpty(bmwserviceList)){
                        renderSuppliers(bmwserviceList.suppliers);
                    }
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/providers.htm', '失败');
                }
            });
        });
    }

    function renderSuppliers(list) {
        var serviceName = storage.getCurServiceOfBMW().name;
        $supplierList.append(template('supplierTmpl', {
            list: list,
            type: type,
            serviceName: serviceName
        }));

        switch (type) {
            case 'follow':
                $filter.addClass('hidden');
                $moreBtn.addClass('hidden');
                break;
            case 'service':
                if (list.length) {
                    // 当服务商数量可在一页内完全显示，隐藏查看更多管家按钮
                    var contentHeight = $supplierList.height(),
                        mainHeight = $main.height();
                    $filter.removeClass('hidden');
                    $moreBtn.toggleClass('hidden', contentHeight < mainHeight);
                    $supplierTip.find('em').text(serviceName);
                    $supplierTip.toggleClass('hidden', contentHeight >= mainHeight);
                }
                break;
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });

        renderImg();
        renderRaty();
        isloading = false;
    }

    function renderImg() {
        var $img = $supplierList.find('.avatar');
        $img.each(function (i, item) {
            DZ_COM.setImg($(item), 48, 48);
        });
    }

    function renderRaty() {
        var $raty = $('.raty');
        $raty.raty({
            score: function () {
                return $(this).attr('data-score');
            },
            width: '100%',
            path: 'images',
            readOnly: true
        });
    }

    function renderRecruit() {
        setTimeout(function () {
            $joinUs.addClass('scale');
            rotateHandler();
        }, 1000);
    }

    function rotateHandler() {
        setTimeout(function () {
            $joinUs.addClass('rotate');
        }, 5000);
    }

    function followHandler($this, providerId) {
        DZ_COM.checkNetwork(null, function () {
            var data = {
                uid: storage.getUid(),
                providerId: providerId
            };
            $.ajax({
                url: host.HOST_URL + "/fw/attention.htm",
                data: DZ_COM.convertParams(data),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('关注成功');
                            $this.find('.btn-follow').prop('disabled', true);
                            getFollows(true);
                        }
                        else {
                            Daze.showMsg('关注失败');
                        }
                    }
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/attention.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-首页', 'fw/attention.htm', '失败');
                }
            });
        });
    }

    function setCurService() {
        var $li_active = $serviceList.find('li.active'),
            serviceId = $li_active.data('id'),
            serviceName = $li_active.text();

        if (type == 'follow') {
            storage.storeInfo('curServiceOfBMW', {});
        }
        else {
            storage.storeInfo('curServiceOfBMW', {
                id: serviceId,
                name: serviceName
            });
        }
    }

    function logoutEventHandler() {
        document.removeEventListener('logoutEvent', logoutEventHandler);
        storage.removeInfo('pid');
        storage.removeInfo('uid');
        storage.removeInfo('userId');
        $followCount.text(0).addClass('hidden');
        getList();
    }

    function followEventHandler() {
        document.removeEventListener('daze_followEvent', followEventHandler);
        getList();
    }
});
