require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/tools',
    'com/storage',
    'com/GALocalStorage'
], function (a, b, tool, storage) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        renderInfo();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/order-completed', "汽车服务-管家-支付完成");
    }

    function bindEvents() {
        var $processItem = $('#processItem'),
            $orderItem = $('#orderItem');
        $processItem.click(function () {
            Daze.pushWindow('process.html');
            ga_storage._trackEvent('汽车服务-管家-支付完成', '点击', '查看担保交易流程');
        });
        $orderItem.click(function () {
            Daze.navigator.gotoOrderList({
                colIndex: 3
            });
            ga_storage._trackEvent('汽车服务-管家-支付完成', '点击', '查看我的订单');
        });
    }

    function renderHeader() {
        Daze.setTitle('支付完成');
    }

    function renderInfo() {
        var providerInfo = storage.getItem('providerInfo');
        $('.service').text(providerInfo.serviceName);
        $('.price').text(providerInfo.price);
    }
});