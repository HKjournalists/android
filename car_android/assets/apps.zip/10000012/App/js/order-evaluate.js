require([
    'lib/zepto.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/tools',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, DZ_COM) {

    var queryObj = tool.getQueryString(),
        provider = queryObj.provider,
        orderId = queryObj.orderId,
        uid = queryObj.uid;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        renderProvider();
        renderRaty();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/order-detail', "汽车服务-管家-评价服务");
    }

    function bindEvents() {
        $('#evaluateBtn').click(function () {
            evaluateHandler();
            ga_storage._trackEvent('汽车服务-管家-评价服务', '点击', '提交评价');
        });
    }

    function renderHeader() {
        Daze.setTitle('评价服务');
    }

    function renderProvider() {
        $('#name').text(provider);
    }

    function renderRaty() {
        var $raty = $('#raty');
        var score = null;
        $raty.raty({
            score: function () {
                score = $(this).attr('data-score');
                return score;
            },
            width: '100%',
            path: 'images',
            click: function (score) {
                renderHint(score);
            }
        });
        renderHint(score);
    }

    function renderHint(score) {
        var $raty = $('#raty'),
            $hint = $('#hint');
        if ($hint.length) {
            $hint.text(score);
        }
        else {
            $hint = $('<span class="hint" id="hint">' + score + '</span>');
            $raty.append($hint);
        }
    }

    function evaluateHandler() {
        var score = $('#raty').find('input').val();
        var comment = $('#comment').val();

        if (!score) {
            Daze.showMsg('请选择评分');
            return false;
        }
        else if (!comment) {
            Daze.showMsg('请输入评价内容');
            return false;
        }

        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/fw/evaluate.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    uid: uid,
                    orderId: orderId,
                    score: score,
                    content: comment
                }),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('评价成功');
                            setTimeout(function () {
                                Daze.system.postObserver({name: 'daze_evaluateEvent'});
                                Daze.popTo(-1);
                            }, 2000);
                        }
                        else {
                            Daze.showMsg('评价失败');
                            setTimeout(function () {
                                Daze.popTo(-1);
                            }, 2000);
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-评价服务', 'fw/evaluate.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-评价服务', 'fw/evaluate.htm', '失败');
                }
            });
        });
    }
});