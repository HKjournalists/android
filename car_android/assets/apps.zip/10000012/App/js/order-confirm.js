require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/tools',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM) {
    var recordOrderId
    var $providerInfo = $('#providerInfo'),
        //$coupon = $('#coupon'),

        $payTypes = $('#payTypes'),
        $radioItem = $payTypes.find('.item-radio'),
        $checkboxItem = $payTypes.find('.item-new'),
        $balance = $('#balance'),
        $payBtn = $('#payBtn');

    var providerInfo = storage.getItem('providerInfo');
        providerInfo.cityName = storage.getCurCity().name;

    var orderMoney = providerInfo.price || 0,//订单金额
        cashBalance = 0;//现金账户余额

    var curCity = null,
        curService = null;

    var couponList = [];

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        curCity = storage.getCurCity();
        curService = storage.getCurServiceOfBMW();
        renderHeader();
        renderInfo();
        renderPayType();
        getCoupons();
        getBalance();
        bindEvents();
        ga_storage._trackPageview('carService/bmw/order-confirm', "汽车服务-管家-确认订单");
    }

    function bindEvents() {
        //选择代金券
        $('#coupon').click(function () {
            Daze.showSelectWin(couponList, function (coupon) {
                couponChange(coupon);
            });
        });
        //选择支付方式
        $payTypes.on('click', '.item-radio', function () {
            if (orderMoney > cashBalance) {
                $(this).toggleClass('checked');
            }
            else {
                var $checkbox = $payTypes.find('.item-checkbox');
                $(this).addClass('checked');
                $checkbox.removeClass('checked');
            }
        });
        $payTypes.on('click', '.item-checkbox', function () {
            if (orderMoney > cashBalance) {
                if ($(this).hasClass('checked')) {
                    return false;
                }
                else {
                    $(this).addClass('checked').siblings('.item-checkbox').removeClass('checked');
                }
            }
            else {
                $(this).addClass('checked').siblings().removeClass('checked');
            }
        });

        //支付
        $payBtn.click(function () {
            addOrder();
            ga_storage._trackEvent('汽车服务-管家-确认订单', '点击', '在线支付');
        });
    }

    function renderHeader() {
        Daze.setTitle('确认订单');
    }

    function renderInfo() {
        $providerInfo.html(template('infoTmpl', providerInfo));
        renderMoney();
    }

    function renderPayType() {
        var system = DZ_COM.getSystem(),
            validVersion = getValidVersion(),
            validVersion1 = getValidVersion1(),
            validVersion2 = getValidVersion2();

        //旧版本兼容 3.0.0.0 Android & ios
        if (!validVersion) { // 低于版本处理
            $payTypes.find('.item-old').removeClass('hidden');
            $payTypes.find('.item-new').addClass('hidden');

            $checkboxItem = $payTypes.find('.item-old');
        }

        //旧版本兼容 3.2.0.0 Android
        if (validVersion1) { // 高于版本处理
            if (system == 'android') {
                $('.item-card').attr('data-type', 12);
                $('.item-wechat').removeClass('hidden');
            }
            else if (system == 'ios') {
                //3.2.0 ios
                $('.item-card').attr('data-type', 12);
                $('.item-alipay').attr('data-type', 16);
                $('.item-wechat').removeClass('hidden');
            }
        }

        // 旧版本兼容 3.2.1.0 Android
        if (validVersion2 && system == 'android') { // 高于版本处理
            $('.item-alipay').attr('data-type', 16);
        }
    }

    /**
     * @method getCoupons
     * @description 获取代金券列表
     */
    function getCoupons() {
        DZ_COM.checkNetwork(null, function () {
            var params = {
                orderTypeId: 5,
                uid: storage.getUid(),
                price: providerInfo.price
            };
            $.ajax({
                url: host.HOST_URL + '/coupon/getValidList.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        renderCoupon(r.data.list || []);
                    }
                    else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-管家-确认订单', 'coupon/getValidList.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-确认订单', 'coupon/getValidList.htm', '失败');
                }
            });
        });
    }

    function renderCoupon(list) {
        couponChange();

        for (var i = 0; i < list.length; i++) {
            var itemList = list[i].list || [];
            if (list[i].name == curService.id) {
                couponList = itemList;
            }
            else if (list[i].name == 'all') {
                couponList = couponList.concat(itemList);
            }
        }

        if (couponList.length) {
            for (var j = 0; j < couponList.length; j++) {
                couponList[j].endTime = couponList[j].endTime.split(' ')[0];
            }

            //默认选中最近到期的代金券
            couponChange(couponList[0]);

            $('#coupon').removeClass('hidden');
        }
    }

    function couponChange(coupon) {
        if (!tool.isEmpty(coupon)) {
            $('#coupon').attr({
                'data-id': coupon.id
            });
            $('#coupon').find('.name').text(coupon.name);
            $('#coupon').find('.price').text('¥' + coupon.amount);

            var money = tool.convertNumber(orderMoney - coupon.amount);
            money = money > 0 ? money : 0.01;

            renderMoney(money);
        }
        else {
            $('#coupon').attr({
                'data-id': 0
            });
            $('#coupon').find('.name').text('请选择代金券');
            $('#coupon').find('.price').text('');

            renderMoney();
        }
    }

    function renderMoney(money) {
        money = money ? money : orderMoney;
        $providerInfo.find('.price span').text(money);
        $payBtn.val('在线支付¥' + money);
    }

    /**
     * @method getBalance
     * @description 获取账户余额
     */
    function getBalance() {
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getUserInfo.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    uid: storage.getUid()
                }),
                success: function (r) {
                    if (r.code == 0) {
                        cashBalance = r.data.userInfo.cashBalance || 0;
                        payInit();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        cashBalance = 0;
                        payInit();
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-确认订单', 'user/getUserInfo.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-确认订单', 'user/getUserInfo.htm', '失败');
                }
            });
        });
    }

    function payInit() {
        if (cashBalance) {
            $balance.text(cashBalance);
            $radioItem.removeClass('hidden');
        }
        if (cashBalance >= orderMoney) {
            $radioItem.addClass('checked');
        }
        else {
            $radioItem.addClass('checked');
            $checkboxItem.eq(0).addClass('checked');
        }
    }

    function addOrder() {
        var params = {
            uid: storage.getUid(),
            pId: storage.getPid(),
            userId: storage.getUserId(),
            cityId: curCity.id,
            serviceName: providerInfo.serviceName,
            providerId: providerInfo.providerDetail.id,
            providerName: providerInfo.providerDetail.fullName,
            providerPhone: providerInfo.providerDetail.name,
            providerServiceId: providerInfo.providerServiceId,
            price: providerInfo.price,
            descr: $('#demand').val()
        };

        var couponId = $('#coupon').data('id');
        if (couponId) {
            params.couponId = {
                benjin: couponId
            };
        }

        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/fw/submitOrders.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        recordOrderId = r.data.orderId
                        payHandler(r.data.orderId);
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-管家-确认订单', 'fw/submitOrders.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-管家-确认订单', 'fw/submitOrders.htm', '失败');
                }
            });
        });
    }

    function payHandler(orderId) {
        var validVersion = getValidVersion();
        var payType = getPayType();

        var payObj = {
            orderId: orderId,
            useBalance: payType.useBalance,
            payOnline: payType.payOnline
        };

        if (validVersion) {
            if (!payType.type) {
                Daze.showMsg('请选择支付方式');
                return false;
            }
            payObj.payType = payType.type;
        }

        Daze.pay(payObj, function (resp) {
            if (resp.isSuccess) {
                localStorage.setItem(recordOrderId+'Status',recordOrderId)
                setTimeout(function () {
                    location.reload();
                }, 3000);
                Daze.pushWindow('order-completed.html');
            }
            else {
                Daze.showMsg('支付失败');
                setTimeout(function () {
                    Daze.popTo(-1);
                }, 2000);
            }
        });
    }

    function getPayType() {
        var type = 0,
            useBalance = false,
            payOnline = false;
        if (cashBalance) {
            useBalance = $radioItem.hasClass('checked');
        }

        $checkboxItem.each(function (i, item) {
            if ($(item).hasClass('checked')) {
                type = $(item).data('type');
                payOnline = true;
            }
        });

        type = Number(type);
        if (useBalance) {
            switch (type) {
                case 3: // 银行卡
                    type = 8;
                    break;
                case 1: // 支付宝
                    type = 6;
                    break;
                case 10: // 微信
                    type = 11;
                    break;
                case 12: // 连连
                    type = 14;
                    break;
                case 16: // OpenTrade
                    type = 17;
                    break;
                default:
                    type = 5;
                    break;
            }
        }
        return {
            type: type,
            useBalance: useBalance,
            payOnline: payOnline
        };
    }

    function getValidVersion() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3.0.0.0';
        }
        else if (system == 'ios') {
            latestVersion = '3.0.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }

    function getValidVersion1() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3.2.0.0';
        }
        else if (system == 'ios') {
            latestVersion = '3.2.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }

    function getValidVersion2() {
        var system = DZ_COM.getSystem(),
            latestVersion = '';
        if (system == 'android') {
            latestVersion = '3.2.1.0';
        }

        return DZ_COM.compareVersion(latestVersion);
    }
});