require([
    'lib/zepto.min',
    'com/GALocalStorage',
    'com/storage',
    'com/host',
    'com/common',
    'com/tools',
    'com/modules/banner',
    'lib/underscore'
], function (a, b,storage,host,DZ_COM,tool,module_banner) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        DZ_COM.login(function(){
            init();
        })
    }, false);

    function init() {
        Daze.setTitle('选择服务');
        ga_storage._trackPageview('carService/smby/index', "汽车服务-上门保养-选择服务");
        // FastClick.attach(document.body);
        render()
    }

	function render() {
        var serviceId = tool.getQueryString().serviceId
        var cityId = tool.getQueryString().cityId
        var cityTmpl = _.template($('#list-city').html())
        var cityName = tool.getQueryString().cityName

        Daze.showMsg({
            type: 'loading',
            visible: true
        });

        $.ajax({
            type:"get",
            url: host.HOST_URL + "/fw/serviceGoodsList.htm",
            data:DZ_COM.convertParams({serviceId:serviceId,cityId:cityId}),
            dataType:"json",
            success: function(data){
                var data = data.data.list;
                var cityHtml = cityTmpl({citylist : data})
                $('.service-list-box').html(cityHtml)
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
            },
            error: function(xhr,type){

            }
        });

		$('.service-list-box').on('click','.service-item',function(e){
            e.preventDefault()
			var _id = $(this).data('id')
        	Daze.pushWindow('service-detail.html?proId='+_id+'&cityId='+cityId+'&cityName='+cityName);
		})

        $.ajax({
            type:"get",
            url: host.HOST_URL + "/advert/getPosition.htm",
            data:DZ_COM.convertParams({relationValue:serviceId}),
            dataType:"json",
            success: function(data){
                if(data.data.identity){
                    module_banner.init(data.data.identity);
                }
            },
            error: function(xhr,type){

            }
        });

    }





});
