define([], function () {
    return [
        {
            "province": "北京市",
            "cities": [
                {
                    "name": "北京市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "被处罚人"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "重庆市",
            "cities": [
                {
                    "name": "重庆市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "上海市",
            "cities": [
                {
                    "name": "上海市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "海南省",
            "cities": [
                {
                    "name": "海口市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "三亚市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "五指山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": false
        },
        {
            "province": "湖北省",
            "cities": [
                {
                    "name": "武汉市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        //{
                        //    "field": "param1",
                        //    "name": "财政票据网点代码"
                        //},
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "宜昌市",
                    "units": [
                        {
                            "name": "宜昌交警罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                },
                                {
                                    "field": "param1",
                                    "name": "取财政票据网点代码"
                                }
                            ],
                            "desc": "网点代码可在上图查询，也可在交警中心和建行任一网点获取，若不输入则默认为建行西陵支行(南湖宾馆对面)。请于缴交后一年内凭处罚通知书到选定建行网点(未选即西陵支行)领取财政票据。"
                        }
                    ],
                    "valid": false,
                    "payOnline": 1
                },
                {
                    "name": "荆州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "财政票据网点代码"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "十堰市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "财政票据网点代码"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "黄石市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "财政票据网点代码"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "黄冈市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "财政票据网点代码"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "湖南省",
            "cities": [
                {
                    "name": "长沙市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "株洲市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "湘潭市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "衡阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "邵阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "岳阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "常德市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "张家界市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "益阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "娄底市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "郴州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "永州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "怀化市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "湘西市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "江西省",
            "cities": [
                {
                    "name": "南昌市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "景德镇",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "赣州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "九江市",
                    "units": [
                        {
                            "name": "代收九江交通违章罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "交通罚款单编号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "宜春市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "上饶市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "萍乡市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "新余市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "鹰潭市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "吉安市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "抚州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "安徽省",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "安徽省交警罚款代收",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "罚单号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "福建省",
            "cities": [
                {
                    "name": "福州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "厦门市",
                    "units": [
                        {
                            "name": "厦门交警（缴费）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚通知书编号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "泉州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "莆田市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "漳州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "宁德市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "三明市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "南平市",
                    "units": [
                        {
                            "name": "南平交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "16位罚单号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "龙岩市",
                    "units": [
                        {
                            "name": "龙岩交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "16位罚单号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "武夷山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "河南省",
            "cities": [
                {
                    "name": "郑州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "洛阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "新乡市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "南阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "平顶山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "安阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "开封市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": false
        },
        {
            "province": "河北省",
            "cities": [
                {
                    "name": "石家庄市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "保定市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "唐山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "廊坊市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "邯郸市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "秦皇岛市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "沧州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "邢台市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "衡水市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "张家口市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "承德市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "定州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "馆陶市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "张北市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "赵县市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "正定市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "青海省",
            "cities": [
                {
                    "name": "西宁市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": false
        },
        {
            "province": "甘肃省",
            "cities": [
                {
                    "name": "临夏",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "兰州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "定西市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "平凉市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "庆阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "金昌市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "武威市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "张掖市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "嘉峪关市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "酒泉市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "天水市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "陇南市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "甘南",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "白银市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "广东省",
            "cities": [
                {
                    "name": "深圳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "广州市",
                    "units": [
                        {
                            "name": "广州地区交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ],
                            "desc": "处罚决定书号为罚单上方15位或16位编号。广州辖区内有非现场处理交通违法行为的车主或当事人，可于金盾网完成罚单确认后办理缴费。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "东莞市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "佛山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "中山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "珠海市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "惠州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "江门市",
                    "units": [
                        {
                            "name": "凭决定书号缴费（不要发票）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "决定书"
                                },
                                {
                                    "field": "param1",
                                    "name": "手机"
                                },
                                {
                                    "field": "param2",
                                    "name": "身份证"
                                },
                                {
                                    "field": "param3",
                                    "name": "姓名"
                                }
                            ]
                        },
                        {
                            "name": "凭决定书号缴费（要发票）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "决定书"
                                },
                                {
                                    "field": "param1",
                                    "name": "手机"
                                },
                                {
                                    "field": "param2",
                                    "name": "身份证"
                                },
                                {
                                    "field": "param3",
                                    "name": "姓名"
                                },
                                {
                                    "field": "param4",
                                    "name": "邮寄地址"
                                }
                            ]
                        },
                        {
                            "name": "凭通知书号缴费（不要发票）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "通知书"
                                },
                                {
                                    "field": "param1",
                                    "name": "手机"
                                },
                                {
                                    "field": "param2",
                                    "name": "车辆识别代号"
                                },
                                {
                                    "field": "param3",
                                    "name": "身份证"
                                },
                                {
                                    "field": "param4",
                                    "name": "姓名"
                                }
                            ]
                        },
                        {
                            "name": "凭通知书号缴费（要发票）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "通知书"
                                },
                                {
                                    "field": "param1",
                                    "name": "手机"
                                },
                                {
                                    "field": "param2",
                                    "name": "车辆识别代号"
                                },
                                {
                                    "field": "param3",
                                    "name": "身份证"
                                },
                                {
                                    "field": "param4",
                                    "name": "姓名"
                                },
                                {
                                    "field": "param5",
                                    "name": "邮寄地址"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "汕头市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "湛江市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "肇庆市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "茂名市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "揭阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "梅州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "清远市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "阳江市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "韶关市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "河源市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "云浮市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "汕尾市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "潮州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "台山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "阳春市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "顺德市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "广西壮族自治区",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "广西交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "决定书编号"
                                }
                            ],
                            "desc": "16位编号仅输前15位核对姓名、金额无误后交款。如需打印代收罚款收据，凭处罚决定书到指定网点(详见http://www.ccb.com/gx)补打。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "黑龙江省",
            "cities": [
                {
                    "name": "哈尔滨市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "大庆市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "齐齐哈尔市",
                    "units": [
                        {
                            "name": "交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "违章罚款票据号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "牡丹江市",
                    "units": [
                        {
                            "name": "交通违章罚款（缴费）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "违章罚款票据号"
                                }
                            ],
                            "desc": "暂开通綏芬河市、海林市"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "绥化市",
                    "units": [
                        {
                            "name": "交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "违章罚款票据号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "佳木斯市",
                    "units": [
                        {
                            "name": "交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "违章罚款票据号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "鸡西市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "双鸭山市",
                    "units": [
                        {
                            "name": "交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "违章罚款票据号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "鹤岗市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "黑河市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "伊春市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "七台河市",
                    "units": [
                        {
                            "name": "交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "违章罚款票据号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "内蒙古自治区",
            "cities": [
                {
                    "name": "呼和浩特市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "包头市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "鄂尔多斯市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "通辽市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "呼伦贝尔市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "巴彦淖尔市",
                    "units": [
                        {
                            "name": "巴市交警交通罚款：处罚书号方式",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ],
                            "desc": "请仔细核对处罚决定书号后再缴费，缴费后如要交通违法“罚没款专用收据。”请于15日内到相应交通违法处理机关领取。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "赤峰市",
                    "units": [
                        {
                            "name": "赤峰交警交通罚款：处罚书号方式",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ],
                            "desc": "请仔细核对处罚决定书号后再缴费，缴费后如要交通违法“罚没款专用收据。”请于15日内到相应交通违法处理机关领取。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "乌兰察布市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "锡林郭勒盟市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "兴安盟市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "乌海市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "阿拉善盟市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "海拉尔市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "宁夏回族自治区",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "宁夏区交警队（缴费）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "决定书号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "贵州省",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "贵州交通罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书编号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "山东省",
            "cities": [
                {
                    "name": "滨州",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "德州",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "东营",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "菏泽",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "济南",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "济宁",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "莱芜",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "聊城",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "临沂",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "青岛",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "日照",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "泰安",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "潍坊",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "威海",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "烟台",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "枣庄",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "淄博",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "缴款书号"
                        },
                        {
                            "field": "param1",
                            "name": "校验码"
                        },
                        {
                            "field": "param2",
                            "name": "项目编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "山西省",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "交通违章罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚书编号"
                                }
                            ],
                            "desc": "请不要输入“-”和最后一位数字(例如：140222-1234567890，输入140222123456789)；缴费时间0：00-21：00。成功缴费后，请隔日查询相应罚单是否撤销，避免重复缴费造成损失。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "陕西省",
            "cities": [
                {
                    "name": "西安市",
                    "units": [
                        {
                            "name": "交通违章罚款简单处罚",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚书编号"
                                }
                            ]
                        },
                        {
                            "name": "交通违章罚款现场处罚",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚书编号"
                                }
                            ]
                        },
                        {
                            "name": "交通违章罚款行政处罚",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚书编号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "咸阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "宝鸡市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "渭南市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "汉中市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "榆林市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "延安市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "安康市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "商洛市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "铜川市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "四川省",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "四川交警罚款代收",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ]
                        },
                        {
                            "name": "四川交警罚款代收（手机银行版）",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ],
                            "desc": "该项目仅适用于手机银行新版客户端"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "新疆维吾尔自治区",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "代收交通罚款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "罚单号"
                                }
                            ],
                            "desc": "暂限乌鲁木齐、石河子、克拉玛依、巴州、喀什、塔城、吐鲁番、库车"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "云南省",
            "cities": [
                {
                    "name": "全省通用",
                    "units": [
                        {
                            "name": "云南省交通罚没款缴费",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ],
                            "desc": "缴费支付成功后，交通处罚完成，交通处罚信息实时更新。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "浙江省",
            "cities": [
                {
                    "name": "杭州市",
                    "units": [
                        {
                            "name": "杭州交警罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号码"
                                }
                            ],
                            "desc": "支持杭州市区(不含余杭、桐庐、富阳)交警罚没款，请输10位或16位处罚决定书号码"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "宁波市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "违法人姓名"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "台州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "违法人姓名"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": false,
                    "payOnline": 0
                },
                {
                    "name": "金华市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "违法人姓名"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "舟山市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "违法人姓名"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "衢州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "违法人姓名"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "丽水市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "违法人姓名"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "湖州市",
                    "units": [
                        {
                            "name": "湖州交警罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号码"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "嘉兴市",
                    "units": [
                        {
                            "name": "嘉兴交警罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书编号"
                                }
                            ],
                            "desc": "请输入16位处罚决定书编号，查询核实后缴费。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "绍兴市",
                    "units": [
                        {
                            "name": "绍兴交警罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "罚没收据编号"
                                }
                            ],
                            "desc": "输入16位合同号：交通违法罚没专用收据编号16位"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                },
                {
                    "name": "温州市",
                    "units": [
                        {
                            "name": "温州交警罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号码"
                                }
                            ],
                            "desc": "支持温州各县市区交警罚没款，请输入16位处罚决定编号，罚没款票据次日可到建行营业部领取。咨询电话88080630。"
                        },
                        {
                            "name": "温州市人行横道违章罚没款",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ],
                            "desc": "请输入处罚决定书号，目前只受理温州市区人行道违章处理。"
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        },
        {
            "province": "江苏省",
            "cities": [
                {
                    "name": "苏州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "南京市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "无锡市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "常州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "徐州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "南通市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "扬州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "盐城市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "淮安市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "连云港市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "泰州市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "宿迁市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "镇江市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "沐阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "大丰市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "param1",
                            "name": "车牌号"
                        },
                        {
                            "field": "param2",
                            "name": "发动机号",
                            "placeholder": "发动机号后六位"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "吉林省",
            "cities": [
                {
                    "name": "长春市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                }
            ],
            "valid": true
        },
        {
            "province": "辽宁省",
            "cities": [
                {
                    "name": "沈阳市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "大连市",
                    "needs": [
                        {
                            "field": "photo",
                            "name": "罚单拍照"
                        },
                        {
                            "field": "number",
                            "name": "罚单编号"
                        },
                        {
                            "field": "fine",
                            "name": "处罚金额"
                        },
                        {
                            "field": "penaltyDate",
                            "name": "处罚时间"
                        },
                        {
                            "field": "lateFee",
                            "name": "滞纳金"
                        }
                    ],
                    "valid": true,
                    "payOnline": 0
                },
                {
                    "name": "本溪市",
                    "units": [
                        {
                            "name": "本溪交通罚款缴费",
                            "needs": [
                                {
                                    "field": "number",
                                    "name": "处罚决定书号"
                                }
                            ]
                        }
                    ],
                    "valid": true,
                    "payOnline": 1
                }
            ],
            "valid": true
        }
    ];
});

