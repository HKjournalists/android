require(['lib/zepto.min'], function (a) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('fddj pay completed init');
        renderHeader();
        bindEvents();
    }

    function bindEvents() {
        var toIndex = $('#toIndex');
        toIndex.click(function () {
            Daze.popTo(-99);
        });
    }

    function renderHeader() {
        Daze.setTitle('支付成功');
    }
});