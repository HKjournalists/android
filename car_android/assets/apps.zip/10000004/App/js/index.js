require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'list',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM, list) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        DZ_COM.login(function(){
            DZ_COM.getCurCity(function(){
                init();
            });
        })
    }, false);

    var fddjInfo = null,
        couponList = [],
        payOnline = false;

    var arr = ['苏州市', '无锡市', '常州市', '徐州市', '南通市', '扬州市', '盐城市', '淮安市', '连云港市', '泰州市', '宿迁市', '镇江市', '沐阳市', '大丰市'];

    var $doc = $(document),
        $numberFAQ = $('#numberFAQ'),
        $form = $('#form'),
        $payOnline = $('#payOnline'),
        $province = $('#province'),
        $city = $('#city'),
        $itemUnit = $('#itemUnit'),
        $unit = $('#unit'),
        $toggleContent = $('#toggleContent'),
        $btnSubmit = $('#btnSubmit'),

        $wrapSelectCoupon = $('#wrapSelectCoupon'),
        $listCoupon = $('#listCoupon'),
        $btnOrder = $('#btnOrder'),

        $paymentLink = $('#paymentLink');

    function init() {
        renderHeader();
        renderProvince();
        bindEvents();
        ga_storage._trackPageview('carService/fddj/index', "汽车服务-罚款代缴-首页");
    }

    function bindEvents() {
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });

        $form.on('click', '.ipt', function () {
            $wrapSelectCoupon.addClass('hidden');
        });

        $form.on('input', '.ipt', function () {
            renderBtn();
        });

        $form.on('click', '.item-photo', function () {
            Daze.photo({
                type: 6
            }, function (o) {
                if (!o.url) {
                    return false;
                }

                var $img = $('#photo'),
                    $takeAnew = $('#takeAnew');

                $img.attr('src', o.url);
                DZ_COM.setImg($img, 32, 32);
                $takeAnew.removeClass('hidden');
                renderBtn();
            });
        });

        $form.on('input', '#fine', function () {
            renderLateFee();
        });

        $form.on('input', '#penaltyDate', function () {
            var penaltyDate = +new Date($(this).val()),
                date = +new Date();
            if (date < penaltyDate) {
                $(this).val(getCurDate());
            }
            renderLateFee();
        });

        $province.change(function () {
            renderCity();
            renderBtn();
        });

        $city.change(function () {
            renderUnit();
            renderBtn();
        });

        $unit.change(function () {
            renderNeeds();
            renderBtn();
        });

        $numberFAQ.click(function () {
            $(this).find('.tpl').removeClass('hidden');
            return false;
        });

        $numberFAQ.find('.tpl').click(function () {
            $(this).addClass('hidden');
            return false;
        });

        $doc.on('click', '.view-tpl', function () {
            $(this).find('.tpl').removeClass('hidden');
        });

        $doc.on('click', '.tpl', function () {
            $(this).addClass('hidden');
        });

        $form.on('input', '#param1', function () {
            if ($.inArray($city.val(), arr) != -1) {
                var val = $(this).val();
                if (val.length > 7) {
                    $(this).val(val.slice(0, 7));
                }
                else if (val.length < 7) {
                    renderBtn();
                }
            }
        });

        $form.on('input', '#param2', function () {
            if ($.inArray($city.val(), arr) != -1) {
                var val = $(this).val();
                if (val.length > 6) {
                    $(this).val(val.slice(0, 6));
                }
                else if (val.length < 6) {
                    renderBtn();
                }
            }
        });

        $btnSubmit.click(function () {
            DZ_COM.login(function () {
                submitHandler();
                ga_storage._trackEvent('汽车服务-罚款代缴-首页', '点击', '去缴罚款');
            });
        });

        $listCoupon.click(function () {
            Daze.showSelectWin(couponList, function (coupon) {
                if (tool.isEmpty(coupon)) {
                    couponReset();
                }
                else {
                    couponSelected(coupon);
                }
            });
        });

        $btnOrder.click(function () {
            addOrder();
            ga_storage._trackEvent('汽车服务-罚款代缴-首页', '点击', '提交订单');
        });

        $('.js_demo-cfpic-show').on('click', function () {
            $('#demo-cfpic').find('.tpl').removeClass('hidden')
        });

        $('.js_must-know-show').on('click', function () {
            $('#must-know').find('.tpl').removeClass('hidden')
        });

        $('#must-know').on('click', '.tpl', function () {
            $(this).addClass('hidden')
        });
        $('#demo-cfpic').on('click', '.tpl', function () {
            $(this).addClass('hidden')
        });

        // 分享
        $paymentLink.click(function () {
            Daze.share({
                from: 42,
                type: 42,
                to: '2'
            });
        })
    }

    function renderHeader() {
        Daze.setTitle('罚款代缴');
    }

    function renderProvince() {
        $province.empty();

        var curCity = storage.getGlobalData().curCity,
            city = curCity && curCity.name,
            province = curCity && curCity.province,
            flag = false;

        for (var i = 0; i < list.length; i++) {
            if (list[i].valid) {
                if (list[i].province.indexOf(province) >= 0) {
                    flag = true;
                    province = list[i].province;
                }

                var option = $('<option>');
                option.text(list[i].province).val(list[i].province);
                option.appendTo($province);
            }
        }

        if (flag) {
            $province.val(province);
        }

        renderCity(city);
    }

    /**
     * @method getCityByProvince
     * @description 根据省份获取城市列表
     * @returns {*}
     */
    function getCityByProvince() {
        var cities = [],
            result = [];
        for (var i = 0; i < list.length; i++) {
            if (list[i].province == $province.val()) {
                cities = list[i].cities;
            }
        }
        for (var j = 0; j < cities.length; j++) {
            if (cities[j].valid) {
                result.push(cities[j]);
            }
        }
        return result;
    }

    function renderCity(city) {
        $city.empty();

        var flag = false;

        var cities = getCityByProvince();
        for (var i = 0; i < cities.length; i++) {
            if (cities[i].name.indexOf(city) >= 0) { // 优先使用定位城市
                flag = true;
                city = cities[i].name;
            }

            var option = $('<option>');
            option.text(cities[i].name).val(cities[i].name);
            option.appendTo($city);
        }

        if (flag) {
            $city.val(city);
        }

        renderUnit();
    }

    function getUnit() {
        for (var i = 0; i < list.length; i++) {
            if (list[i].province == $province.val()) {
                var cities = list[i].cities;
                for (var j = 0; j < cities.length; j++) {
                    if (cities[j].name == $city.val()) {
                        payOnline = cities[j].payOnline;
                        return cities[j].units || [];
                    }
                }
            }
        }
        return [];
    }

    function renderUnit() {
        $unit.empty();
        var units = getUnit();
        if (payOnline) {
            for (var i = 0; i < units.length; i++) {
                var option = $('<option>');
                option.text(units[i].name).val(units[i].name);
                option.appendTo($unit);
            }
            $itemUnit.removeClass('hidden');
        }
        else {
            $unit.empty();
            $itemUnit.addClass('hidden');
        }
        $payOnline.val(payOnline);
        // if (payOnline) {
        $('.js_notice-show').on('click', function () {
            $(this).toggleClass('rotate')
            $('.notice-online').toggleClass('hidden');
        })
        // }
        renderNeeds();
    }

    function getNeeds() {
        for (var i = 0; i < list.length; i++) {
            if (list[i].province == $province.val()) {
                var cities = list[i].cities;
                for (var j = 0; j < cities.length; j++) {
                    if (cities[j].name == $city.val()) {
                        var payOnline = cities[j].payOnline;
                        if (payOnline) {
                            var units = cities[j].units;
                            for (var k = 0; k < units.length; k++) {
                                if (units[k].name == $unit.val()) {
                                    return {
                                        needs: units[k].needs,
                                        desc: units[k].desc,
                                        payOnline:true
                                    }
                                }
                            }
                        }
                        else {
                            return {
                                needs: cities[j].needs,
                                payOnline:false
                            }
                        }
                    }
                }
            }
        }
        return [];
    }

    function renderNeeds() {
        var obj = getNeeds();
        $toggleContent.html(template('toggleItemTmpl', {
            needs: obj.needs,
            desc: obj.desc,
            city: $city.val(),
            province: $province.val(),
            payOnline:obj.payOnline
        }));

        if ($province.val() == "山东省") {
            $('.item-lateFee').addClass("hidden")
            $('.item-penaltyDate').after('<p style="text-align:center;padding-top:10px;">超过15天的罚款，无法缴纳，请勿下单</p>')
        }
        if (!payOnline) {
            $('#penaltyDate').val(getCurDate());
            renderLateFee();
        }
    }

    function renderLateFee() {
        var data = getFormData(),
            penaltyDate = +(new Date(data.penaltyDate)),
            date = +new Date(),
            dis = 0,
            extra = 0,
            lateFee = 0;
        var $lateFee = $('#lateFee');

        if (data.fine && penaltyDate) {
            dis = Math.ceil((date - penaltyDate) / (24 * 3600 * 1000));
            if (dis > 15) {
                extra = dis - 15;
                lateFee = tool.convertNumber(data.fine * 0.03 * extra);
                lateFee = lateFee > data.fine ? data.fine : lateFee;
                $lateFee.val(lateFee);
            }
            else {
                $lateFee.val(0);
            }
        }
        else {
            $lateFee.val(0);
        }
    }

    function getCurDate() {
        var d = new Date(),
            year = d.getFullYear(),
            month = d.getMonth() + 1,
            date = d.getDate();
        return year + '-' + month + '-' + date;
    }

    function getFormData() {
        var o = {};
        var items = $form.serializeArray();
        $.each(items, function (i, item) {
            o[item.name] = item.value;
        });

        //add photo
        o.payOnline = Number(o.payOnline);
        if (o.payOnline == 0) {
            var photoUrl = $('#photo').attr('src');
            o.url = photoUrl;
        }

        return o;
    }

    function validateForm() {
        var data = getFormData(),
            eligible = true,
            msg = '';
        if (!data.province) {
            eligible = false;
            msg = '请选择省份';
        }
        else if (!data.city) {
            eligible = false;
            msg = '请选择城市';
        }
        else {
            if (data.payOnline) {//支持罚单在线代缴服务
                if (!data.unit) {
                    eligible = false;
                    msg = '请选择收费单位';
                }
                else if (!data.number && data.province != '山东省') {
                    eligible = false;
                    msg = $('#number').attr('placeholder');
                }
                else {
                    for (var i in data) {
                        if (i.indexOf('param') >= 0 && !data[i]) {
                            eligible = false;
                            msg = $('input[name=' + i + ']').attr('placeholder');
                        }
                    }
                }
            }
            else {//人工服务
                if (!data.url) {
                    eligible = false;
                    msg = '请上传罚单照片';
                }
                else {
                    for (var i in data) {
                        if (!data[i] && i != 'payOnline' && i != 'lateFee' && i != 'unit') {
                            eligible = false;
                            if (i == 'fine') {
                                msg = '请输入处罚金额';
                            }
                            else if (i == 'penaltyDate') {
                                msg = '请选择处罚时间';
                            }
                            else if (i.indexOf('param') >= 0) {
                                msg = $('input[name=' + i + ']').attr('placeholder');
                            }
                        }
                        else if ($.inArray(data.city, arr) != -1 && i == 'param1' && data[i].length != 7) {
                            eligible = false;
                            msg = '请输入正确的车牌号';
                        }
                    }
                }
            }
        }

        return {
            data: data,
            eligible: eligible,
            msg: msg
        }
    }

    function renderBtn() {
        var eligible = validateForm().eligible;
        if (eligible) {
            $btnSubmit.removeAttr('disabled');
        }
        else {
            $btnSubmit.attr('disabled', 'disabled');
        }
    }

    function submitHandler() {
        var result = validateForm();
        if (result.eligible) {
            DZ_COM.checkNetwork(null, function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });

                var data = result.data,
                    extraParam = {};
                data.ver = 2;
                for (var i in data) {
                    if (i.indexOf('param') >= 0) {
                        extraParam[i] = data[i];
                        delete data[i];
                    }
                }

                if (data.url) {
                    extraParam.url = data.url;
                    delete  data.url;
                }

                if (!tool.isEmpty(extraParam)) {
                    data.extraParam = extraParam;
                }

                $.ajax({
                    url: host.HOST_URL + '/penalty/getPenaltyInfo.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(data),
                    success: function (r) {
                        if (r.code == 0) {
                            var canPay = Number(r.data.canPay);
                            if (canPay) {
                                fddjInfo = r.data;
                                getCouponList();
                            }
                            else {
                                Daze.showMsg('提交成功');
                                setTimeout(function () {
                                    location.reload();
                                }, 2100);
                            }
                        }
                        else {
                            if (r.code == 1) {
                                Daze.showMsg(r.msg);
                            }
                            else {
                                Daze.showMsg('查询罚单金额失败');
                            }
                            return false;
                        }
                        ga_storage._trackEvent('汽车服务-罚款代缴-首页', 'penalty/getPenaltyInfo.htm', '成功');
                    },
                    error: function () {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-罚款代缴-首页', 'penalty/getPenaltyInfo.htm', '失败');
                    }
                });
            });
        }
        else {
            Daze.showMsg(result.msg);
        }
    }

    function getCouponList() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var params = {
            orderTypeId: 3,
            uid: storage.getGlobalData().uid,
            price: Number(fddjInfo.penalty.fine)
        };
        $.ajax({
            url: host.HOST_URL + '/coupon/getValidList.htm',
            type: 'post',
            data: DZ_COM.convertParams(params),
            success: function (r) {
                var list = [];
                if (r) {
                    if (r.code == 0) {
                        list = r.data.list;
                    }
                    else {
                        Daze.showMsg(r.msg);
                    }
                }
                renderSelectCoupon(list);
                ga_storage._trackEvent('汽车服务-罚款代缴-首页', 'coupon/getValidList.htm', '成功');
            },
            error: function () {
                DZ_COM.renderNetworkTip(null, 1);
                ga_storage._trackEvent('汽车服务-罚款代缴-首页', 'coupon/getValidList.htm', '失败');
            }
        });
    }

    function renderSelectCoupon(list) {
        var serviceName = '罚款代缴';

        $wrapSelectCoupon.find('.service .value').text(serviceName);
        if (fddjInfo.penalty.unit) {
            $wrapSelectCoupon.find('.item-money .key span').text('(' + fddjInfo.penalty.unit + ')');
        }
        $wrapSelectCoupon.find('.item-money .price').text(fddjInfo.penalty.fine);
        if (fddjInfo.penalty.lateFee) {
            $('.item-late-fee').show();
            $wrapSelectCoupon.find('.item-late-fee .price').text(fddjInfo.penalty.lateFee);
        }
        else {
            $('.item-late-fee').hide();
        }
        if (fddjInfo.costPrice) {
            $('.item-service-money').show();
            $wrapSelectCoupon.find('.item-service-money .price').text(fddjInfo.costPrice);
            if (fddjInfo.costPercent) {
                $wrapSelectCoupon.find('.item-service-money .value span.caption').text('(' + fddjInfo.costPercent + '%(罚款金额+滞纳金))');
            }
        }
        else {
            $('.item-service-money').hide();
        }
        couponReset();

        for (var i = 0; i < list.length; i++) {
            if (list[i].name == 'benjin') {
                couponList = list[i].list || [];
            }
        }
        if (list.length && couponList.length) {
            for (var j = 0; j < couponList.length; j++) {
                couponList[j].endTime = couponList[j].endTime.split(' ')[0];
            }
            $listCoupon.show();

            //排序
            couponList.reverse();

            //默认选中最近到期的代金券
            couponSelected(couponList[0]);
        }
        else {
            couponList = [];
            $listCoupon.hide();
        }

        $wrapSelectCoupon.removeClass('hidden');

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function couponReset() {
        $listCoupon.attr({
            'data-id': 0
        }).text('请选择代金券');
        $wrapSelectCoupon.find('.coupon-price').text('');
        $wrapSelectCoupon.find('.order-money span').text(fddjInfo.price);
    }

    function couponSelected(coupon) {
        $listCoupon.attr({
            'data-id': coupon.id
        }).text(coupon.name + '(' + coupon.endTime + ')');
        $wrapSelectCoupon.find('.coupon-price').text(' -' + coupon.amount);
        var money = fddjInfo.price - coupon.amount > 0 ? tool.convertNumber(fddjInfo.price - coupon.amount) : 0.01;
        $wrapSelectCoupon.find('.order-money span').text(money);
    }

    function addOrder() {
        var globalData = storage.getGlobalData(),
            params = {
                pid: globalData.pid,
                uid: globalData.uid,
                userId: globalData.userId,
                penaltyId: fddjInfo.penalty.id
            };

        var couponId = $listCoupon.data('id');
        if (couponId) {
            params.couponId = {
                benjin: couponId
            };
        }

        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                type: 'POST',
                url: host.HOST_URL + '/penalty/add.htm',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    if (r.code == 0) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });

                        setTimeout(function () {
                            location.reload();
                        }, 100);
                        Daze.pushWindow({
                            appId:'10000009',
                            url:'detail.html?orderId='+r.data.orderId
                        });
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-罚款代缴-首页', 'penalty/add.htm', '成功');
                },
                error: function () {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-罚款代缴-首页', 'penalty/add.htm', '失败');
                }
            });
        });
    }
});
