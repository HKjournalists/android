/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function(a, b, host, tool, storage, DZ_COM) {
    var domId = 'mainBox',
        $mainBox = $('#mainBox'),
        _query = tool.getQueryString();

    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        DZ_COM.login(function() {
            DZ_COM.getCurCity(function() {
                init();
            });
        });
    }, false);

    function init() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        if(!_query.code && !_query.name){
            Daze.popTo(-1);
            return;
        }
        renderHeader(_query.name);
        renderContent(_query.code);
        ga_storage._trackPageview('cmuber/index', "汽车服务-车猫Uber-我要卖车");
    }

    function renderHeader(name) {
        Daze.setTitle(name+'介绍');
    }

    function renderContent(type){
        $mainBox.html(template('myTemplate',{
            type : type
        }));
        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

});
