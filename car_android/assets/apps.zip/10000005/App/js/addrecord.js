require([
    'lib/zepto.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common', 
    'com/GALocalStorage',
    'lib/mobiscroll.min'
], function (a,host, tool, storage, DZ_COM) {
    var $btnsubmit = $('.btn-origin'),
        $gasTime =  $("#gasTime"),
        $gasAmount = $("#gasAmount"),
        $gasAddress = $("#gasAddress"),
        today =getToday();
        var date = new Date();
        var year = date.getFullYear();
        var curCity = storage.getGlobalData().curCity;
         //var curCity = [{id:92,name:'杭州',province:'浙江'}];
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
        
    }, false);
    function init() {
        renderHeader();
        //DZ_COM.login(function () {
        bindEvents();
        // timereload();
        $gasTime.val(today);
        //});
        // var curr = new Date().getFullYear();
        // var fun = function () {
        //     $('#gasTime').scroller('destroy').scroller({
        //         preset: 'date',
        //         //invalid: { daysOfWeek: [0, 6], daysOfMonth: ['5/1', '12/24', '12/25'] },
        //         theme: 'android-ics light',
        //         mode: 'scroller',
        //         lang: 'zh',
        //         display: 'bottom'
        //     });
        // }
        // fun();
        ga_storage._trackPageview('carService/ykcz/index', "汽车服务-加油卡充值-首页");
        //时间设置
        $gasTime.mobiscroll().date({
            theme:'android-ics light',
            mode:'scroller',
            lang: 'zh',
            display:'bottom',
            startYear:2015,
            endYear:year,

        });
    }
    function bindEvents() {
        // $gasTime.on({
        //     focus:function(){

        //     }
        // })
        $btnsubmit.on({
            click:function(){
                var gasTime = $gasTime.val();
                var gasAmount = $gasAmount.val();
                var gasAddress = $gasAddress.val();
                var forminfy= false;
                if (gasAmount.length==0) {
                    Daze.showMsg('请添加金额');
                }else if (gasTime.length==0) {
                    Daze.showMsg('请添加时间');
                }else {
                    DZ_COM.checkNetwork(null, function () {
                        Daze.showMsg({
                            type: 'loading',
                            visible: true
                        });
                        $.ajax({
                            type:"post",
                            url:host.HOST_URL+"/gas/addRecord.htm",
                            data:DZ_COM.convertParams({
                                cityId:curCity.id,
                                uid:storage.getUid(),
                                gasTime:gasTime,
                                gasAmount:gasAmount,
                                gasAddress:gasAddress
                            }),
                            dataType:"json",
                            success:function(data){
                                Daze.showMsg({
                                    type: 'loading',
                                    visible: false
                                })
                                $btnsubmit.removeAttr("disabled");
                                Daze.showMsg('添加成功');
                                Daze.pushWindow('record.html');
                               

                            },
                            error:function(){

                            }
                        })
                    }) 
                }
            }
        })
        
        /*var lbsGeo = document.getElementById('lbs-geo');
        //监听定位失败事件 geofail  
        lbsGeo.addEventListener("geofail",function(evt){ 
            Daze.showMsg("获取位置失败……");
        });
        //监听定位成功事件 geosuccess
        lbsGeo.addEventListener("geosuccess",function(evt){ 
            console.log(evt.detail);
            var address = evt.detail.address;
            var coords = evt.detail.coords;
            var x = coords.lng;
            var y = coords.lat;
            Daze.showMsg("地址："+address);
        });*/
    }
    function renderHeader() {
        Daze.setTitle('添加记录');
    }
    // function timereload() {
    //     $("#gasTime").mobiscroll().date({
    //         theme: theme,     
    //         mode: mode,       
    //         display: display, 
    //         lang: lang   
    //     })
    // }
    function getToday() {
            var date = new Date(), day = date.getDate(), month = date.getMonth() + 1, year = date.getFullYear();

            if (month < 10) month = "0" + month;
            if (day < 10) day = "0" + day;

            return year + "-" + month + "-" + day;
        }


});