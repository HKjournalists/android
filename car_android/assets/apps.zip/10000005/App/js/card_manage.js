require([
    'lib/zepto.min',
    'lib/vue',
    'lib/vue-validator',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, Vue, validator, host, tool, storage, DZ_COM) {


    document.addEventListener("DazeJSObjReady", function () {

        DZ_COM.login(function(){
            init();
        })
    }, false);

    function init() {

        Daze.setTitle('管理油卡');
        render()
        ga_storage._trackPageview('carService/ykcz/index', "汽车服务-加油卡充值-首页");
    }

    function render(){
        // Vue.use(validator)
        document.addEventListener('daze_followEvent', function(){
            location.reload()
        });
        Daze.system.addObserver({name: 'daze_followEvent'});

        var card_manage = new Vue({
            el: ".card-manage",

            data: {
                cardData:null,
                renderOver:false
            },

            created: function(){
                this.getData()
            },
            ready:function(){
                this.renderOver = true;
            },

            filters: {
                numSplit: function(value) {
                    return value.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 ");
                },
                type2text:function(value){
                    if(value == 0){
                        return '中石化'
                    }
                    else{
                        return '中石油'
                    }
                }
            },

            methods: {
                showLoading:function(){
                    console.log(1)
                    Daze.showMsg({
                        type: 'loading',
                        visible: true
                    });
                },

                hideLoading:function(){
                    console.log(2)
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                },
                goEdit:function(item){
                    Daze.pushWindow('card_edit.html?id='+ item.id +'&cardNum='+ item.cardNum +'&type='+ item.type +'&owner='+ item.owner +'&isDefault='+ item.isDefault);
                },
                goAdd:function(item){
                    Daze.pushWindow('card_add.html');
                },
                updateData:function(){
                    this.cardData.name = 'vue'
                    this.$log()
                },
                getData:function(){
                    var self = this

                    self.showLoading()
                    $.ajax({
                        type:"get",
                        url:host.HOST_URL + '/userCard/getOilCards.htm',
                        data:DZ_COM.convertParams({
                            uid:storage.getUid()
                        }),
                        dataType:"json",
                        success:function(data){
                            self.cardData = data.data
                            self.hideLoading()
                        },
                        error:function(){

                        }
                    })
                }
            }

        })
    }
});
