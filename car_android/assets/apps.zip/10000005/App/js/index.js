require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/city-list',
    'com/modules/city',
    'com/modules/banner',
    'lib/underscore',
    './popmodal',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM, list, module_city, module_banner) {

    var //$info = $('#info'),
        $form = $('#form'),
        $chooseCity = $('#chooseCity'),
        $handerMoney = $('#handerMoney'),
        $zkList = $('li i', $handerMoney),
        $OilPrices = $('#OilPrices'),
        $selectType = $('#selectType'),
        $selProvince = $('#selProvince'),
        $itemCardNoOfSH = $('#itemCardNoOfSH'),
        $itemCardNoOfSY = $('#itemCardNoOfSY'),
        $cardNoOfSH = $('#cardNoOfSH'),
        $cardNoOfSY = $('#cardNoOfSY'),
        $recordsOfSH = $('#recordsOfSH'),
        $recordsOfSY = $('#recordsOfSY'),
        $itemRepeat = $('#itemRepeat'),
        $repeatCardNo = $('#repeatCardNo'),
        $itemOwner = $('#itemOwner'),
        $owner = $('#owner'),
        $prePaidMoney = $('#prePaidMoney'),
    //$payMoney = $('#payMoney'),
        $btnPay = $('#btnPay'),
        $instructionOfSH = $('#instructionOfSH'),
        $instructionOfSY = $('#instructionOfSY'),
        $checkbox = $('#checkbox'),
        $showAgreement = $('#showAgreement'),
        $wrapSelectCoupon = $('#wrapSelectCoupon'),
        $showServiceDetail = $('#showServiceDetail'),
        $listCoupon = $('#listCoupon'),
        $recordBtn = $('#recordBtn'),
        $btnOrder = $('#btnOrder');

    var provinces = [],
        zk_oil = [[0, 0, 0, 0], [0, 0, 0, 0]],//1000 500 200 100
        _init_flag = false,
        zshHaszk = false,
        _etype = 0,
        yhq = false,
        gettingCardInfo = false,
        orderMoney = $prePaidMoney.val(),
        couponList = [],
        type = 0; // 0：中国石化；1：中国石油
    var serviceId = 10,
        serviceName = '加油卡充值',
        countnum = 0;
    var curCity = storage.getGlobalData().curCity;

    // alert(curCity)

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        document.addEventListener('daze_followEvent', function(e){
            location.reload()
        });

        DZ_COM.login(function(){
            DZ_COM.getCurCity(function(){
                init();
            });
        })
    }, false);

    function init() {
        console.log(storage.getCurCity())
        FastClick.attach(document.body);
        renderHeader();
        // DZ_COM.login(function () {
            // module_city.getCurrentCity(function (isSuccess) {
                // debugger
                // if (isSuccess) {
                    renderContent();
                // }
            // });
            // alert('uid:'+storage.getUid())
            // getProvince();
            recodNum();
            // getCardRecord(0);
            // getCardRecord(1);
            bindEvents();
            // alert('uid2222222222:'+storage.getUid())
        // });
        ga_storage._trackPageview('carService/ykcz/index', "汽车服务-加油卡充值-首页");
    }

    function recodNum() {

        //获取加油记录
        var cardTmpl = _.template($('#card-info').html())


        $.ajax({
            type:"post",
            url:host.HOST_URL + "/userCard/getOilCards.htm",
            data:DZ_COM.convertParams({
                cityId:storage.getGlobalData().curCity,
                orderTypeId:4,
                uid:storage.getUid()
            }),
            dataType:"json",
            success:function(data){
                if (data.code==0) {
                    // data.data.list = []
                    if(data.data.list.length){
                        $('#showServiceDetail').css('display','block')
                        type = data.data.list[0].type
                        $('.js_card-info').attr('data-type',data.data.list[0].type)
                        $('.js_card-info').find('.js_user-name').text(data.data.list[0].owner)
                        $('.js_card-info').find('.js_card-num').text(data.data.list[0].cardNum.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 "))
                        _.each(data.data.list,function(item){
                            item.splitNum = item.cardNum.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 ");
                            if(item.isDefault == true){
                                type = item.type
                                $('.js_card-info').attr('data-type',item.type)
                                $('.js_card-info').find('.js_user-name').text(item.owner)
                                $('.js_card-info').find('.js_card-num').text(item.cardNum.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 "))
                            }
                        })
                        console.log(data.data.list)
                        var cardHtml = cardTmpl({cardInfo : data.data.list})
                        var _cardNum = ''
                        $('.js_card-html').html(cardHtml)
                        $('.js_card-info').addClass('show')
                        if($('#modal-becoming .index-card-info.select').length > 0){
                            _cardNum = $('#modal-becoming .index-card-info.select .js_card-num').attr('data-num')
                        }
                        getDiscountAmount(_cardNum)
                        typeHandle(type)

                    }
                    else{
                        $('.js_no-card').addClass('show')
                        $('#showServiceDetail').css('display','none')

                    }
                };

            },
            error:function(){
                Daze.showMsg('请求数据失败！')
            }
        })

        $('.js_card-manage').on('click',function(){
            Daze.system.addObserver({name: 'daze_followEvent'});
        })
        $('.js_no-card').on('click',function(){
            Daze.system.addObserver({name: 'daze_followEvent'});
            Daze.pushWindow('card_add.html')
        })

    }

    function oilPrice() {//显示油价
        var curCity = storage.getCurCity();
        $chooseCity.find('.item_city').html(curCity.name);
        $.ajax({
            url: host.HOST_URL + '/data/getOilPrice.htm',
            type: 'post',
            data: DZ_COM.convertParams({
                cityId: curCity.id
            }),
            beforeSend: function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
            },
            success: function (r) {
                if (r.code == 0) {
                    resulutFn(r.data);
                } else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            },
            error: function () {
                resulutFn();
            },
            complete: function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
            }
        });
        function resulutFn(obj) { //结果处理
            obj = obj || {"list": [{"oilType": "93"}, {"oilType": "95"}]};
            $OilPrices.find('.oil-info').each(function (index) {
                this.getElementsByTagName('h5')[0].innerHTML = obj.list[index].oilType + '#';
                this.getElementsByTagName('P')[0].innerHTML = !obj.list[index].price ? '?' : obj.list[index].price;
            });
        }
    }

    function bindEvents() {
        $handerMoney.on({//价格选择
            click: function () {
                var _price = $(this).data('price'),
                    index = $(this).index();
                _etype = index;
                $(this).addClass('active').siblings('li').removeClass('active');
                $prePaidMoney.val(_price);
            }
        }, 'li').children().first().trigger('click');


        // $chooseCity.click(function () {//点击切换城市
        //     module_city.init();
        // });
        // document.addEventListener('selectEvent', function () {//选择城市后
        //     renderContent();
        // });

        $(document).click(function (e) {
            var parentNode = e.target.parentNode.className;
            var isHidden = $wrapSelectCoupon.hasClass('hidden');
            if (!isHidden && parentNode != 'wrap-select-coupon') {
                $wrapSelectCoupon.addClass('hidden');
                $btnPay.removeAttr('disabled');
            }
        });

        $selectType.on('click', 'li', function () {//选项卡切换
            var isCur = $(this).hasClass('active'),
                index = $(this).index(),
                dl = $showServiceDetail.find('dl');
            if (!isCur && $(this).data('type') != 2) {
                type = $(this).data('type');
                getDiscountAmount();
                //reset form
                $(this).addClass('active').siblings().removeClass('active');
                dl.hide().eq(index).show();
                $form[0].reset();
                $btnPay.attr('disabled', true);
                $itemRepeat.addClass('hidden');
                $wrapSelectCoupon.addClass('hidden');
                switch (type) {
                    case 0://石化
                        $itemCardNoOfSH.removeClass('hidden');
                        $itemCardNoOfSY.addClass('hidden');
                        $instructionOfSH.removeClass('hidden');
                        $instructionOfSY.addClass('hidden');
                        $itemOwner.addClass('hidden');
                        $owner.attr({
                            'readonly': true,
                            'placeholder': ''
                        });
                        break;
                    case 1://石油
                        $itemCardNoOfSH.addClass('hidden');
                        $itemCardNoOfSY.removeClass('hidden');
                        $instructionOfSH.addClass('hidden');
                        $instructionOfSY.removeClass('hidden');
                        $itemRepeat.removeClass('hidden');
                        $itemOwner.removeClass('hidden');
                        $owner.attr('placeholder', '请输入持卡人').removeAttr('readonly').val('');
                        break;
                }
                renderProvince();
                ga_storage._trackEvent('汽车服务-加油卡充值-首页', '点击', $(this).text());
            }else if ($(this).data('type') == 2) {//油卡记录
                //去除显示的消息数量
                Daze.pushWindow('record.html');
            }
            else {
                return false;
            }
        });

        $showServiceDetail.on({
            click: function () {
                var type = this.getAttribute('data-type'), url = '';
                if (type == 0) {
                    url = 'service-detail-zsh.html';
                }
                else if (type == 1) {
                    url = 'service-detail-zsy.html';
                }
                Daze.pushWindow(url);
            }
        }, '.show-service-detail');

        $selProvince.change(function () {//省份切换
            var province = $(this).val();

            $form[0].reset();
            if (type == 0) {
                $itemOwner.addClass('hidden');
            }
            $wrapSelectCoupon.addClass('hidden');
            $selProvince.val(province);
            renderBtn();
        });

        $cardNoOfSH.on('focus', function () {//石化加油卡号历史记录
            $wrapSelectCoupon.addClass('hidden');
            var records = storage.getGlobalData().cardNosOfSH;
            if (records && records.length) {
                $recordsOfSH.find('li').remove();
                for (var i = 0; i < records.length; i++) {
                    var li = $('<li>').text(records[i]);
                    $recordsOfSH.prepend(li);
                }
                $recordsOfSH.removeClass('hidden');
            }
            return false;
        });

        $cardNoOfSY.on('focus', function () {//石油加油卡号历史记录

            var records = storage.getGlobalData().cardNosOfSY;
            var nums = $(this).val().length;
            $wrapSelectCoupon.addClass('hidden');
            if (records && records.length) {
                $itemRepeat.css("margin-top",(records.length+1)*40);
                $recordsOfSY.find('li').remove();
                for (var i = 0; i < records.length; i++) {
                    var li = $('<li>').text(records[i]);
                    $recordsOfSY.prepend(li);
                }
                $recordsOfSY.removeClass('hidden');
            }
            return false;
        });
        $cardNoOfSH.on('blur', function () {
            var val = this.value;
            if (/^[0-9]{19}$/.test(val)) {
                getDiscountAmount(val);
            }
            setTimeout(function () {
                $recordsOfSH.addClass('hidden');
            }, 200);
            renderBtn();
        });

        $repeatCardNo.on('blur', function () {
            var val = this.value;
            if (/^[0-9]{16}$/.test(val)) {
                getDiscountAmount(val);
            }
            renderBtn();
        });


        // $cardNoOfSY.on('blur', function () {
        //         $recordsOfSY.addClass('hidden');
        //     // setTimeout(function () {
        //         $itemRepeat.css("margin-top",'1px');
        //     // }, 200);

        // });

        $cardNoOfSH.on('input', function () {
            var cardNo = $(this).val(),
                result = validate();
                this.value =this.value.replace(/\s/g,'').replace(/(\d{4})(?=\d)/g,"$1 ");
                console.log(cardNo.length)
                var noSpaceCardNo = cardNo.replace(/\s/g,'')
            if (/^([0-9]|\s)*$/.test(cardNo)) {
                if (cardNo.length == 23) {
                    $(this).blur();
                    if (type == 0) {
                        if (!gettingCardInfo) {
                            gettingCardInfo = true;
                            getCardNoInfo(noSpaceCardNo);
                            renderBtn();
                        }
                        else {
                            Daze.showMsg("正在获取油卡信息，请稍侯");
                        }
                    }
                }
            }
            else {
                $itemOwner.addClass('hidden');
                if (result.msg) {
                    console.log(result.msg)
                    // Daze.showMsg(result.msg);
                }
            }
        });
        //输入16位数字后显示确认卡号
        // $cardNoOfSY.on('keyup', function () {


        //     countnum = $(this).val().length;
        //     console.log(countnum);

        //     if (countnum == 16) {

        //         var i =$recordsOfSY.find("li").length+1;

        //         $itemRepeat.removeClass('hidden');
        //         $itemRepeat.css("margin-top",i*40);
        //     }else {
        //         $itemRepeat.addClass('hidden');
        //     }
        // });

        $cardNoOfSY.on('blur', function () {
            var cardNo = $(this).val();

            if (/^[0-9]*$/.test(cardNo)) {
                /*if (cardNo.length == 16) {
                    //$(this).blur();
                    if (type == 1) {
                        saveCardNo(cardNo);

                        //countnum  = 0;
                        //$itemRepeat.removeClass('hidden');
                    }
                }*/
                renderBtn();
            }
            else {
                //$itemRepeat.addClass('isHidden');
                // $recordsOfSY.addClass('hidden');
                // $itemRepeat.css("margin-top","1px");
                Daze.showMsg('加油卡号为16位数字');
            }
            setTimeout(function(){
                            $recordsOfSY.addClass('hidden');
                        },1);
            $itemRepeat.css("margin-top","1px");
        });
        // 确认加油卡号
        $repeatCardNo.on('input', function () {

            var repeatCardNo = $(this).val();
            if (/^\d{16}$/.test(repeatCardNo)) {
                var result = validate();
                if (!result.eligible) {
                    Daze.showMsg(result.msg);
                }
                renderBtn();
            }
        });


        // 加油卡号历史记录
        $recordsOfSH.on('click', 'li', function () {
            var cardNo = $(this).text();
            $cardNoOfSH.val(cardNo);
            getCardNoInfo(cardNo);
            getDiscountAmount(cardNo);
            renderBtn();
        });

        $recordsOfSY.on('click', 'li', function () {
            var cardNo = $(this).text();
            $cardNoOfSY.val(cardNo);
            getDiscountAmount(cardNo);
            //$itemRepeat.removeClass('hidden');
            $recordsOfSY.addClass('hidden');
            $itemRepeat.css("margin-top","1px");
        });

        $recordsOfSH.on('click', '#clearSH', function () {
            storage.removeInfo('cardNosOfSH');
            $recordsOfSH.addClass('hidden');
        });

        $recordsOfSY.on('click', '#clearSY', function () {
            storage.removeInfo('cardNosOfSY');
            $recordsOfSY.addClass('hidden');
            $itemRepeat.css("margin-top","1px");
        });

        $itemOwner.on('input', function () {
            renderBtn();
        });

        $btnPay.click(function () {
            // var result = validate();
            // if (result.eligible) {
                var _cardname = $('.js_card-info').find('.js_user-name').text()
                var _cardnum = $('.js_card-info').find('.js_card-num').text()

                if(_cardname == '' && _cardnum == '' ){
                    Daze.showMsg('请选择油卡');
                    return
                }
                $btnPay.attr('disabled', true);
                orderMoney = $prePaidMoney.val();
                getPayMoney();
                ga_storage._trackEvent('汽车服务-加油卡充值-首页', '点击', '立即充值');

                var _text = $('.js_card-info').find('.js_card-num').text()
                getCouponList(function(){
                    $('.js_order-card-number').text(_text)
                });

            // }
            // else {
                // Daze.showMsg(result.msg);
            // }
        });

        $listCoupon.click(function () { //选择优惠
            var _getrep = getRep();
            if(!_getrep){
                return false;
            }
            Daze.showSelectWin(couponList, function (coupon) {
                if (tool.isEmpty(coupon)) {
                    couponReset();
                    getPayMoney();
                } else {
                    //原价
                    orderMoney = $prePaidMoney.val();
                    $wrapSelectCoupon.find('.price').text(orderMoney);
                    couponSelected(coupon);
                }
            });
        });

        $btnOrder.click(function () {
            addOrder();
            ga_storage._trackEvent('汽车服务-加油卡充值-首页', '点击', '提交订单');
        });

        $checkbox.click(function () {
            $(this).toggleClass('checked');
            renderBtn();
        });

        $showAgreement.click(function () {
            Daze.pushWindow('agreement.html');
        });
    }

    function getRep(){
        if (zshHaszk && !type) {
            return false;
        }
        if (zshHaszk && type && _etype==2) {
            return false;
        }
        return true;
    }

    function renderHeader() {
        Daze.setTitle('加油卡充值');
    }


    /**
     * @method getCardRecord
     * @description 获取油卡历史记录
     */
    function getCardRecord(cardType){
        $.ajax({
            url: host.HOST_URL + '/dealService/getCardRecord.htm',
            type: 'post',
            data: DZ_COM.convertParams({
                uid : storage.getGlobalData().uid,
                cardType : cardType
            }),
            success: function (r) {
                if(r.code == '0' && r.data && r.data.list && r.data.list.length){
                    var key = cardType ? 'cardNosOfSY' : 'cardNosOfSH',
                        _arr = [];
                    for(var i = 0 ,len = r.data.list.length; i < len ; i++){
                        _arr.push(r.data.list[i].cardNum);
                    }
                    storage.storeInfo(key, _arr);
                }
                ga_storage._trackEvent('汽车服务-加油卡充值-油卡历史记录', 'dealService/getCardRecord.htm', '成功');
            },
            error: function () {
                DZ_COM.renderNetworkTip(null, 1);
                ga_storage._trackEvent('汽车服务-加油卡充值-油卡历史记录', 'dealService/getCardRecord.htm', '失败');
            }
        });
    }

    /**
     * @method getProvince
     * @description 获取省份列表
     */
    function getProvince() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/dealService/getCardNum.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    serviceId: serviceId
                }),
                success: function (r) {

                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if (r.code == 0) {
                        provinces = r.data.list;
                        renderProvince();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/getCardNum.htm', '成功');
                },
                error: function () {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/getCardNum.htm', '失败');
                }
            });
        });
    }

    function renderProvince() {
        if (!provinces) {
            return false;
        }
        var curCity = storage.getCurCity(),
            locationProvice = curCity.province,
            locationCityId = curCity.id,
            cityId = provinces[0].cityId,
            province = provinces[0].province;
        for (var i = 0; i < provinces.length; i++) {
            var option = $('<option>').val(provinces[i].cityId).text(provinces[i].province);
            $selProvince.append(option);
            if (locationProvice && locationProvice == provinces[i].province) {
                cityId = provinces[i].cityId;
                province = provinces[i].province;
            } else if (locationCityId && locationCityId == provinces[i].cityId) {
                cityId = locationCityId;
                province = provinces[i].province;
            }
        }
        $selProvince.val(cityId);
        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    /*function saveCardNo(cardNo) {
        var globalData = storage.getGlobalData(),
            key = type ? 'cardNosOfSY' : 'cardNosOfSH',
            records = globalData[key];
        if (records && records.length) {
            if ($.inArray(cardNo, records) < 0) {
                records.push(cardNo);
            }
        } else {
            records = [];
            records.push(cardNo);
        }
        storage.storeInfo(key, records.slice(-2));
    }*/

    function getCardNoInfo(cardNo) {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/dealService/getCardInfo.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    cardNo: cardNo
                }),
                success: function (r) {
                    gettingCardInfo = false;
                    if (r.code == 0) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        if (r.data && r.data.value) {
                            //取到正确的持有人数据的时候才显示
                            if (r.data.value != "没有查询到支持的模板") {
                                $owner.val(r.data.value);
                                $itemOwner.removeClass('hidden');
                            }
                        }
                    }
                    else {
                        $btnPay.attr('disabled', true);
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/getCardInfo.htm', '成功');
                },
                error: function () {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/getCardInfo.htm', '失败');
                }
            });
        });
    }

    /**
     * @method getPayMoney
     * @description 计算订单金额
     */
    function getPayMoney(num) {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var globalData = storage.getGlobalData(),
                pid = globalData.pid;
            var formData = getFormData(),
                uid = globalData.uid,
                userId = globalData.userId,
                cityId = storage.getCurCity().id,
                cardNo = $('.js_card-info').find('.js_card-num').text(),
                money = formData.pre_paid_money;
            $.ajax({
                url: host.HOST_URL + '/dealService/genChargePrice.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    serviceId: serviceId,
                    cityId: cityId,
                    uid: uid,
                    userId: userId,
                    cardNo: cardNo.replace(/\s/g, ''),
                    cardType: type,
                    rechargeAmount: Number(money),
                    province: storage.getCurCity().province
                }),
                success: function (r) {
                    if (r.code == 0) {
                        orderMoney = r.data.price;
                        $wrapSelectCoupon.find('.price').text(orderMoney);
                        if (num) {
                            $wrapSelectCoupon.find('.order-money span').text(orderMoney - num);
                        } else {
                            $wrapSelectCoupon.find('.order-money span').text(orderMoney);
                        }
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });

                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/genChargePrice.htm', '成功');
                },
                error: function () {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/genChargePrice.htm', '失败');
                }
            });
        });
    }

    function typeHandle(typeNum){
        if(typeNum == 0){
            $('.js_type-text').text('中国石化服务说明')
            $('.js_type-link').attr('data-type','0')
            $('.js_zsy-tip').css('display','none')
            $('.js_zsh-tip').css('display','block')
            $('.js_zsh-hidden').css('display','none')
        }
        else{
            $('.js_type-text').text('中国石油服务说明')
            $('.js_type-link').attr('data-type','1')
            $('.js_zsy-tip').css('display','block')
            $('.js_zsh-tip').css('display','none')
            $('.js_zsh-hidden').css('display','block')
        }
    }

    function getCouponList(callback) {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var params = {
            orderTypeId: 4,
            uid: storage.getGlobalData().uid,
            price: Number(orderMoney)
        };
        $.ajax({
            url: host.HOST_URL + '/coupon/getValidList.htm',
            type: 'post',
            data: DZ_COM.convertParams(params),
            success: function (r) {
                var list = [];
                if (r) {
                    if (r.code == 0) {
                        list = r.data && r.data.list;
                    }
                    else {
                        Daze.showMsg(r.msg);
                    }
                }
                renderSelectCoupon(list);
                callback && callback()
                ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'coupon/getValidList.htm', '成功');
            },
            error: function () {
                DZ_COM.renderNetworkTip(null, 1);
                ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'coupon/getValidList.htm', '失败');
            }
        });
    }

    function setDiscountAmount() {//状态折扣显示
        $zkList.each(function (i) {
            var _zk = zk_oil[type][i];
            if (_zk > 0) {
                $(this).text(_zk + '折');
            } else {
                $(this).text('');
            }
        });
    }

    function getDiscountAmount(card) {//查询折扣额度
        var globalData = storage.getGlobalData(),
            uid = globalData.uid,
            userId = globalData.userId,
            cardType = type,
            cardNo = card;
        $.ajax({
            url: host.HOST_URL + '/dealService/getDicsAmount.htm',
            type: 'post',
            data: DZ_COM.convertParams({
                uid: uid,
                userId: userId,
                cardNo: cardNo,
                cardType: cardType
            }),
            success: function (r) {
                if (r.code == 0) {
                    if (r['data']['result'] == true) {
                        zshHaszk = true;
                        if (type == 0) {
                            zk_oil[type][2] = 9.5;
                        }else{
                            zk_oil[type][2] = 9.5;
                        }
                    } else {
                        zshHaszk = false;
                    }
                    setDiscountAmount();
                } else {
                    Daze.showMsg(r.msg);
                    return false;
                }
                ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/addCardOrder.htm', '成功');
            },
            error: function () {
                DZ_COM.renderNetworkTip(null, 1);
                ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/addCardOrder.htm', '失败');
            }
        });
    }

    function renderSelectCoupon(list) {
        $wrapSelectCoupon.find('.service .value').text(serviceName);
        var cardNo = type ? $cardNoOfSY.val() : $cardNoOfSH.val();
        $wrapSelectCoupon.find('.card-number').text(cardNo);
        $wrapSelectCoupon.find('.price').text(orderMoney);
        /*if (type == 0) {
         $wrapSelectCoupon.find('.card-owner').text('(' + $owner.val() + ')');
         }*/
        couponReset();
        var _getrep = getRep();
        if(_getrep){
            for (var i = 0; i < list.length; i++) {
                if (list[i].name == 'benjin') {
                    couponList = list[i].list || [];
                }
            }
        }else{
            couponList = [];
        }


        if (list.length && couponList.length) {
            for (var j = 0; j < couponList.length; j++) {
                couponList[j].endTime = couponList[j].endTime.split(' ')[0];
            }
            $listCoupon.show();

            //默认选中最近到期的代金券
            couponSelected(couponList[0]);
        }
        else {
            couponList = [];
            $listCoupon.hide();
        }
        $wrapSelectCoupon.removeClass('hidden');

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function couponReset() {
        yhq = false;
        $listCoupon.attr({
            'data-id': 0
        }).text('请选择代金券');
        $wrapSelectCoupon.find('.coupon-price').text('');
        $wrapSelectCoupon.find('.order-money span').text(orderMoney);
    }

    function couponSelected(coupon) {
        yhq = true;
        $listCoupon.attr({
            'data-id': coupon.id
        }).text(coupon.name + '(' + coupon.endTime + ')');
        $wrapSelectCoupon.find('.coupon-price').text(' -' + coupon.amount);
        var money = orderMoney - coupon.amount > 0 ? orderMoney - coupon.amount : 0.01;
        $wrapSelectCoupon.find('.order-money span').text(tool.convertNumber(money));
        getPayMoney(coupon.amount);
    }

    function addOrder() {
        var globalData = storage.getGlobalData(),
            ykczInfo = getFormData();
        var params = {
            pId: globalData.pid,
            uid: globalData.uid,
            userId: globalData.userId,
            serviceId: serviceId,
            cityId: storage.getCurCity().id,
            price: orderMoney,
            cardNo: $('.js_card-info').find('.js_card-num').text(),
            rechargeAmount: Number(ykczInfo.pre_paid_money),
            province: storage.getCurCity().province,
            cardType: type,
            name: $('.js_card-info').find('.js_user-name').text()
        };

        var couponId = $listCoupon.data('id');
        if (couponId) {
            params.couponId = {
                benjin: couponId
            };
        }

        //验证
        var result = DZ_COM.validateParams(params, function () {
            addOrder();
        });
        if (result.eligible) {
            DZ_COM.checkNetwork(null, function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
                $.ajax({
                    url: host.HOST_URL + '/dealService/addCardOrder.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(params),
                    success: function (r) {
                        if (r.code == 0) {
                            Daze.showMsg({
                                type: 'loading',
                                visible: false
                            });

                            setTimeout(function () {
                                location.reload();
                            }, 100);
                            Daze.pushWindow({
                                appId:'10000009',
                                url:'detail.html?orderId='+r.data.orderId
                            });
                        }
                        else {
                            Daze.showMsg(r.msg);
                            return false;
                        }
                        ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/addCardOrder.htm', '成功');
                    },
                    error: function () {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-加油卡充值-首页', 'dealService/addCardOrder.htm', '失败');
                    }
                });
            });
        }
        else {
            Daze.showMsg(result.msg);
        }
    }

    /**
     * @method getFormData
     * @description 获取表单数据并转换为obj类型
     * @returns {{obj:object}}
     */
    function getFormData() {
        var arr = $form.serializeArray(),
            obj = {};
        for (var i = 0; i < arr.length; i++) {
            obj[arr[i].name] = arr[i].value;
        }

        obj.province = $selProvince.find('option').not(function () { // zepto不支持'option:selected'
            return !this.selected
        }).text();
        obj.cardNo = type ? obj.cardNoOfSY : obj.cardNoOfSH;

        return obj;
    }

    /**
     * @method validate
     * @description 表单验证
     * @returns {{data: object, msg: string, eligible: boolean}}
     */
    function validate() {
        var data = getFormData(),
            msg = '',
            eligible = true;
            console.log(data)

        if (type == 0) {//石化
            if (!data.cityId) {
                eligible = false;
                msg = '请选择省份';
            }
            else if (!data.cardNo) {
                eligible = false;
                msg = '请输入加油卡号';
            }
            else if (!/^\d{4}\s\d{4}\s\d{4}\s\d{4}\s\d{3}$/.test(data.cardNo)) {
                console.log(1)
                eligible = false;
                msg = '加油卡号为19位数字';
            }
            else if (!data.pre_paid_money) {
                eligible = false;
                msg = '请选择充值金额';
            }
        }
        else if (type == 1) {//石油
            if (!data.cityId) {
                eligible = false;
                msg = '请选择省份';
            }
            // else if (!data.owner) {
            //     eligible = false;
            //     msg = '请输入持卡人';
            // }
            else if (!data.cardNo) {
                eligible = false;
                msg = '请输入加油卡号';
            }
            else if (!/^^\d{4}\s\d{4}\s\d{4}\s\d{4}$/.test(data.cardNo)) {
                eligible = false;
                msg = '加油卡号为16位数字';
            }
            else if (!data.repeatCardNo || data.repeatCardNo != data.cardNo) {
                eligible = false;
                msg = '卡号不一致，请重新检查输入';
            }
            else if (!data.pre_paid_money) {
                eligible = false;
                msg = '请选择充值金额';
            }
        }

        return {
            data: data,
            msg: msg,
            eligible: eligible
        }
    }

    function renderBtn() {
        // var result = validate();
        var isChecked = $checkbox.hasClass('checked');
        if (isChecked) {
            $btnPay.removeAttr('disabled');
        }
        else {
            $btnPay.attr('disabled', true);
        }
    }

    // 渲染页面内容
    function renderContent() {
        oilPrice();
        // render banner
        module_banner.init('oilHead');
    }


    $('.change-card-main').on('click','.index-card-info',function(){
        var $self = $(this)
        $self.addClass('select').siblings().removeClass('select')
    })

    $('.change-card-main').on('click','.index-card-info',function(){
        var $self = $(this)
        $self.addClass('select').siblings().removeClass('select')
    })

    $('.change-card-confirm').on('click',function(){
        if($('.change-card-main').find('.index-card-info.select').length == 0){
            return
        }
        var _name = $('.change-card-main').find('.index-card-info.select').find('.js_user-name').text()
        var _num = $('.change-card-main').find('.index-card-info.select').find('.js_card-num').text()
        var _type = $('.change-card-main').find('.index-card-info.select').data('type')
        console.log(_type)
        $('.js_card-info').attr('data-type',_type)
        $('.js_card-info').find('.js_user-name').text(_name)
        $('.js_card-info').find('.js_card-num').text(_num)

        if(type != _type){
            type = _type
            getDiscountAmount()
            typeHandle(type)
        }
    })

    $('.header-btn').on('click','.header-btn-item',function(){
        var _link = $(this).data('go')
        Daze.pushWindow(_link)
    })

    $('.js_agree-btn').on('click',function(){
        $(this).toggleClass('in')
        $('#btnPay').toggleClass('event-disabled')
    })

});
