define([
    '../lib/text!./component-card.html',
], function (cardHtml) {
    return {
        template: cardHtml,
        props: ['data'],

        data: function () {
            return {
                trimCardNum: ''
            }
        },

        created:function(){
            this.showLoading()
            this.changeType(this.data.type)
        },

        compiled: function () {
            this.hideLoading()
        },
        methods: {
            enterNum:function(){
                this.data.cardNum = this.data.cardNum.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 ")
            },
            saveTrimNum:function(){
                this.data.cardNum = this.data.cardNum.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 ")
                this.data.trimCardNum = this.data.cardNum.replace(/\s/g, '')
                this.$log()
            },
            changeType:function(typeNum){
                this.$log()
                this.data.type = typeNum
                if(typeNum == 0){
                    this.data.maxLength = 23
                    this.data.placeholder = '请输入19位加油卡号'
                }
                else{
                    this.data.maxLength = 19
                    this.data.placeholder = '请输入16位加油卡号'
                    this.data.cardNum = this.data.cardNum.substring(0,19)
                    this.data.trimCardNum = this.data.cardNum.replace(/\s/g, '')
                }
            },
            showLoading:function(){
                console.log(1)
                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
            },

            hideLoading:function(){
                console.log(2)
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
            }
        }
    }
});