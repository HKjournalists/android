require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common', 
    'com/GALocalStorage'
], function (a, b ,host, tool, storage, DZ_COM) {
    var $record_list = $('#add_record_list'),
        $recordBtn = $('#recordBtn'),
        $recordList = $('#recordList'),
        $dateChoose = $('#dateChoose'),
        $GasAmount = $('.GasAmount'),
        $card_list = $('#card_record_list'),
        $count_num = $('#count_num'),
        $oilcard_lists = $('.oilcard-lists'),
        $addRecord = $('.addRecord'),
        $addRecord_lg = $('.addRecord-lg'),
        $btnrecord = $('.btn-record'),
        $btnoilcard = $('.btn-oilcard'),
        coutajax,plus=0;
        records = new Array();

        var curCity = storage.getGlobalData().curCity;
        //var curCity = [{id:92,name:'杭州',province:'浙江'}];
    document.addEventListener("DazeJSObjReady", function () {
       // console.log("DazeJSObjReady");
        init();
        
    }, false);
    function init() {
        renderHeader();
        //DZ_COM.login(function () {
            oilRecord(1);
            getoilcard(1);
            bindEvents();
            getGasAmount();
            getdateyear();
       // });
        ga_storage._trackPageview('carService/ykcz/index', "汽车服务-加油卡充值-首页");
    }
    // 选择不同年份的加油总费用
    function getdateyear() {
        var date = new Date();
        var year = date.getFullYear();
        if (year == 2015) {

        }else {
            var n = year -2015;
            for (var i = 0; i < n; i++) {
                var k = 2016 + i
                var str = '<option>'+k+'</option>'
                $dateChoose.append(str);
            };
            
        }
        
        //console.log(year);
    }
    function bindEvents() {
        $('.container').on({
            click : function(){
                $record_list.find('dd').removeClass('animate'); 
            }
        });
        $recordBtn.on({
            click : function(){
                var index = $(this).index();
                $(this).addClass('active').siblings().removeClass('active');
                $recordList.find('.item').hide().eq(index).show();
            }
        },'li');
        //select事件
        $dateChoose.on({
            change : function(){
                oilRecord(1);
            }
        })
        $card_list.on({
            click: function(){
                var self = $(this);
                //event.stopPropagation();
                 var orderId = self.attr('data-oid');
                // 
                Daze.pushWindow({
                    appId:'10000009',
                    url:'detail.html?orderId=' + orderId
                });
               
                //console.log(orderId);
            }
        },'.oilcard-lists');

        $('.addRecord,.addRecord-lg').on({
            click :function () {
                Daze.pushWindow('addrecord.html');
            }
        })
        $btnrecord.click(function(){
            var pageIndex = $(this).attr('data-page');
            oilRecord(pageIndex);
        })

        $btnoilcard.click(function(){
            var pageIndex = $(this).attr('data-page');
            getoilcard(pageIndex);
        })
        $('#add_record_list').on('click','.gasAddress',function(){
            $(this).parent().parent().addClass('animate').siblings().removeClass('animate');
            event.stopPropagation();
        })
        $record_list.on({
            swipeLeft:function(event){
              $(this).parent().addClass('animate').siblings().removeClass('animate');
              event.stopPropagation();
              //event.preventDefault();
            // },
            // tap : function(e){

            //     //console.log("1111");
            //     if(e.target.tagName.toLowerCase()!='span' || e.target.tagName!=undefined){
            //         //console.log("打开地图");
            //     }
             }
        },'.listcontainer').on({
            click : function(){
                var id = $(this).parent().attr('data-position');
                console.log(id);
                var self = $(this);
                DZ_COM.confirm( {
                    content : '删除该消息？',
                    yesFn : function(){
                        //删除事件
                        delRecord(id);
                        self.parent().remove();
                    }
                });
                //$(this)
                //console.log("删除");
            }
        },'.del');

        /*var lbsGeo = document.getElementById('lbs-geo');
        //监听定位失败事件 geofail  
        lbsGeo.addEventListener("geofail",function(evt){ 
            Daze.showMsg("获取位置失败……");
        });
        //监听定位成功事件 geosuccess
        lbsGeo.addEventListener("geosuccess",function(evt){ 
            console.log(evt.detail);
            var address = evt.detail.address;
            var coords = evt.detail.coords;
            var x = coords.lng;
            var y = coords.lat;
            Daze.showMsg("地址："+address);
        });*/
    }
    function renderHeader() {
        Daze.setTitle('加油记录');
    }
    // 获取加油记录
    function oilRecord(i) {
        // DZ_COM.checkNetwork(null, function () {
        //     Daze.showMsg({
        //         type: 'loading',
        //         visible: true
        //     });
        var time = $dateChoose.val();
       
        //var curCity = storage.getGlobalData().curCity;
            $.ajax({
                type:"post",
                url:host.HOST_URL+"/gas/gasRecord.htm",
                data:DZ_COM.convertParams({
                    cityId: curCity.id,
                    uid:storage.getUid(),
                    gasTime:time,
                    pageIndex:i
                }),
                dataType:"json",
                success:function(data){
                    // Daze.showMsg({
                    //         type: 'loading',
                    //         visible: false
                    //     });
                    if (data.code==0) {

                        records=data.data.list;
                        console.log(records.length);
                        //console.log('1'+records);
                        $record_list.append(template('record_list_temp', {list: records}));

                        if (data.data.total>10) {

                            $btnrecord.removeClass('hidden');
                        }
                        if (records.length == 0) {
                            //alert('1');
                            $btnrecord.addClass('hidden');
                        };
                        $btnrecord.attr('data-page',parseInt(i-0+1));
                    }else {
                        Daze.showMsg('加载失败，请重试');
                    }
                },
                error:function(){
                    Daze.showMsg('加载失败，请重试');
                }
            })
        // });
    }
    //获取加油总花费
    function getGasAmount() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var time = $dateChoose.val();
            $.ajax({
                type:"post",
                url:host.HOST_URL+"/gas/getGasAmount.htm",
                data:DZ_COM.convertParams({
                    cityId:curCity.id,
                    uid:storage.getUid(),
                    gasTime:time
                }),
                dataType:"json",
                success:function(data){
                     Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                    if (data.code==0) {
                        $GasAmount.text(data.data.price);
                    }
                    //console.log('获取加油记录成功！');
                },
                error:function(){

                }
            })
        });
    }
    function delRecord(id){
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                type:"post",
                url:host.HOST_URL+"/gas/delRecord.htm",
                data:DZ_COM.convertParams({
                    cityId:curCity.id,
                    id:id
                }),
                dataType:"json",
                success:function(data){

                    Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                    if (data.code==0) {
                        Daze.showMsg('删除成功');
                        getGasAmount();
                    }else {
                        Daze.showMsg('删除失败');
                    }
                },
                error:function(){
                    Daze.showMsg('删除失败');
                }
            });
       })   
    }
    function getoilcard(i) {

      
        $.ajax({
            type:"post",
            url:host.HOST_URL + "/fw/orders.htm",
            data:DZ_COM.convertParams({
                cityId:curCity.id,
                orderTypeId:4,
                uid:storage.getUid(),
                pageIndex:i,
                pageSize:10
            }),
            dataType:"json",
            success:function(data){
                Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                if (data.code ==0 ) {
                    //console.log(data);
                    var record = data.data.list;
                   //console.log(data.data.total)
                    var num = data.data.total;
                    coutajax = parseInt(num/10-0+1);
                    plus= plus +1;
                    $count_num.text(num);
                    if (record.length==0) {
                        $btnoilcard.addClass('hidden');
                    }
                    $card_list.append(template('card_list_temp', {list: record}));
                    if (num > 10 ) {
                        $btnoilcard.removeClass('hidden');
                    }
                    if (plus>=coutajax) {
                        $btnoilcard.addClass('hidden');
                    };
                    $btnoilcard.attr('data-page',parseInt(i-0+1));
                }else {
                    Daze.showMsg('加载失败，请重试');
                }
            },
            error:function(){
                Daze.showMsg('加载失败，请重试');
            }
        })
    }
});