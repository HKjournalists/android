require([
    'lib/zepto.min',
    'com/host',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, host, storage, common) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('ykcz pay completed init');

        var today = common.getToday();
        if (today == '2015-08-01') { // HD0001
            judgeHandler();
        }
        else { // HD0003
            renderContent('HD0003');
        }
        bindEvents();
        renderHeader();
        ga_storage._trackPageview('carService/ykcz/completed', "汽车服务-加油卡充值-支付完成");
    }

    function bindEvents() {
        var $toIndex = $('#toIndex'),
            $shareBtn = $('#shareBtn'),
            $entranceOfHD0003 = $('#entranceOfHD0003');
        $toIndex.click(function () {
            Daze.popTo(-99);
        });
        $shareBtn.click(function () {
            getReward();
        });
        $entranceOfHD0003.click(function () {
            Daze.pushWindow({
                appId: '11000003',
                url: 'index.html'
            });
        });
    }

    function renderHeader() {
        Daze.setTitle('支付成功');
    }

    function judgeHandler() { // 判断活动HD0001是否已领取过
        $.ajax({
            url: host.HOST_URL + '/user/hasQualified.htm',
            type: 'post',
            data: common.convertParams({
                uid: storage.getUid(),
                type: 37
            }),
            success: function (r) {
                if (r.code == 0) {
                    var canShare = r.data && r.data.canShare,
                        serial = canShare ? 'HD0001' : 'HD0003';
                    renderContent(serial);
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-HD0001', 'user/hasQualified.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-HD0001', 'user/hasQualified.htm', '失败');
            }
        });
    }

    function renderContent(serial) {
        $('#entranceOf' + serial).removeClass('hidden');
    }

    function getReward() {
        $.ajax({
            url: host.HOST_URL + '/user/dismantle.htm',
            type: 'post',
            data: common.convertParams({
                uid: storage.getUid(),
                type: 37
            }),
            success: function (r) {
                if (r.code == 0) {
                    Daze.share({
                        from: 37,
                        type: 37,
                        to: '2'
                    }, function (result) {
                        if (result.isSuccess || result.status == '成功') {
                            var $entranceOfHD0001 = $('#entranceOfHD0001'),
                                $result = $('#result'),
                                amount = r.data.amount;
                            if (amount) {
                                $result.find('img').attr('src', 'images/c_' + amount + 'y.png');
                                $entranceOfHD0001.addClass('hidden');
                                $result.removeClass('hidden');
                            }
                            else {
                                Daze.showMsg(r.msg);
                            }
                        }
                    });
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-8.1特惠日', 'user/dismantle.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-8.1特惠日', 'user/dismantle.htm', '失败');
            }
        });

    }
});
