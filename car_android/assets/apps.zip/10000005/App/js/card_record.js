require([
    'lib/zepto.min',
    'lib/vue',
    'lib/vue-validator',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'lib/fastclick',
    'com/GALocalStorage',
    'lib/underscore'
], function (a, Vue, validator, host, tool, storage, DZ_COM,FastClick) {


    document.addEventListener("DazeJSObjReady", function () {

        DZ_COM.login(function(){
            init();
        })
    }, false);

    function init() {
        FastClick.attach(document.body);
        Daze.setTitle('充值记录');
        render()
        ga_storage._trackPageview('carService/ykcz/index', "汽车服务-加油卡充值-首页");
    }

    function render(){
        // Vue.use(validator)

        var card_manage = new Vue({
            el: ".card-record",

            data: {
                list:null,
                myOptions: [
                  { text: '2013', value: '2013' },
                  { text: '2014', value: '2014' },
                  { text: '2015', value: '2015' }
                ],
                allTotal:0,
                selected:'2015',
                renderOver:false,
                noData:false
            },

            created: function(){
                this.getData()
                this.$watch('selected', function () {
                  this.getData()
                })
            },
            ready: function(){
                this.renderOver = true
            },

            filters: {
                numSplit: function(value) {
                    return value.replace(/\s/g, '').replace(/(\d{4})(?=\d)/g, "$1 ");
                },
                type2text:function(value){
                    if(value == 0){
                        return '中石化'
                    }
                    else{
                        return '中石油'
                    }
                },
                status2text:function(value){
                    var s
                    switch (value) {
                        case -1:
                            s = '已删除';
                            break;
                        case 1:
                            s = '无法支付';
                            break;
                        case 2:
                            s = '待支付';
                            break;
                        case 3:
                            s = '已支付';
                            break;
                        case 4:
                            s = '审核信息';
                            break;
                        case 5:
                            s = '待审核';
                            break;
                        case 6:
                            s = '审核失败';
                            break;
                        case 7:
                            s = '审核通过';
                            break;
                        case 10:
                            s = '处理中';
                            break;
                        case 11:
                            s = '处理失败';
                            break;
                        case 12:
                            s = '处理成功';
                            break;
                        case 13:
                            s = '待退款';
                            break;
                        case 14:
                            s = '已退款';
                            break;
                        case 15:
                            s = '确认完成';
                            break;
                        case 16:
                            s = '已评价';
                            break;
                        case 20:
                            s = '已关闭';
                            break;
                    }
                    return s
                }
            },

            methods: {
                showLoading:function(){
                    // console.log(1)
                    Daze.showMsg({
                        type: 'loading',
                        visible: true
                    });
                },

                hideLoading:function(){
                    // console.log(2)
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                },
                con:function(item){
                    // console.log(item)
                },
                goEdit:function(item){
                    Daze.pushWindow('card_edit.html?id='+ item.id +'&cardNum='+ item.cardNum +'&type='+ item.type +'&owner='+ item.owner +'&isDefault='+ item.isDefault);
                },
                goAdd:function(item){
                    Daze.pushWindow('card_add.html');
                },
                updateData:function(){
                    this.cardData.name = 'vue'
                    this.$log()
                },
                getData:function(){
                    var self = this
                    self.allTotal = 0
                    self.showLoading()
                    $.ajax({
                        url: host.HOST_URL + '/userCard/chargeRecord.htm',
                        type: 'post',
                        data: DZ_COM.convertParams({
                            uid : storage.getUid(),
                            chargeTime : self.selected
                        }),
                        success: function (data) {

                            if(data.code != 0){
                                return
                            }


                            _.each(data.data.list,function(i){
                                var moment_date = moment(i.orderTime)
                                var moment_month = moment_date.month()
                                i.month = moment_month + 1
                            })
                            var group_date = _.groupBy(data.data.list, 'month');
                            var group_arr = []
                            for(var i in group_date){
                                var _month = i
                                var _record = group_date[i]
                                var obj = {
                                    month : _month,
                                    record : _record
                                }
                                group_arr.push(obj)
                            }
                            console.log(group_arr)
                            self.list = group_arr

                            if(!data.data.list.length){
                                self.noData = true
                            }
                            else{
                                self.noData = false
                            }

                            self.hideLoading()
                        },
                        error: function () {

                        }
                    });

                    $.ajax({
                        url: host.HOST_URL + '/userCard/chargeAmount.htm',
                        type: 'post',
                        data: DZ_COM.convertParams({
                            uid : storage.getUid(),
                            chargeTime : self.selected
                        }),
                        success: function (data) {
                            if(data.code != 0){
                                return
                            }
                            _.each(data.data.list,function(i){

                                self.allTotal = self.allTotal + i.totalConsum
                            })

                            var group_date = _.groupBy(data.data.list, 'month');
                            // console.log(group_date)
                            self.moneys = group_date
                            // console.log(self.moneys)
                        },
                        error: function () {

                        }
                    });
                }
            }

        })
    }
});
