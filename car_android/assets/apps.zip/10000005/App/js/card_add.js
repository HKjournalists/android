require([
    'lib/zepto.min',
    'lib/vue',
    'lib/vue-validator',
    'component/component-card',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'lib/fastclick',
    'com/GALocalStorage'
], function (a, Vue, validator, card, host, tool, storage, DZ_COM,FastClick) {


    document.addEventListener("DazeJSObjReady", function () {

        DZ_COM.login(function(){
            init();
        })
    }, false);

    function init() {
        FastClick.attach(document.body);
        Daze.setTitle('添加油卡');
        render()
        ga_storage._trackPageview('carService/ykcz/index', "汽车服务-加油卡充值-首页");
    }

    function render(){
        // Vue.use(validator)
        var card_add = new Vue({
            el: ".card-add",

            data: {
                cardData:{
                    "owner": "",
                    "cardNum": "",
                    "trimCardNum": "",
                    "type": 0,
                    "show": false,
                    "maxLength": 23,
                    "placeholder": "请输入19位加油卡号",
                    "isDefault":true
                },
                isAjax:false,
                renderOver:false
            },
            ready:function(){
                this.renderOver = true;
            },

            methods: {
                showLoading:function(){
                    console.log(1)
                    Daze.showMsg({
                        type: 'loading',
                        visible: true
                    });
                },

                hideLoading:function(){
                    console.log(2)
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                },
                addData:function(){
                    var self = this
                    if(self.cardData.owner == ''){
                        Daze.showMsg('持卡人不能为空')
                        return
                    }
                    if(self.cardData.type == 0 && self.cardData.trimCardNum.length != 19){
                        Daze.showMsg('请输入19位卡号')
                        return
                    }
                    else if(self.cardData.type == 1 && self.cardData.trimCardNum.length != 16){
                        Daze.showMsg('请输入16位卡号')
                        return
                    }
                    self.isAjax = true
                    self.showLoading()
                    $.ajax({
                        type:"get",
                        data:DZ_COM.convertParams({
                            uid: storage.getUid(),
                            cardNum: self.cardData.trimCardNum,
                            owner: self.cardData.owner,
                            type: self.cardData.type,
                            isDefault:self.cardData.isDefault
                        }),
                        url:host.HOST_URL + '/userCard/add.htm',
                        dataType:"json",
                        success:function(data){
                            self.hideLoading()
                            Daze.showMsg('添加成功！')
                            setTimeout(function(){
                                Daze.system.postObserver({name: 'daze_followEvent'})
                                Daze.popTo(-1)
                            },1000)
                            console.log(data)
                        },
                        error:function(){
                            // self.isAjax = false
                        }
                    })
                }
            },

            components:{
                card:card,
            }

        })
    }
});
