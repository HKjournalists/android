require(['lib/zepto.min', 'com/storage'], function (a, storage) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('supplier pay completed init');

        renderHeader();
        setInfo();
    }

    function renderHeader() {
        Daze.setTitle('支付完成');
    }

    function setInfo() {
        var curSupplier = storage.getCurSupplier();
        if (!curSupplier) {
            Daze.showMsg('服务商不存在');
        }
        else {
            var tel = curSupplier.tel,
                supplierName = curSupplier.name,
                telArr = [];
            var $supplier = $('#supplier'),
                $phoneNumbers = $('#phoneNumbers');

            //set phone numbers
            $phoneNumbers.empty();
            if (tel.indexOf('/') >= 0) {
                telArr = tel.split('/');
            }
            else {
                telArr[0] = tel;
            }
            for (var i = 0; i < telArr.length; i++) {
                var $telNumber = $('<a>').attr('href', 'tel:' + telArr[i]).text(telArr[i]);
                $phoneNumbers.append($telNumber);
            }
            $supplier.text(supplierName);
        }
    }
});
