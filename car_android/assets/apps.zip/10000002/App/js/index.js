require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, host, storage, DZ_COM) {
    var tabSort = $('#tabSort'),
        $listSuppliers = $('#listSuppliers'),
        $btnMore = $('#btnMore');

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    var suppliers = [],
        total = 0,
        pageIndex = 0,
        type = 0;

    function init() {
        renderHeader();
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        getList(type);
        bindEvents();
        ga_storage._trackPageview('carService/suppliers/index', "汽车服务-非自营服务-首页");
    }

    function bindEvents() {
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });

        tabSort.on('click', 'li', function () {
            var isCurTab = $(this).hasClass('active');
            $(this).addClass('active').siblings().removeClass('active');
            pageIndex = 0;
            type = $(this).data('type');
            if (!isCurTab) {
                if (type || type == 0) {
                    $listSuppliers.find('ul').remove();
                    $btnMore.hide();
                }
                getList(type);
                ga_storage._trackEvent('汽车服务-非自营服务-首页', '点击', $(this).text());
            }
        });
        $listSuppliers.on('click', 'li', function (e) {
            if (e.target.className == 'tel') {
                ga_storage._trackEvent('汽车服务-非自营服务-首页', '点击', '联系服务商');
            }
            else {
                var supplierId = $(this).data('supplierid');
                Daze.pushWindow('supplier.html?supplierId=' + supplierId);
                ga_storage._trackEvent('汽车服务-非自营服务-首页', '点击', '服务商详情');
            }
        });
        $btnMore.on('click', function () {
            getList(type);
        });
    }

    function renderHeader() {
        Daze.setTitle('服务提供商');
    }

    /**
     * @method getList
     * @description 根据城市id和服务id获取供应商列表
     * @param type
     */
    function getList(type) {
        var domId = 'listSuppliers';
        DZ_COM.checkNetwork(domId, function () {
            $.ajax({
                url: host.HOST_URL + '/dealService/getServiceProviderList.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    serviceId: storage.getCurService().id,
                    cityId: storage.getCurCity().id,
                    pageIndex: pageIndex,
                    sortType: type
                }),
                success: function (r) {
                    if (r.code == 0) {
                        pageIndex++;
                        suppliers = convertData(r.data.list);
                        total = r.data.total;
                        renderServices();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-非自营服务-首页', 'dealService/getServiceProviderList.htm', '成功');
                },
                error: function () {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-非自营服务-首页', 'dealService/getServiceProviderList.htm', '失败');
                }
            });
        });
    }

    /**
     * @method renderServices
     * @description 渲染供应商列表
     */
    function renderServices() {
        var list = $('#listSuppliers');
        list.append(template('suppliersTmpl', {list: suppliers}));

        var l = list.find('li').length;
        if (l && l < total) {
            $btnMore.show();
        }
        else {
            $btnMore.hide();
        }

        renderLevel();

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    /**
     * @method renderLevel
     * @description 渲染供应商星级评价
     */
    function renderLevel() {
        var level = $('.level');
        level.raty({
            score: function () {
                return $(this).data('score');
            },
            width: '100%',
            path: 'images',
            readOnly: true
        });
    }

    /**
     * @method convertData
     * @description 供应商列表数据二次处理
     * @param {array} list
     * @returns {array} list
     */
    function convertData(list) {
        for (var i = 0; i < list.length; i++) {
            list[i].business_phone = list[i].business_phone.split('/')[0];
        }
        return list;
    }
});
