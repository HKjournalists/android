require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/jquery.raty.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, c, host, tool, storage, DZ_COM) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    var authType = null;

    var orderMoney = 0,
        couponList = [];

    var $info = $('#info'),
        fixedBox = $('#fixedBox'),

        $wrapSelectCoupon = $('#wrapSelectCoupon'),
        $listCoupon = $('#listCoupon'),
        $btnOrder = $('#btnOrder');

    function init() {
        renderHeader();
        var urlParams = tool.getQueryString(),
            supplierId = urlParams.supplierId;
        if (supplierId) {
            getDetail(supplierId);
            bindEvents();
        }
        else {
            Daze.showMsg('无法获取供应商');
            setTimeout(function () {
                Daze.popWindow();
            }, 2100);
            return false;
        }
        ga_storage._trackPageview('carService/suppliers/supplier', "汽车服务-非自营服务-服务商详情");
    }

    function bindEvents() {
        $info.on('click', '.item', function () {
            var $this = $(this),
                $content = $this.find('.content'),
                $arrow = $this.find('.arrow');
            if ($this.hasClass('active')) {
                $this.removeClass('active');
                $arrow.removeClass('rotation');
                $content.addClass('hidden');
            }
            else {
                $this.addClass('active');
                $arrow.addClass('rotation');
                $content.removeClass('hidden');
            }
        });
        $info.on('focus', '#iptMoney', function () {
            $wrapSelectCoupon.addClass('hidden');
        });
        $info.on('input', '#iptMoney', function () {
            var result = validateMoney();
            var $btnPay = $('#btnPay');
            if (result.eligible) {
                orderMoney = result.orderMoney;
                $btnPay.removeAttr('disabled');
            }
            else {
                orderMoney = 0;
                $btnPay.attr('disabled', true);
            }
        });
        $info.on('click', '#btnPay', function () {
            DZ_COM.login(function () {
                getCouponList();
                ga_storage._trackEvent('汽车服务-非自营服务-服务商详情', '点击', '确认金额');
            });
        });
        $(window).scroll(function () {
            if (!authType) {
                return false;
            }

            var scrollTop = $(this).scrollTop(),
                height = fixedBox.height(),
                bottom = fixedBox.css('bottom');
            var fixedFiller = $('#fixedFiller');

            if (scrollTop >= 130) {
                if (bottom != '0px') {
                    fixedBox.css({
                        bottom: 68 - height
                    }, 200);
                    fixedFiller.css({
                        height: 68
                    });
                }
            }
            else {
                fixedBox.css({
                    bottom: -height
                }, 200);
                fixedFiller.css({
                    height: 0
                });
            }
        });
        $listCoupon.click(function () {
            Daze.showSelectWin(couponList, function (coupon) {
                if (tool.isEmpty(coupon)) {
                    couponReset();
                }
                else {
                    couponSelected(coupon);
                }
            });
        });
        $btnOrder.click(function () {
            addOrder();
            ga_storage._trackEvent('汽车服务-非自营服务-服务商详情', '点击', '提交订单');
        });

        //电话联系
        $('.btn-tel').click(function () {
            ga_storage._trackEvent('汽车服务-非自营服务-服务商详情', '点击', '电话联系');
        });
    }

    function renderHeader() {
        Daze.setTitle('服务详情');
    }

    function getDetail(supplierId) {
        var domId = 'info';
        DZ_COM.checkNetwork(domId, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });

            var cityId = storage.getCurCity().id,
                serviceId = storage.getCurService().id;
            $.ajax({
                url: host.HOST_URL + '/dealService/getServiceProviderDetail.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    serviceProviderId: supplierId,
                    serviceId: serviceId,
                    cityId: cityId
                })
            }).done(function (r) {
                if (r.code == 0) {
                    var detailInfo = convertData(r.data);
                    authType = detailInfo.serviceProvider.authType;
                    saveCurSupplier(supplierId, detailInfo);
                    renderSupplierDetail(detailInfo);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(domId, 1);
            });
        });
    }

    function convertData(data) {
        if (data.serviceProvider) {
            if (!data.serviceProvider.authType) {
                data.serviceProvider.authType = '';
            }
            else if (data.serviceProvider.authType == 1) {
                data.serviceProvider.authType = '个人身份证已认证';
            }
            else if (data.serviceProvider.authType == 2) {
                data.serviceProvider.authType = '营业执照已认证';
            }

            var phone = data.serviceProvider.businessPhone;
            if (phone && phone.indexOf('/') >= 0) {
                var telArr = phone.split('/');
                data.serviceProvider.businessPhone = telArr[0];
                data.serviceProvider.otherTels = telArr.slice(1);
            }

            // add cur service name
            data.serviceProvider.curServiceName = storage.getCurService().name;
        }
        if (data.stuff) {
            data.stuff = data.stuff.split('\n');
        }
        return data;
    }

    function saveCurSupplier(supplierId, detailInfo) {
        var curSupplier = {
            id: supplierId,
            name: detailInfo.serviceProvider.name,
            tel: detailInfo.serviceProvider.businessPhone,
            evaluationScore: detailInfo.serviceProvider.evaluationScore
        };
        storage.storeInfo('curSupplier', curSupplier);
    }

    function renderSupplierDetail(detailInfo) {
        $info.html(template('detailTmpl', {info: detailInfo}));

        var tel = detailInfo.serviceProvider.businessPhone;
        fixedBox.find('.btn-tel').attr('href', 'tel:' + tel);

        renderLevel();

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function renderLevel() {
        var level = $('.level');
        level.raty({
            score: function () {
                return $(this).data('score');
            },
            path: 'images',
            readOnly: true
        })
    }

    function getCouponList() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var params = {
                orderTypeId: 2,
                uid: storage.getUid(),
                price: Number(orderMoney)
            };
            $.ajax({
                url: host.HOST_URL + '/coupon/getValidList.htm',
                type: 'post',
                data: DZ_COM.convertParams(params)
            }).done(function (r) {
                var list = [];
                if (r) {
                    if (r.code == 0) {
                        list = r.data.list;
                    }
                    else {
                        Daze.showMsg(r.msg);
                    }
                }
                renderSelectCoupon(list);
            }).fail(function () {
                DZ_COM.renderNetworkTip(null, 1);
            });
        });
    }

    function renderSelectCoupon(list) {
        var serviceName = storage.getCurService().name;

        $wrapSelectCoupon.find('.service .value').text(serviceName);
        $wrapSelectCoupon.find('.service-type .key').text($('#alias').text());
        $wrapSelectCoupon.find('.price').text(orderMoney);
        couponReset();

        for (var i = 0; i < list.length; i++) {
            if (list[i].name == 'benjin') {
                couponList = list[i].list || [];
            }
        }
        if (list.length && couponList.length) {
            for (var j = 0; j < couponList.length; j++) {
                couponList[j].endTime = couponList[j].endTime.split(' ')[0];
            }
            $listCoupon.show();

            //默认选中最近到期的代金券
            couponSelected(couponList[0]);
        }
        else {
            couponList = [];
            $listCoupon.hide();
        }
        $wrapSelectCoupon.removeClass('hidden');

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function couponReset() {
        $listCoupon.attr({
            'data-id': 0
        }).text('请选择代金券');
        $wrapSelectCoupon.find('.coupon-price').text('');
        $wrapSelectCoupon.find('.order-money span').text(orderMoney);
    }

    function couponSelected(coupon) {
        $listCoupon.attr({
            'data-id': coupon.id
        }).text(coupon.name + '(' + coupon.endTime + ')');
        $wrapSelectCoupon.find('.coupon-price').text(' -' + coupon.amount);
        var money = orderMoney - coupon.amount > 0 ? orderMoney - coupon.amount : 0.01;
        $wrapSelectCoupon.find('.order-money span').text(tool.convertNumber(money));
    }

    function addOrder() {
        var params = {
            pId: storage.getPid(),
            uid: storage.getUid(),
            userId: storage.getUserId(),
            cityId: storage.getCurCity().id,
            serviceId: storage.getCurService().id,
            serviceProviderId: storage.getCurSupplier().id,
            price: Number(orderMoney)
        };

        var couponId = $listCoupon.data('id');
        if (couponId) {
            params.couponId = {
                benjin: couponId
            };
        }

        //验证
        var result = DZ_COM.validateParams(params, function () {
            addOrder();
        });
        if (result.eligible) {
            DZ_COM.checkNetwork(null, function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
                $.ajax({
                    url: host.HOST_URL + '/dealService/add.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(params)
                }).done(function (r) {
                    if (r.code == 0) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });

                        setTimeout(function () {
                            location.reload();
                        }, 100);
                        Daze.pushWindow('detail.html?orderId=' + r.data.orderId);
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                }).fail(function () {
                    DZ_COM.renderNetworkTip(null, 1);
                });
            });
        }
        else {
            Daze.showMsg(result.msg);
        }
    }

    function validateMoney() {
        var v = $('#iptMoney').val();
        var exp = /^(([1-9]\d*)(\.\d+)?)$|(0\.0?(\d+?))$/;
        var msg = '',
            eligible = true;

        if (!exp.test(v)) {
            eligible = false;
            msg = '金额格式错误！';
        }

        return {
            eligible: eligible,
            msg: msg,
            orderMoney: v
        }
    }
});
