require(['lib/zepto.min'], function (a) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        var hash = window.location.hash;
        if(hash=="#fast"){
            $('.fast').removeClass('hidden');
        }else{
            $('.nofast').removeClass('hidden');
        }
        bindEvents();
        renderHeader();
    }

    function bindEvents() {
        var toIndex = $('#toIndex');

        toIndex.click(function () {
            Daze.popTo(-2);
        });
    }

    function renderHeader() {
        Daze.setTitle('支付成功');
    }
});
