require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'inputFoucs',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM,InputFoucs) {
    var serviceTypes = null;

    var $info = $('#info'),
        $wrapSelectCoupon = $('#wrapSelectCoupon'),
        $listCoupon = $('#listCoupon'),
        $infoRescue = $('#infoRescue'),
        $form = $('#form'),
        $btnOrder = $('#btnOrder'),
        serviceItemId = 0;
        _InputFoucs = null;

    var curServiceType = null,
        couponList = [];

    var serviceId = 9,
        serviceName = '全国道路救援',
        globalData = storage.getGlobalData(),
        cityId = globalData && globalData.curCity && globalData.curCity.id || 92,
        serviceProviderId = globalData && globalData.curSupplier && globalData.curSupplier.id || 39;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");

        DZ_COM.login(function(){
            DZ_COM.getCurCity(function(){
                init();
            });
        })
    }, false);

    function init() {
        renderHeader();
        if(DZ_COM.getSystem() == 'android'){
           _InputFoucs = new InputFoucs();
        }
        
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        getServiceTypes();
        bindEvents();
        ga_storage._trackPageview('carService/rescue/index', "汽车服务-全国道路救援-首页");
    }

    function bindEvents() {
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });

        $info.on('click', '#infoServiceTypes li', function () {
            var isCur = $(this).hasClass('cur');
            if (!isCur) {
                $wrapSelectCoupon.addClass('hidden');
                $infoRescue.addClass('hidden');
                $(this).addClass('cur').siblings().removeClass('cur');

                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
                var serviceTypeId = $(this).data('id');
                serviceItemId = serviceTypeId;
                curServiceType = getSecondInfoByServiceType(serviceTypeId);
                renderSecondInfo();
                renderTotalInfo();
                ga_storage._trackEvent('汽车服务-全国道路救援-首页', '点击', $(this).data('name'));
            }
            else {
                return false;
            }
        });

        //tab切换
        $info.on('click', '.tab li', function () {
            var isCur = $(this).hasClass('active');
            if (!isCur) {
                $(this).addClass('active').siblings().removeClass('active');
                var idx = $(this).index();
                var $content = $info.find('.tab-content');
                $content.addClass('hidden');
                $content.eq(idx).removeClass('hidden');
                ga_storage._trackEvent('汽车服务-全国道路救援-首页', '点击', $(this).text());
            }
            else {
                return false;
            }
        });

        $info.on('click', '.agreement', function () {
            var $cb = $(this).find('#checkbox');
            $cb.toggleClass('checked');
            var isChecked = $cb.hasClass('checked');
            var $btnPay = $('#btnPay');
            if (isChecked) {
                $btnPay.removeAttr('disabled');
            }
            else {
                $btnPay.attr('disabled', true);
            }
        });

        $info.on('click', '#showAgreement', function () {
            Daze.pushWindow('service-detail.html');
        });

        $info.on('click', '#btnPay', function () {
            if(this.getAttribute('data-type') == 'fast'){
                var date = new Date(),
                    h = date.getHours(),
                    m = date.getMinutes();
                if(h > 20 || h < 8 || (h==20&&m>=30) || (h==8&&m<=30)){
                    Daze.showMsg("请在受理时间下单");
                    return;
                }
            }
            if (curServiceType.price === 0) {
                if (Daze.auth && Daze.auth.auth) {//用户认证
                    Daze.auth.auth();
                }
                else {
                    Daze.rescue();
                }
                ga_storage._trackEvent('汽车服务-全国道路救援-首页', '点击', '立即认证');
            }
            else {
                DZ_COM.login(function () {
                    getCouponList();
                    ga_storage._trackEvent('汽车服务-全国道路救援-首页', '点击', '立即下单');
                });
            }
        });

        $listCoupon.click(function () {
            Daze.showSelectWin(couponList, function (coupon) {
                if (tool.isEmpty(coupon)) {
                    couponReset();
                }
                else {
                    couponSelected(coupon);
                }
            });
        });

        $btnOrder.click(function () {
            addOrder();
            ga_storage._trackEvent('汽车服务-全国道路救援-首页', '点击', '提交订单');
        });
    }

    function renderHeader() {
        Daze.setTitle('全国道路救援');
    }

    function getServiceTypes() {
        var domId = 'info';
        DZ_COM.checkNetwork(domId, function () {
            $.ajax({
                url: host.HOST_URL + '/dealService/getServiceItems.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    serviceId: serviceId,
                    cityId: cityId
                }),
                success: function (r) {
                    if (r.code == 0) {
                        serviceTypes = r.data && r.data.list.length ? convertData(r.data.list) : [];
                        renderServiceTypes();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-全国道路救援-首页', 'dealService/getServiceItems.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-全国道路救援-首页', 'dealService/getServiceItems.htm', '失败');
                }
            });
        });
    }

    function convertData(list) {
        for (var j = 0; j < list.length; j++) {
            if (list[j].stuff) {
                list[j].stuff = list[j].stuff.split('\n');
            }
        }
        return list;
    }

    function getSecondInfoByServiceType(id) {
        for (var i = 0; i < serviceTypes.length; i++) {
            if (serviceTypes[i].id == id) {
                return serviceTypes[i];
            }
        }
        return {};
    }

    function renderServiceTypes() {
        $info.append(
            template('serviceTypesTmpl', {
                serviceId: serviceId,
                serviceTypes: serviceTypes
            })
        );

        curServiceType = serviceTypes[0];
        if (curServiceType) {
            renderSecondInfo();
            renderTotalInfo();
        }
        else {
            Daze.showMsg({
                type: 'loading',
                visible: false
            });
        }
    }

    function renderSecondInfo() {
        var $infoSecond = $('#infoSecond');
        if ($infoSecond) {
            $infoSecond.remove();
        }
        $info.append(template('secondTmpl', curServiceType));

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function renderTotalInfo() {
        var $wrapTotal = $('#wrapTotal');
        if ($wrapTotal) {
            $wrapTotal.remove();
        }
        curServiceType.btnVal = curServiceType.price === 0 ? '立即认证' : '立即下单';
        $info.append(template('totalTmpl', curServiceType));
    }

    function getCouponList() {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var params = {
                orderTypeId: 2,
                uid: storage.getGlobalData().uid,
                price: curServiceType.price
            };
            $.ajax({
                url: host.HOST_URL + '/coupon/getValidList.htm',
                type: 'post',
                data: DZ_COM.convertParams(params),
                success: function (r) {
                    var list = [];
                    if (r) {
                        if (r.code == 0) {
                            list = r.data.list;
                        }
                        else {
                            Daze.showMsg(r.msg);
                        }
                    }
                    renderSelectCoupon(list);
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                }
            });
        });
    }

    function renderSelectCoupon(list) {
        $wrapSelectCoupon.find('.service .value').text(serviceName);
        $wrapSelectCoupon.find('.service-type .key').text(curServiceType.props);
        $wrapSelectCoupon.find('.price').text(curServiceType.price);
        couponReset();

        for (var i = 0; i < list.length; i++) {
            var itemList = list[i].list || [];
            if (list[i].name == serviceId) {
                couponList = itemList;
            }
            else if (list[i].name == 'all') {
                couponList = couponList.concat(itemList);
            }
        }
        if (couponList.length) {
            for (var j = 0; j < couponList.length; j++) {
                couponList[j].endTime = couponList[j].endTime.split(' ')[0];
            }
            $listCoupon.show();

            //默认选中最近到期的代金券
            couponSelected(couponList[0]);
        }
        else {
            couponList = [];
            $listCoupon.hide();
        }
        $infoRescue.removeClass('hidden');

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function couponReset() {
        $listCoupon.attr({
            'data-id': 0
        }).text('请选择代金券');
        $infoRescue.find('.order-money span').text(curServiceType.price);
    }

    function couponSelected(coupon) {
        $listCoupon.attr({
            'data-id': coupon.id
        }).text(coupon.name + '(' + coupon.endTime + ')');
        var money = curServiceType.price - coupon.amount > 0 ? curServiceType.price - coupon.amount : 0.01;
        $infoRescue.find('.order-money span').text(tool.convertNumber(money));
    }

    function addOrder() {
        var globalData = storage.getGlobalData();
        var params = {
            pId: globalData.pid,
            uid: globalData.uid,
            userId: globalData.userId,
            cityId: cityId,
            serviceItemId : serviceItemId,
            serviceId: serviceId,
            serviceProviderId: serviceProviderId,
            price: curServiceType.price,
            descr: getData()
        };

        var couponId = $listCoupon.data('id');
        if (couponId) {
            params.couponId = {
                benjin: couponId
            };
        }
        if (!params.descr || params.descr.split(',').length != 3) {
            return false;
        }

        //验证
        var result = DZ_COM.validateParams(params, function () {
            addOrder();
        });
        if (result.eligible) {
            DZ_COM.checkNetwork(null, function () {
                Daze.showMsg({
                    type: 'loading',
                    visible: true
                });
                $.ajax({
                    url: host.HOST_URL + '/dealService/add.htm',
                    type: 'post',
                    data: DZ_COM.convertParams(params),
                    success: function (r) {
                        if (r.code == 0) {
                            Daze.showMsg({
                                type: 'loading',
                                visible: false
                            });
                            $form[0].reset();
                            $infoRescue.addClass('hidden');
                            Daze.pushWindow({
                                appId:'10000009',
                                url:'detail.html?orderId='+r.data.orderId
                            });
                        }
                        else {
                            Daze.showMsg(r.msg);
                            return false;
                        }
                        ga_storage._trackEvent('汽车服务-全国道路救援-首页', 'dealService/add.htm', '成功');
                    },
                    error: function (r) {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-全国道路救援-首页', 'dealService/add.htm', '失败');
                    }
                });
            });
        }
        else {
            Daze.showMsg(result.msg);
        }
    }

    function getData() {
        var $form = $('#form');
        var arr = $form.serializeArray(),
            data = [];
        for (var i in arr) {
            if (!arr[i].value) {
                var placeholder = $('input[name=' + arr[i].name + ']').attr('placeholder');
                Daze.showMsg(placeholder);
                return false;
            }
            else if (arr[i].name == 'number' && arr[i].value.length != 7) {
                Daze.showMsg('车牌号输入有误');
                return false;
            }
            else {
                data.push(arr[i].value);
            }
        }

        return data.toString();
    }
});
