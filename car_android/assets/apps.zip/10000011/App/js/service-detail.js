require(['lib/zepto.min'], function (a) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
    }

    function renderHeader() {
        Daze.setTitle('服务协议');
    }
});
