require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM) {
    var $wrapOrderDetail = $('#wrapOrderDetail'),
        $wrapSelect = $('#wrapSelect'),
        $cashAccount = $('#cashAccount'),
        $payOnline = $('#payOnline'),
        $cbOfCashAccount = $('#cbOfCashAccount'),
        $cbOfPayOnline = $('#cbOfPayOnline'),
        $btnPay = $('#btnPay'),
        $btnClose = $('#btnClose');

    var orderMoney = 0,//订单金额
        cashBalance = 0;//现金账户余额

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        var queryObj = tool.getQueryString(),
            orderId = queryObj.orderId;
        if (orderId) {
            getDetail(orderId);
            bindEvents(orderId);

        }
        else {
            Daze.showMsg('订单不存在');
            setTimeout(function () {
                Daze.popWindow();
            }, 2100);
            return false;
        }
        ga_storage._trackPageview('carService/rescue/detail', "汽车服务-全国道路救援-订单详情");
    }

    function bindEvents(orderId) {
        $btnPay.click(function () {
            payHandler(orderId);
            ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', '点击', '确认前往付款');
        });
        $btnClose.click(function () {
            DZ_COM.confirm({
                content: '确定取消订单？',
                yesFn: function () {
                    DZ_COM.login(function () {
                        closeOrder(orderId);
                        ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', '点击', '取消订单');
                    });
                }
            });
        });
        $cbOfCashAccount.change(function () {
            var isChecked = $(this).is(':checked');
            if (orderMoney > cashBalance) {
                if (isChecked) {
                    $cashAccount.find('.pay-balance').removeClass('hidden');
                    $payOnline.find('.pay-balance .balance').text(tool.convertNumber(orderMoney - cashBalance));
                }
                else {
                    $cashAccount.find('.pay-balance').addClass('hidden');
                    $payOnline.find('.pay-balance .balance').text(orderMoney);
                }
            }
            else {
                if (isChecked) {
                    $cbOfCashAccount.attr('disabled', true);
                    $cashAccount.find('.pay-balance').removeClass('hidden');
                    $cbOfPayOnline.prop('checked',false);
                    $cbOfPayOnline.prop('disabled',false);
                    $payOnline.find('.pay-balance').addClass('hidden');
                }
            }
            renderBtn();
        });
        $cbOfPayOnline.change(function () {
            var isChecked = $(this).is(':checked');
            if (orderMoney <= cashBalance) {
                if (isChecked) {
                    $cbOfCashAccount.prop('checked',false);
                    $cbOfCashAccount.prop('disabled',false);
                    $cashAccount.find('.pay-balance').addClass('hidden');
                    $cbOfPayOnline.attr('disabled', true);
                    $payOnline.find('.pay-balance').removeClass('hidden');
                }
            }
            renderBtn();
        });
    }

    function renderHeader() {
        Daze.setTitle('订单详情');
    }

    function renderBtn() {
        var useBalance = $('#cbOfCashAccount').is(':checked'),
            payOnline = $('#cbOfPayOnline').is(':checked');

        //按钮可用情况1：订单金额大于现金余额，使用在线支付或者在线支付和现金余额共用
        //按钮可用情况2：订单金额小于等于现金余额，使用在线支付或者现金余额
        var available = false;
        if (orderMoney > cashBalance) {
            if (payOnline) {
                available = true;
            }
        }
        else {
            if (useBalance || payOnline) {
                available = true;
            }
        }
        if (available) {
            $btnPay.removeAttr('disabled');
        }
        else {
            $btnPay.attr('disabled', true);
        }
    }

    function getDetail(orderId) {
        var domId = 'wrapOrderDetail';
        DZ_COM.checkNetwork(domId, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/dealService/getOrderDetail.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    orderId: orderId
                }),
                success: function (r) {
                    if (r.code == 0) {
                        var data = convertData(r.data.serviceOrderDetail);
                        renderDetail(data);
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', 'dealService/getOrderDetail.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', 'dealService/getOrderDetail.htm', '失败');
                }
            });
        });
    }

    function renderDetail(data) {
        if (data.couponPrice) {
            orderMoney = data.price - data.couponPrice > 0 ? tool.convertNumber(data.price - data.couponPrice) : 0.01;
        }
        else {
            orderMoney = data.price;
        }
        data.orderMoney = orderMoney;
        $wrapOrderDetail.html(template('detailTmpl', data));
        if (data.status == '待支付') {
            var globalData = storage.getGlobalData();
            if (globalData.uid) {
                getBalance();
            }
            else {
                payInit();
            }
            $wrapSelect.removeClass('hidden');
        }
        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function convertData(data) {
        var s = DZ_COM.convertStatus(data.status).status,
            c = DZ_COM.convertStatus(data.status).color,
            bc = DZ_COM.convertStatus(data.status).backgroundColor;
        data.status = s;
        data.color = c;
        data.backgroundColor = bc;

        // convert coupon name
        data.couponName = JSON.parse(data.couponName).benjin;

        return data;
    }

    function getBalance() {
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getUserInfo.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    uid: storage.getUid()
                }),
                success: function (r) {
                    if (r.code == 0) {
                        cashBalance = r.data.userInfo.cashBalance || 0;
                        payInit();
                    }
                    else {
                        Daze.showMsg(r.msg);
                        cashBalance = 0;
                        payInit();
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', 'user/getUserInfo.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', 'user/getUserInfo.htm', '失败');
                }
            });
        });
    }

    function payInit() {
        $cashAccount.find('.balance').text(cashBalance);
        if (cashBalance) {
            $cashAccount.removeClass('hidden');
        }
        if (orderMoney > cashBalance) {
            $cbOfPayOnline.attr({'checked': true, 'disabled': true});
            $payOnline.find('.pay-balance .balance').text(orderMoney);
            $payOnline.find('.pay-balance').removeClass('hidden');
        }
        else {
            $cbOfCashAccount.attr({'checked': true, 'disabled': true});
            $cashAccount.find('.pay-balance .balance').text(orderMoney);
            $payOnline.find('.pay-balance .balance').text(orderMoney);
            $cashAccount.find('.pay-balance').removeClass('hidden');
        }
    }

    function payHandler(orderId) {
        var useBalance = $cbOfCashAccount.is(':checked'),
            payOnline = $cbOfPayOnline.is(':checked');
        Daze.pay({
            orderId: orderId,
            useBalance: useBalance,
            payOnline: payOnline
        }, function (resp) {
            if (resp.isSuccess) {
                setTimeout(function () {
                    location.reload();
                }, 3000);
                Daze.pushWindow('completed.html');
            }
            else {
                Daze.showMsg('支付失败');
            }
        });
    }

    function closeOrder(orderId) {
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            var pid = storage.getPid();
            $.ajax({
                url: host.HOST_URL + '/formOrder/closeOrder.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    orderId: orderId,
                    pId: pid
                }),
                success: function (r) {
                    if (r.code == 0) {
                        if (r.data && r.data.result) {
                            Daze.showMsg('取消成功');
                            setTimeout(function () {
                                location.reload();
                            }, 2100);
                        }
                        else {
                            Daze.showMsg('取消失败');
                        }
                    }
                    else {
                        Daze.showMsg(r.msg);
                        return false;
                    }
                    ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', 'formOrder/closeOrder.htm', '成功');
                },
                error: function (r) {
                    DZ_COM.renderNetworkTip(null, 1);
                    ga_storage._trackEvent('汽车服务-全国道路救援-订单详情', 'formOrder/closeOrder.htm', '失败');
                }
            });
        });
    }
});
