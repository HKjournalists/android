require(['lib/zepto.min', 'lib/tpl.min', 'com/host', 'com/tools', 'com/storage', 'com/common'], function (a, b, host, tool, storage, DZ_COM) {
    var $number = $('#number'),
        $records = $('#records'),
        $btnMore = $('#btnMore');

    var pid = 0,
        uid = 0;

    var cash = 0;

    //分页参数
    var pageIndex = 1,
        pageSize = 10,
        total = 0,
        loadedLen = 0;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('cash init');
        renderHeader();
        var urlParams = tool.getQueryString();
        pid = urlParams.pid;
        uid = urlParams.uid;
        if (pid) {
            if (uid) {
                getUserInfo();
                getRecordsOfCash();
            }
            else {
                DZ_COM.getUidByPid(pid, function () {
                    getUserInfo();
                    getRecordsOfCash();
                });
            }
        }
        else {
            DZ_COM.login(function () {
                getUserInfo();
                getRecordsOfCash();
            });
        }
        bindEvents();
    }

    function bindEvents() {
        $btnMore.click(function () {
            getRecordsOfCash();
        });
    }

    function renderHeader() {
        Daze.setTitle('我的账户');
    }

    /**
     * @method getUserInfo
     * @description 获取用户信息
     */
    function getUserInfo() {
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getUserInfo.htm',
                data: DZ_COM.convertParams({
                    uid: uid
                })
            }).done(function (r) {
                if (r.code == 0) {
                    cash = r.data.userInfo.cashBalance || 0;
                    $number.text(cash);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(null, 1);
            });
        });
    }

    /**
     * @method getRecordsOfCash
     * @description 获取现金账户交易记录
     */
    function getRecordsOfCash() {
        var domId = 'records';
        DZ_COM.checkNetwork(domId, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/user/getCashRecords.htm',
                data: DZ_COM.convertParams({
                    uid: uid,
                    pageIndex: pageIndex,
                    pageSize: pageSize
                })
            }).done(function (r) {
                if (r.code == 0) {
                    pageIndex++;
                    total = r.data.total;
                    loadedLen += r.data.list.length;
                    renderRecords(r.data.list);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(domId, 1);
            });
        });
    }

    function renderRecords(records) {
        $records.append(template('recordsTmpl', {list: convertData(records)}));
        if (total > loadedLen) {
            $btnMore.show();
        }
        else {
            $btnMore.hide();
        }
        if (!total) {
            $('.tit').hide();
        }
        else {
            $('.tit').show();
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function convertData(records) {
        for (var i = 0; i < records.length; i++) {
            records[i].time = records[i].time.split(' ')[0];
        }
        return records;
    }
});