require(['lib/zepto.min', 'com/host', 'com/tools', 'com/storage', 'com/common'], function (a, host, tool, storage, DZ_COM) {
    var $sendTime = $('#sendTime'),
        $msgTitle = $('#msgTitle'),
        $msgContent = $('#msgContent'),
        $msgFrom = $('#msgFrom'),
        $shareBtn = $('#shareBtn'),
        $errBtn = $('#errBtn'),
        errImgSrc = 'images/logo.jpg',
        msgflag = {
            url: host.HOST_URL + "/msgCenter/index.html"
        }
        _succ = false,
        _messageId = 0,
        _type = 0;
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('account init');
        renderHeader();
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        var urlParams = tool.getQueryString();
        _messageId = urlParams.messageId || 0;
        _type = urlParams.type || 2;
        bindEvents();
    }

    function bindEvents() {
        $errBtn.on({ //加载失败 点击重新载入
            click : function(){
                getMsgContent();
            }
        }).trigger('click');
       
        $shareBtn.on({//分享按钮点击
            click : function(){
                Daze.share({
                    to: "23",
                    title: msgflag.title,
                    url: msgflag.url + "?messageId=" + _messageId + "&type=" + _type ,
                    image : msgflag.image
                },shareCallback);

            }
        });
        function shareCallback(){
            $.ajax({
                url: host.HOST_URL + '/notice/countSharing.htm',
                type: 'post',
                data: DZ_COM.convertParams({
                    messageId:_messageId,
                    type:_type
                })
            });
        }
    }
    function renderHeader() {
        Daze.setTitle('消息详情');
    }
    /**
     * @method getMsgContent
     * @description 获取消息内容
     * 返回字段  data : {content:'', id:'',  title:'', titleImg:'', sendTime:'', newsFrom:'' ,type:'' }
     */

    function getMsgContent(){//获取消息内容
        $errBtn.hide();
        $.ajax({
            url: host.HOST_URL + '/notice/getMessageDetail.htm',
            type: 'post',
            data: DZ_COM.convertParams({
                messageId:_messageId,
                type:_type
            }),
        }).done(function(r) {
            if (r.code == 0) {
                var _data = r.data;
                msgflag.title = _data.title;
                msgflag.image = _data.titleImg;
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
                if(Daze.isDazeClient){
                    $shareBtn.html('<img src="images/cwz_share.png" />');
                }
                $sendTime.text(_data.sendTime.substr(0,10));
                $msgTitle.text(_data.title);
                $msgContent.html(_data.content);
                $msgFrom.html('转自'+_data.newsFrom);
                $msgContent.find('img').each(function() {
                    var _f = false;
                    this.parentNode.style.textAlign = 'center';
                    this.onerror = function(){
                        if(!_f){
                            this.src = errImgSrc;
                        }
                        _f = true;
                    }
                });
            }else {
                $errBtn.show();
                Daze.showMsg(r.msg);
                return false;
            }
        }).fail(function() {
            $errBtn.show();
            DZ_COM.renderNetworkTip(null, 1);
        });
    }
});