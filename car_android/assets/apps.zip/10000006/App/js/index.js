require(['lib/zepto.min', 'lib/tpl.min', 'com/host', 'com/tools', 'com/storage', 'com/common'], function (a, b, host, tool, storage, DZ_COM) {
    var $head = $('#head'),
        $topCash = $('#topCash'),
        $topCoupon = $('#topCoupon'),
        $tab = $('#tab'),
        $records = $('#records'),
        $btnMore = $('#btnMore');

    //cash or coupon
    var pid = 0,
        uid = 0,
        type = 'cash';

    //余额
    var cash = 0,
        coupon = 0;

    //分页参数
    var pageIndex = 1,
        pageSize = 10,
        total = 0,
        loadedLen = 0;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        DZ_COM.getCurCity(function(){
            init();
        });
    }, false);

    function init() {
        console.log('account init');
        renderHeader();
        var urlParams = tool.getQueryString();
        pid = urlParams.pid;
        uid = urlParams.uid;
        if (urlParams.type) {
            type = urlParams.type;
        }
        if (pid) {
            if (uid) {
                getUserInfo();
                renderTab();
            }
            else {
                DZ_COM.getUidByPid(pid, function () {
                    getUserInfo();
                    renderTab();
                });
            }
        }
        else {
            DZ_COM.login(function () {
                getUserInfo();
                renderTab();
            });
        }
        bindEvents();
    }

    function bindEvents() {
        $tab.on('click', 'li', function () {
            var $this = $(this);
            var isCur = $this.hasClass('cur');
            if (!isCur) {
                type = $this.data('type');
                renderTab();
            }
        });
        $btnMore.click(function () {
            switch (type) {
                case 'cash':
                    getRecordsOfCash();
                    break;
                case 'coupon':
                    getRecordsOfCoupon();
                    break;
            }
        });
    }

    function renderHeader() {
        Daze.setTitle('我的账户');
    }

    function renderTab() {
        initData();
        switch (type) {
            case 'cash':
                $topCash.show();
                $topCoupon.hide();
                $head.css({
                    background: '#FF5621'
                });
                $tab.find('li').eq(0).addClass('cur').siblings().removeClass('cur');
                getRecordsOfCash();
                break;
            case 'coupon':
                $topCash.hide();
                $topCoupon.show();
                $head.css({
                    background: '#FF7121'
                });
                $tab.find('li').eq(1).addClass('cur').siblings().removeClass('cur');
                getRecordsOfCoupon();
                break;
        }
    }

    function initData() {
        pageIndex = 1;
        loadedLen = 0;
        total = 0;
        $records.empty();
        $btnMore.hide();
    }

    /**
     * @method getUserInfo
     * @description 获取用户信息
     */
    function getUserInfo() {
        DZ_COM.checkNetwork(null, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getUserInfo.htm',
                data: DZ_COM.convertParams({
                    uid: uid
                })
            }).done(function (r) {
                if (r.code == 0) {
                    cash = r.data.userInfo.cashBalance || 0;
                    coupon = r.data.userInfo.coupon;
                    $topCash.find('i').text(cash);
                    $topCoupon.find('i').text(coupon);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(null, 1);
            });
        });
    }

    /**
     * @method getRecordsOfCash
     * @description 获取现金账户交易记录
     */
    function getRecordsOfCash() {
        var domId = 'records';
        DZ_COM.checkNetwork(domId, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/user/getCashRecords.htm',
                data: DZ_COM.convertParams({
                    uid: uid,
                    pageIndex: pageIndex,
                    pageSize: pageSize
                })
            }).done(function (r) {
                if (r.code == 0) {
                    pageIndex++;
                    total = r.data.total;
                    loadedLen += r.data.list.length;
                    renderRecords(r.data.list);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(domId, 1);
            });
        });
    }

    /**
     * @method getRecordsOfCoupon
     * @description 获取代金券账户交易记录
     */
    function getRecordsOfCoupon() {
        var domId = 'records';
        DZ_COM.checkNetwork(domId, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                url: host.HOST_URL + '/activity/getBalanceRecords.htm',
                data: DZ_COM.convertParams({
                    pId: pid,
                    pageIndex: pageIndex,
                    pageSize: pageSize
                })
            }).done(function (r) {
                if (r.code == 0) {
                    pageIndex++;
                    total = r.data.total;
                    loadedLen += r.data.list.length;
                    renderRecords(r.data.list);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(domId, 1);
            });
        });
    }

    function renderRecords(records) {
        $records.append(template('recordsTmpl', {list: convertData(records)}));
        if (total > loadedLen) {
            $btnMore.show();
        }
        else {
            $btnMore.hide();
        }
        if (!total) {
            $('.tit').hide();
        }
        else {
            $('.tit').show();
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function convertData(records) {
        for (var i = 0; i < records.length; i++) {
            var changeMoney = 0;
            switch (type) {
                case 'cash':
                    changeMoney = records[i].changeCash;
                    break;
                case 'coupon':
                    changeMoney = records[i].balancePay;
                    break;
            }
            records[i].changeMoney = changeMoney;
            records[i].time = records[i].time.split(' ')[0];
            records[i].type = type;
        }
        return records;
    }
});