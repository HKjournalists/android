require(['lib/zepto.min', 'com/common'], function (a, DZ_COM) {
    var $list = $('#list'),
        $item = $list.find('li');

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('coupon how to use init');
        renderHeader();
        bindEvents();
    }
    function renderHeader() {
        Daze.setTitle('代金券问答');
    }

    function bindEvents() {
        $item.click(function () {
            var $this = $(this),
                $answer = $this.find('.answer');
            var isActive = $this.hasClass('active');
            if (isActive) {
                $this.removeClass('active');
                $answer.hide();
            }
            else {
                $this.siblings().removeClass('active');
                $this.siblings().find('.answer').hide();
                $this.addClass('active');
                $answer.show();
            }
        });
    }
});