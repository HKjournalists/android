require(['lib/zepto.min', 'lib/tpl.min', 'com/host', 'com/tools', 'com/storage', 'com/common'], function (a, b, host, tool, storage, DZ_COM) {
    var $number = $('#number'),
        $tab = $('#tab'),
        $records = $('#records'),
        $btnMore = $('#btnMore'),
        $howToUse = $('#howToUse');

    var uid = 0,
        usable = 0;//0可用1不可用

    //分页参数
    var pageIndex = 1,
        pageSize = 10,
        total = 0,
        loadedLen = 0;

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log('account init');
        renderHeader();
        var urlParams = tool.getQueryString();
        uid = urlParams.uid;
        if (uid) {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            getRecordsOfCoupon();
        }
        else {
           Daze.showMsg('uid不存在');
        }
        bindEvents();
    }

    function bindEvents() {
        $tab.on('click', 'li', function () {
            var $this = $(this);
            var isCur = $this.hasClass('cur');
            if (!isCur) {
                usable = $this.data('type');
                $this.addClass('cur').siblings().removeClass('cur');
                initData();
                getRecordsOfCoupon();
            }
        });
        $btnMore.click(function () {
            getRecordsOfCoupon();
        });

        $howToUse.click(function () {
            Daze.pushWindow('how-to-use.html');
        });
    }

    function renderHeader() {
        Daze.setTitle('我的账户');
    }

    function initData() {
        pageIndex = 1;
        loadedLen = 0;
        total = 0;
        $records.empty();
        $btnMore.hide();
    }

    /**
     * @method getRecordsOfCoupon
     * @description 获取代金券账户交易记录
     */
    function getRecordsOfCoupon() {
        var domId = 'records';
        DZ_COM.checkNetwork(domId, function () {
            $.ajax({
                url: host.HOST_URL + '/user/getCouponList.htm',
                data: DZ_COM.convertParams({
                    uid: uid,
                    pageIndex: pageIndex,
                    pageSize: pageSize,
                    isAvalid: usable
                })
            }).done(function (r) {
                if (r.code == 0) {
                    pageIndex++;
                    total = r.data.total;
                    loadedLen += r.data.list.length;
                    if (!usable) {
                        $number.text(total);
                    }
                    renderRecords(r.data.list);
                }
                else {
                    Daze.showMsg(r.msg);
                    return false;
                }
            }).fail(function () {
                DZ_COM.renderNetworkTip(domId, 1);
            });
        });
    }

    function renderRecords(records) {
        $records.append(template('recordsTmpl', {list: convertData(records), usable: usable}));
        if (total > loadedLen) {
            $btnMore.show();
        }
        else {
            $btnMore.hide();
        }
        if (!total) {
            $('.tit').hide();
        }
        else {
            $('.tit').show();
        }

        Daze.showMsg({
            type: 'loading',
            visible: false
        });
    }

    function convertData(records) {
        for (var i = 0; i < records.length; i++) {
            var status = records[i].status,
                cls = '';
            switch (status) {
                case -1://已过期
                    status = '已过期';
                    cls = 'expired';
                    break;
                case 1://使用中
                    status = '使用中';
                    cls = 'in-use';
                    break;
                case 2://已使用
                    status = '已使用';
                    cls = 'used';
                    break;
                default:
                    break;
            }

            records[i].status = status;
            records[i].cls = cls;

            records[i].beginTime = records[i].beginTime.split(' ')[0];
            records[i].endTime = records[i].endTime.split(' ')[0];
        }
        return records;
    }
});