require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/banner',
    'com/GALocalStorage',
], function (a, b,host, tool, storage, DZ_COM, list, module_banner) {
    var $container = $('#container'),timespace;
    var linkcity =  [   {
                    name:'广州',url:'http://jtzl.gzjt.gov.cn/'
                    },
                    {
                    name:'贵阳',url:'http://xkczd.gz163.cn/'
                    },
                    {
                    name:'天津',url:'http://www.tjjttk.gov.cn/'
                    },
                    {
                    name:'深圳',url:'http://xqctk.sztb.gov.cn/'
                    },
                    {
                    name:'北京',url:'http://www.bjhjyd.gov.cn/'
                    },
                    {
                    name:'杭州',url:'http://xkctk.hzcb.gov.cn/'
                    }
                ]


    document.addEventListener("DazeJSObjReady", function () {
        init();
    }, false);

    function init() {
        bindEvents();
        allresult();
    }

    function bindEvents() {

        if(window.location.hash == '#noData'){
            Daze.popTo(-99)
        }
        // 切换提醒
        $container.on('click','.yh-remind input',function(){
            var id= $(this).parent().parent().parent().parent().attr('data-id');
            var status = $(this).prop('checked');
            switchpost(id,status);
        })

        //重新查询
        $container.on('click','.btn-sm',function(){

            var id =$(this).parent().parent().attr('data-id');

            inquire(id);

        })

        // $container.on('click','.jumprenewal',function(){
        //     var cityname = $(this).parent().parent().parent().find('.bord').attr('daty-city');
        //     var url="renewal.html?cityname="+cityname;
        //     window.location.href=url;
        //     Daze.pushWindow(url);
        // })

        $container.on('click','.edit',function(){
            var self = $(this).parent().parent();
            var id=self.attr('data-id');
            var type =self.attr('data-type');
            var code = self.find('.result-code').text();
            var isRemind = self.attr('data-isRemind');
            var cityId = self.find('.bord').attr('data-city');
            var isSuccess = self.find('.result-info').attr('data-sc');
            var no = self.find('.result-code').attr('data-no');
            var nextNo = self.find('.edit').attr('data-nextNo');
            var day = self.find('.result-info').attr('data-day');
            //var name = self.find('.bigwidth').text();

            var url = 'edit.html?id='+id+'&type='+type+'&code='+code+'&isRemind='+isRemind+'&cityId='+cityId+'&isSuccess='+isSuccess+'&no='+no+'&nextNo='+nextNo+'&day='+day;
            //window.location.href=url;
            Daze.pushWindow(url);

        })

        $container.on('click','.getcitys',function(){
            var cityop = $(this).parent().parent().parent().find('.f12').text();
            //console.log(cityop);
            $.each(linkcity,function(i,k){

                if (cityop==k.name) {

                    Daze.pushWindow(k.url);
                };
            })
        })
         $container.on('click','.jumpop',function(){

            var cityop = $(this).parent().parent().parent().find('.f12').text();

            //console.log(cityop);

            $.each(linkcity,function(i,k){
                if (cityop==k.name) {
                   // console.log(k.name);
                    Daze.pushWindow(k.url);
                    //window.location.href=k.url;
                };
            })

         })

        // $container.on('click','.icon-ask',function(){
        //     Daze.showMsg('开启摇号提醒功能，下期摇号结果公布自动通知您');
        // })
        $container.on('click','.icon-ask',function(){

            $('.popup').removeClass('hidden-ani');
            setTimeout(function(){
                $('.popup').addClass('hidden-ani');
            },2000)
            // Daze.showMsg('开启摇号提醒功能，摇号结果将以短信和应用内推送的方式通知您');
        })

        $('.btn-org').on('click',function(){
            //window.location.href="index.html";
            Daze.pushWindow('index.html');
        })
    }

    function allresult() {

        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                type:'post',
                url:host.HOST_URL+ '/yaohao/list.htm',
                data:DZ_COM.convertParams({uid:storage.getUid()}),
                dataType:'json',
                success:function(r){
                    if(r.data.length){
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        $.each(r.data,function(i,k){
                            k.swtid  = "swtbox-"+ k.id;
                        })
                        var data = r.data;
                        $container.append(template('temp_result',{list:data}));
                    }
                    else{
                        window.location.hash = '#noData'
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        Daze.pushWindow('index.html')
                    }
                }
            })
        })
    }

    function  switchpost(id,status) {
        $.ajax({
            type:'post',
            url:host.HOST_URL+'/yaohao/remind.htm',
            data:DZ_COM.convertParams({
                uid:storage.getUid(),
                id:id,
                isRemind:status
            }),
            dataType:'json',
            success:function(r){
               if (status==1) {
                    Daze.showMsg('下期摇号结果公布自动通知您');
                }else {
                    Daze.showMsg('摇号提醒已关闭');
                }
            }


        })
    }

    function  inquire(id) {
        $.ajax({
            type:'post',
            url:host.HOST_URL+'/yaohao/query.htm',
            data:DZ_COM.convertParams({
                uid:storage.getUid(),
                id:id
            }),
            dataType:'json',
            success:function(r){

                $.each(r.data,function(i,k){
                    k.swtid  = "swtbox-"+ k.id;
                })
                var data = r.data;
                $container.append(template('temp_result',{list:data}));

            }
        })
    }

})