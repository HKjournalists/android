require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/mobiscroll.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/banner',
    'com/GALocalStorage',
    'js/mobiscroll.select.js'
], function (a, b,c,host, tool, storage, DZ_COM, list, module_banner) {
    var $searchlist = $('#searchlist'),data = new Array,buld={} ,$selectCity=$('#selectCity'),params={};
    var linkcity =  [   {
                    name:'广州',url:'http://jtzl.gzjt.gov.cn/'
                    },
                    {
                    name:'贵阳',url:'http://xkczd.gz163.cn/'
                    },
                    {
                    name:'天津',url:'http://www.tjjttk.gov.cn/'
                    },
                    {
                    name:'深圳',url:'http://xqctk.sztb.gov.cn/'
                    },
                    {
                    name:'北京',url:'http://www.bjhjyd.gov.cn/'
                    },
                    {
                    name:'杭州',url:'http://xkctk.hzcb.gov.cn/'
                    }
                ]

    document.addEventListener("DazeJSObjReady", function () {
        init();
    }, false);

    function init() {

        getinfo();
        getcity();
        bindEvents();
    }

    function bindEvents() {

        $selectCity.on('change',function(){
            buld.cityId =  $(this).val();
            cityName = $('#selectCity_dummy').val();
                if (cityName=='广州' || cityName=='天津' || cityName=='深圳') {

                    $('.city_bjhz').addClass('hidden');
                    $('.city_gzsztj').removeClass('hidden');
                    $('.city_gy').addClass('hidden');

                }else if(cityName == '贵阳'){

                    $('.city_bjhz').addClass('hidden');
                    $('.city_gzsztj').addClass('hidden');
                    $('.city_gy').removeClass('hidden');

                }else {
                    $('.city_bjhz').removeClass('hidden');
                    $('.city_gzsztj').addClass('hidden');
                    $('.city_gy').addClass('hidden');

                }

        })

        $('.btn-save').on('click',function(){

            postchange();

        })

        $('.control-group li').on('click',function(){
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
        })

        $searchlist.on('click','.jumprenewal',function(){
            var cityname = $('#selectCity_dummy').val();
            //console.log(cityname);
            $.each(linkcity,function(i,k){
                if (k.name==cityname) {
                    //console.log(k.name);
                    //console.log(k.url);
                    //window.location.href=k.url;
                    Daze.pushWindow(k.url);
                }
            })
        })

        $('.item-box').on('click',function(){
            $selectCity.trigger('click');
        })

        $('.btn-del').on('click',function(){

            DZ_COM.confirm({
                content : '删除该记录？',
                    yesFn : function(){

                        delrecord();

                    }
            });

        })
    }
    function getQueryStringRegExp(name){
        var reg = new RegExp("(^|\\?|&)"+ name +"=([^&]*)(\\s|&|$)", "i");

        if (reg.test(location.href)) return unescape(RegExp.$2.replace(/\+/g, " ")); return "";
    }
    function getinfo() {
        //buld.cityName = getQueryStringRegExp('cityName');
        buld.type = getQueryStringRegExp('type');
        buld.id = getQueryStringRegExp('id');
        buld.code = getQueryStringRegExp('code');
        buld.cityId = getQueryStringRegExp('cityId');
        buld.isRemind = getQueryStringRegExp('isRemind');
        buld.isSuccess = getQueryStringRegExp('isSuccess');
        buld.no = getQueryStringRegExp('no');
        buld.nextNo = getQueryStringRegExp('nextNo');
        buld.day  = getQueryStringRegExp('day');
        //buld.name  = getQueryStringRegExp('name');
        data[0] = buld;
        $searchlist.append(template('temp_list',{list:data}));
    }

    function getcity() {
        $.ajax({
            type:'post',
            url:host.HOST_URL+'/yaohao/cityInfo.htm',
            data:DZ_COM.convertParams(),
            dataType:'json',
            success:function(r){
               var datas = r.data;
               maintime = r.data;
               console.log(data[0].cityId);
                $.each(datas,function(i,item){
                    if (item.cityId==data[0].cityId) {
                        var str = "<option value="+item.cityId+" selected>"+item.cityName+"</option>";
                        $selectCity.append(str);
                        if (item.cityName=='广州' || item.cityName=='天津' || item.cityName=='深圳') {

                            $('.city_bjhz').addClass('hidden');
                            $('.city_gzsztj').removeClass('hidden');
                            $('.city_gy').addClass('hidden');

                        }else if(item.cityName == '贵阳'){

                            $('.city_bjhz').addClass('hidden');
                            $('.city_gzsztj').addClass('hidden');
                            $('.city_gy').removeClass('hidden');

                        }else {
                            $('.city_bjhz').removeClass('hidden');
                            $('.city_gzsztj').addClass('hidden');
                            $('.city_gy').addClass('hidden');

                        }
                    }else {
                    var str = "<option value="+item.cityId+">"+item.cityName+"</option>";
                        $selectCity.append(str);
                    }
                })

                $selectCity.mobiscroll().select({
                    theme:'android-ics light',
                    mode:'scroller',
                    lang: 'zh',
                    display:'bottom'
                });
            }

        })

    }

    function delrecord() {
        console.log(data[0].id);
        $.ajax({
            type:'post',
            url:host.HOST_URL+'/yaohao/del.htm',
            data:DZ_COM.convertParams({
                uid:storage.getUid(),
                id:data[0].id
            }),
            dataType:'json',
            success:function(r){
                Daze.showMsg('删除成功');
                Daze.pushWindow('result.html');
            },
            error:function(r){
                Daze.showMsg('删除失败');
            }
        })
    }

    function postchange() {

        var cityName = $('#selectCity_dummy').val();
        var code = $('.require_num').val();
        var type= $('.control-group li').filter('.active').attr('data-type');
        var cityId= $('#selectCity').val();
        var id = $('.search-main').attr('data-id');
        DZ_COM.checkNetwork(null, function () {
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            $.ajax({
                type:'post',
                url:host.HOST_URL+'/yaohao/save.htm',
                data:DZ_COM.convertParams({
                    uid: storage.getUid(),
                    id:id,
                    code:code,
                    type:type,
                    cityId:cityId,
                    cityName:cityName
                }),
                dataType:'json',
                success:function(r){
                    Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                    Daze.showMsg('保存成功');
                    Daze.pushWindow('result.html');
                },
                error:function(r){
                     Daze.showMsg('保存失败');
                }
            })
        })
    }




})