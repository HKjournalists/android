require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/banner',
    'com/GALocalStorage',
], function (a, b,host, tool, storage, DZ_COM, list, module_banner) {
    var $container = $('#container'),timespace;
        

    document.addEventListener("DazeJSObjReady", function () {
        init();
    }, false);

    function init() {
        bindEvents(); 
        //allresult();
    }

    function bindEvents() {
        // 切换提醒
        // $container.on('click','.yh-remind input',function(){
        //     var id= $(this).parent().parent().parent().parent().attr('data-id');
        //     var status = $(this).prop('checked');
        //     switchpost(id,status);
        // })




        // $container.on('click','.icon-ask',function(){
        //     Daze.showMsg('开启摇号提醒功能，下期摇号结果公布自动通知您');
        // })


    }





})