require([
    'lib/zepto.min',
    'lib/tpl.min',
    'lib/mobiscroll.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'com/modules/banner',
    'com/GALocalStorage',
    'js/mobiscroll.select.js'
], function (a, b,c,host, tool, storage, DZ_COM, list, module_banner) {
    var $selectCity = $('#selectCity'),
        $record = $('.main-content'),
        $searchlist = $('#searchlist'),
        $btndel = $('.btn-dels'),
        $btnadd = $('.btn-add'),
        maintime;
        var linkcity =  [   {
                    name:'广州',url:'http://jtzl.gzjt.gov.cn/'
                    },
                    {
                    name:'贵阳',url:'http://xkczd.gz163.cn/'
                    },
                    {
                    name:'天津',url:'http://www.tjjttk.gov.cn/'
                    },
                    {
                    name:'深圳',url:'http://xqctk.sztb.gov.cn/'
                    },
                    {
                    name:'北京',url:'http://www.bjhjyd.gov.cn/'
                    },
                    {
                    name:'杭州',url:'http://xkctk.hzcb.gov.cn/'
                    }
                ]
    document.addEventListener("DazeJSObjReady", function () {
        DZ_COM.login(function(){
            init();
        })
    }, false);

    function init() {
        getcity();
        bindEvents();
    }

    function bindEvents() {
        $selectCity.on('change',function(){
            //alert('1');
            var cityName = $('#selectCity_dummy').val();
            console.log(maintime);
            $.each(maintime,function(i,k){

                if (k.cityName ==cityName) {
                    $('.flow-tips p em').text(k.publishTime);
                    $('.timeinfo').text(k.valid);
                    $('.cityinfo').text(k.cityName);
                }
                if (cityName=="贵阳") {
                    $('.southarea').addClass('hidden');
                    $('.normalarea').addClass('hidden');
                    $('.allowxq').removeClass('hidden');
                    $('.spforgz').removeClass('hidden');
                } else if (cityName == "广州" ||cityName == "深圳" || cityName == "天津") {
                    $('.spforgz').addClass('hidden');
                    $('.normalarea').addClass('hidden');
                    $('.southarea').removeClass('hidden');
                    $('.allowxq').removeClass('hidden');
                }else {
                    $('.spforgz').addClass('hidden');
                    $('.normalarea').removeClass('hidden');
                    $('.southarea').addClass('hidden');
                    $('.allowxq').removeClass('hidden');
                }
            })
        })

        $('.control-group li').on('click',function(){
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
        })

        $('.linkop').on('click',function(){
            var opcity = $('#selectCity_dummy').val();

            $.each(linkcity,function(i,k){
                if (opcity == k.name) {

                    Daze.pushWindow(k.url);
                    //window.location.href=k.url;
                };
            })
        })

        $('.item-box').on('click',function(){
            $selectCity.trigger('click');
        })

        $searchlist.on('click','.icon-ask',function(){

            $('.popup').removeClass('hidden-ani');
            setTimeout(function(){
                $('.popup').addClass('hidden-ani');
            },2000)
            // Daze.showMsg('开启摇号提醒功能，摇号结果将以短信和应用内推送的方式通知您');
        })

        $('.btn-normal').on('click',function(){

            collectinfo();

        })

        // $('.renewal').on('click',function(){
        //     var cityname = $('#selectCity').val();

        //     //console.log(cityname)
        //     url='renewal.html?citynam1e='+cityname;
        //     Daze.pushWindow(url);
        //     window.location.href=url;
        // })
        $('#swtbox-2').click(function(){
            var stat = $(this).prop('checked');
            if (stat) {
                $('.switch-prs').text('单位');
            }else {
                $('.switch-prs').text('个人');
            }
        })
        $('#swtbox-1').click(function(){

            var status =$(this).prop('checked');
            if (status) {
                Daze.showMsg('下期摇号结果公布自动通知您');
                //console.log('1');

            }else {
                Daze.showMsg('摇号提醒已关闭');
                //console.log('0');
            }

        })
    }

    //获取摇号城市
    function getcity() {
        var hascity = storage.getCurCity().name;
        //console.log(hascity.name);
       // console.log(hascity);
        $('.cityinfo').text(hascity);
        $.ajax({
            type:'post',
            url:host.HOST_URL+'/yaohao/cityInfo.htm',
            data:DZ_COM.convertParams(),
            dataType:'json',
            success:function(r){
                $('.flow-tips p em').text(r.data[0].publishTime);
               var data = r.data;
               maintime = r.data;
                $.each(data,function(i,item){

                    if (hascity=="贵阳") {
                        $('.southarea').addClass('hidden');
                        $('.normalarea').addClass('hidden');
                        $('.allowxq').removeClass('hidden');
                        $('.spforgz').removeClass('hidden');
                    } else if (hascity == "广州" ||hascity == "深圳" || hascity == "天津") {
                        $('.spforgz').addClass('hidden');
                        $('.normalarea').addClass('hidden');
                        $('.southarea').removeClass('hidden');
                        $('.allowxq').removeClass('hidden');
                    }else {
                        $('.spforgz').addClass('hidden');
                        $('.normalarea').removeClass('hidden');
                        $('.southarea').addClass('hidden');
                        $('.allowxq').removeClass('hidden');
                    }
                    if (hascity == item.cityName) {
                        var str = "<option value="+item.cityId+" selected>"+item.cityName+"</option>";
                        $selectCity.append(str);

                    }else {
                        var str = "<option value="+item.cityId+">"+item.cityName+"</option>";
                        $selectCity.append(str);
                    }

                })

                $('#selectCity').mobiscroll().select({
                    theme:'android-ics light',
                    mode:'scroller',
                    lang: 'zh',
                    display:'bottom'
                });
            }

        })

    }

    function collectinfo() {

        // DZ_COM.checkNetwork(null, function () {
        //     Daze.showMsg({
        //         type: 'loading',
        //         visible: true
        //     });

            k = $('.search-main');
            var code = k.find('.require_num').val();
            var type = k.find('.control-group li').filter('.active').attr('data-type');
            // console.log(type);
            var isRemind = Number(k.find('.switch-box input').prop('checked'));
            var cityId = $selectCity.val();
            var cityName = $('#selectCity_dummy').val();

            if (code.length == 0 || code.length < 13) {
                Daze.showMsg('请输入13位申请编码');
                console.log(code.length)
            }else {

                $.ajax({
                    type:'post',
                    url:host.HOST_URL+'/yaohao/save.htm',
                    data:DZ_COM.convertParams({
                        uid: storage.getUid(),
                        code:code,
                        type:type,
                        isRemind:isRemind,
                        cityId:cityId,
                        cityName:cityName
                    }),
                    dataType:'json',
                    success:function(r){

                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        Daze.pushWindow('result.html');

                    }
                })

            }
        // })
    }

})