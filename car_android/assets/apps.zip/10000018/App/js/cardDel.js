/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'Bcode',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM,Bcode) {
    var domId = 'mainBox',
        _re = common.getObj(),
        $mainBox = $('#mainBox');
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log(_re);
        renderTmpl();
        renderHeader();
        bindEvents();

        document.addEventListener('daze_addBankCard', function(e) {
            var data = e.eventData;
            setBankCard(data);
        });

        ga_storage._trackPageview('insurancefinal/bankList', "汽车服务-橙牛车险管家-选择付款银行卡");
    }

    function bindEvents() {
        $mainBox.on({
            click : function(){
                var _t = $('.value',this).text(),
                    _index = $(this).attr('data-index'),
                    _arr = _re.bankCardList,
                    _code = _arr[_index].code;
                DZ_COM.confirm({
                    title : "删除提示？",
                    'yesBtn' : '是',
                    'noBtn' : '否',
                    content : "是否删除"+_t,
                    yesFn : function(){
                        Daze.showMsg({
                            type: 'loading',
                            visible: true
                        });
                        $.ajax({
                            url: common.HOST_URL + '/server/app/bank/card/del.htm',
                            data : {
                                data : "{'providerId' : '"+_re.uid+"','code':'"+_code+"'}"
                            },
                            dataType : 'json',
                            type : 'post',
                            success : function(r){
                                if(r.code == '0'){
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: false
                                    });
                                    _arr.splice(_index,1);
                                    common.setObj('bankCardList',_arr);
                                    if(typeof _re.bankChecked != 'undefined' && typeof _re.bankChecked.code != 'undefined' && _re.bankChecked.code == _code){
                                            common.removeItem('bankChecked');
                                    }
                                    Daze.system.postObserver({
                                        name: 'daze_delBankCard',
                                        eventData: {
                                            result : 'delBankOk'
                                        }
                                    });
                                    if(_arr.length > 0){
                                        location.reload();
                                    }else{
                                        Daze.system.addObserver({
                                            name: 'daze_addBankCard'
                                        });
                                        Daze.pushWindow({
                                            appId : common.appId,
                                            url : 'cardAdd.html?type=addEmpty'
                                        });
                                        location.reload();
                                    }
                                }else{
                                    Daze.showMsg(r.msg);
                                }
                            }
                        });
                    }
                });
            }
        },'dd').on({
            click : function(){
                Daze.system.addObserver({
                    name: 'daze_addBankCard'
                });
                if(typeof _re.bankCardList != 'undefined' && _re.bankCardList.length != 0){
                    Daze.pushWindow("");
                    Daze.pushWindow({
                        appId : common.appId,
                        url : 'cardAdd.html?type=add'
                    });
                }else{
                    Daze.pushWindow({
                        appId : common.appId,
                        url : 'cardAdd.html?type=addEmpty'
                    });
                }
            }
        },'#cardAdd');
    }

    function setBankCard(data) {
        document.removeEventListener('daze_addBankCard', function(e) {
            setBankCard(e.data);
        });
        if(DZ_COM.getSystem() == 'ios'){
            if(data.result == "addBankOk"){
                location.reload();
            }
        }
    }

    function renderTmpl(){
        $mainBox.html(template('listTmpl', {
            data: _re.bankCardList || []
        }));
    }

    function renderHeader() {
        Daze.setTitle('管理银行卡');
    }

});
