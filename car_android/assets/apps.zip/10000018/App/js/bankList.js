/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'Bcode',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM,Bcode) {
    var domId = 'mainBox',
        _re = common.getObj(),
        $mainBox = $('#mainBox');
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log(_re);
        renderTmpl();
        renderHeader();
        bindEvents();

        document.addEventListener('daze_addBankCard', function(e) {
            var data = e.eventData;
            setBankCard(data);
        });

        document.addEventListener('daze_delBankCard', function(e) {
            var data = e.eventData;
            delBankCard(data);
        });

        Daze.system.addObserver({
            name: 'daze_delBankCard'
        });
        Daze.system.addObserver({
            name: 'daze_addBankCard'
        });

        ga_storage._trackPageview('insurancefinal/bankList', "汽车服务-橙牛车险管家-选择付款银行卡");
    }

    function bindEvents() {
        $mainBox.on({
            click : function(){
                var _index = $(this).attr('data-index');
                Daze.system.postObserver({
                    name: 'daze_bankChecked',
                    eventData: _re.bankCardList[_index]
                });
                common.setObj("bankChecked",_re.bankCardList[_index]);
                Daze.popTo(-1);
            }
        },'dd').on({
            click : function(){
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'cardAdd.html?type=add'
                });
            }
        },'#cardAdd').on({
            click : function(){
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'cardDel.html'
                });
            }
        },'dt.del');
    }

    function setBankCard(data) {
        document.removeEventListener('daze_addBankCard', function(e) {
            setBankCard(e.data);
        });
        if(DZ_COM.getSystem() == 'ios'){
            if(data.result == "addBankOk"){
                location.reload();
            }
        }
    }

    function delBankCard(data){
        document.removeEventListener('daze_delBankCard', function(e) {
            setBankCard(e.data);
        });
        if(DZ_COM.getSystem() == 'ios'){
            if(data.result == "delBankOk"){
                location.reload();
            }
        }
    }

    function renderTmpl(){
        $mainBox.html(template('listTmpl', {
            data: _re.bankCardList || []
        }));
    }

    function renderHeader() {
        Daze.setTitle('选择付款银行卡');
    }

});
