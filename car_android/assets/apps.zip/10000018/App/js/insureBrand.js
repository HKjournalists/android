/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM) {
    var domId = 'mainBox',
        _re = common.getObj(),
        lists = [],
        _type = tool.getQueryString(),
        $mainBox = $('#mainBox');
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        /*if(typeof _re.brandIndex == 'undefined'){
            Daze.popTo(-1);
        }*/
        renderHeader();
        renderTempl();
        bindEvents();
        ga_storage._trackPageview('insurancefinal/insureBrand', "汽车服务-橙牛车险管家-选择保险公司");
    }

    function bindEvents() {
        $mainBox.on({
            click : function(){
                var index = $(this).attr('data-index'),
                    _data = lists[index];
                if(typeof _re.baoxianCompanyCode == 'undefined' || _re.baoxianCompanyCode!=_data.code){
                    Daze.system.postObserver({
                        name: 'daze_insureBrandEvent',
                        eventData: {
                            baoxianCompanyCode : _data.code,
                            baoxianCompanyName : _data.name,
                            baoxianCompanyPic : _data.pic,
                            baoxianCompanyRemark : _data.remark
                        }
                    });
                    common.setObj('baoxianCompanyCode',_data.code);
                    common.setObj('baoxianCompanyName',_data.name);
                    common.setObj('baoxianCompanyPic',_data.pic);
                    common.setObj('baoxianCompanyRemark',_data.remark);
                }
                if(_type && _type.type){
                    common.setObj('reReport','true');
                    Daze.pushWindow({
                        appId : common.appId,
                        url : 'insure.html'
                    });
                }else{
                    Daze.popTo(-1);
                }
                
            }
        },'.resultBox dd');
    }

    function renderHeader() {
        Daze.setTitle('选择保险公司');
    }

    function renderTempl() {
        lists = _re.companyInfo; 
        //初始化写入 
        $mainBox.html(template('insureBrandTmpl', {
            data: lists
        }));
    }
});
