/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM) {
    var domId = 'mainBox',
        _re = common.getObj(),
        _req = tool.getQueryString(),
        $mainBox = $('#mainBox');
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        console.log(_re);
        if(typeof _re.bankChecked == 'undefined' && typeof _re.bankCardList != 'undefined' && _re.bankCardList.length > 0){
            common.setObj('bankChecked',_re.bankCardList[0]);
            _re = common.getObj();
        }
        renderHeader();
        if(typeof _re.bankCardList == 'undefined' || _re.bankCardList.length == 0){
            renderAddCard();
        }else{
            renderContent();
            checkHasOrderPay();
        }
        
        bindEvents();
        document.addEventListener('daze_addBankCard', function(e) {
            var data = e.eventData;
            setBankCard(data);
        });

        document.addEventListener('daze_delBankCard', function(e) {
            var data = e.eventData;
            delBankCard(data);
        });

        Daze.system.addObserver({
            name: 'daze_delBankCard'
        });
        Daze.system.addObserver({
            name: 'daze_addBankCard'
        });
        
        document.addEventListener('daze_bankChecked', function(e) {
            var data = e.eventData;
            if(!data){
                data = common.getObj("bankChecked");
            }
            setBankChecked(data);
        });
        ga_storage._trackPageview('insurancefinal/orderPay', "汽车服务-橙牛车险管家-确认支付");
    }

    function checkHasOrderPay(){//判断订单是否处于支付状态
        common.checkOrder(_re.baoxianUnderwritingReportId,function(a,b,c){
            var _t = Math.ceil((new Date().getTime() - b)/1000),
                $_ipt = $('#orderPay');
                _djs = null;
            if(_t >= 300){
                common.delOrder(_re.baoxianUnderwritingReportId);
                //让订单详情页面刷新
                Daze.system.postObserver({
                    name: 'daze_delOrder',
                    eventData: {
                        result : 'delOk'
                    }
                });
            }else{
                $_ipt.addClass('disabled').attr('disabled','disabled');
                _djs = setInterval(function(){
                    if(_t >= 300){
                        $_ipt.removeClass('disabled').removeAttr('disabled');
                        clearInterval(_djs);
                        common.delOrder(_re.baoxianUnderwritingReportId);
                        //让订单详情页面刷新
                        Daze.system.postObserver({
                            name: 'daze_delOrder',
                            eventData: {
                                result : 'delOk'
                            }
                        });
                    }
                    _t = _t + 1;
                    console.log(_t);
                },1000);
            }
        });
    }

    function setBankCard(data) {
        document.removeEventListener('daze_addBankCard', function(e) {
            setBankCard(e.data);
        });
        if(DZ_COM.getSystem() == 'ios'){
            if(data.result == "addBankOk"){
                location.reload();
            }
        }
    }

    function delBankCard(data){
        document.removeEventListener('daze_delBankCard', function(e) {
            setBankCard(e.data);
        });
        if(DZ_COM.getSystem() == 'ios'){
            if(data.result == "delBankOk"){
                location.reload();
            }
        }
    }

    function showTips(){
        $mainBox.find('#showTips').removeClass('hidden').find('.content').css({
            height : (function(){
                var _H = $(window).height(),
                _h = $mainBox.find('#showTips .content').height();
                return _h > _H * 0.9 ? _H*0.9 : _h ;
            }()),
            marginTop : (function(){
                var _H = $(window).height(),
                _h = $mainBox.find('#showTips .content').height(),
                __h = _h > _H * 0.9 ? _H*0.9 : _h ;
                return -__h*0.5
            }()),
            top : (function(){
                var _H = $(window).height();
                return _H*0.5
            }())
        });
    }

    function setBankChecked(data){
        document.removeEventListener('daze_bankChecked', function(e) {
            setBankChecked(e.data);
        });
        var _tp = data.bankCardType=="01"?"储蓄卡":"信用卡";
        $mainBox.find('.payWay .value').html(data.bankName+'&nbsp;'+_tp+'('+data.cardNo.substr(data.cardNo.length-4,data.cardNo.length)+')');
    }

    function bindEvents() {
        $mainBox.on({
            click : function(){
                Daze.system.addObserver({
                    name: 'daze_bankChecked'
                });
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'bankList.html'
                });
            }
        },'.payWay').on({
            click : function(){
                payOrder();
            }
        },'#orderPay').on({
            click : function(){
                $(this).parent().addClass('hidden');
            }
        },'#showTips .mask').on({
            click : function(){
                if(_req && typeof _req.type != 'undefined' && _req.type=='ord'){
                    Daze.popTo(-2);
                }else{
                    Daze.popTo(-1);
                }
            }
        },'#showTips .btn').on({
            click : function(){
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'cardAdd.html?type=add'
                });
            }
        },'#cardAdd');
    }

    function payOrder(){
        Daze.showMsg({
            type: 'loading',
            visible: true,
            text : '提交中...'
        });
        DZ_COM.checkNetwork(domId, function() {
            $.ajax({
                url: host.HOST_URL + "/appclient/baoxian/pay.htm",
                data: DZ_COM.convertParams({
                    userId: _re.uid,
                    id : _re.baoxianUnderwritingReportId,
                    bankNo : common.getObj().bankChecked.code
                }),
                success: function(r) {
                    var _arr = [];
                    if(r.code == "0" && r.data.result === true){
                        Daze.showMsg('提交成功');
                        common.addOrder(_re.baoxianUnderwritingReportId,new Date().getTime());
                        $('#orderPay').addClass('disabled').attr('disabled','disabled');
                        checkHasOrderPay();
                        showTips();
                        Daze.system.postObserver({
                            name: 'daze_payStatus',
                            eventData: {
                                result : 'payOk'
                            }
                        });
                        common.setObj('_payStatus',{
                            result : 'payOk'
                        });
                    }else{
                        Daze.showMsg('提交失败');
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-立即支付', '/appclient/baoxian/pay.htm', '成功');
                },
                error: function(r) {
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-立即支付', '/appclient/baoxian/pay.htm', '失败');
                }
            });
        });
        
    }

    function renderContent(){
        $mainBox.html(template('orderTmpl', {
            data: _re
        }));
    }

    function renderAddCard(){
        $mainBox.html(template('addCardTmpl'));
    }

    function renderHeader() {
        Daze.setTitle('确认支付');
    }

});
