require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM) {

    var domId = 'mainBox',
        _re = common.getObj(),
        _flag = false,
        _query = tool.getQueryString(),
        $mainBox = $('#mainBox');

    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);


    function init() {
        console.log(_re);
        renderHeader();
        renderTempl(_re);
        getList('province',0);
        bindEvents();
        ga_storage._trackPageview('insurancefinal/delivery', "汽车服务-橙牛车险管家-确认配送信息");
    }

    function getList(type,level, cityCode) {
        cityCode = cityCode || '';
        DZ_COM.checkNetwork(domId, function() {
            var data = {
                level: level
            };
            if (cityCode) {
                data.cityCode = cityCode;
            }
            $.ajax({
                url: host.HOST_URL + "/appclient/common/queryCity.htm",
                data: DZ_COM.convertParams(data),
                success: function(r) {
                    if (r.code == '0' && r.data) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        if(r.data.length > 0){
                            renderList(type, r.data);
                        }else{
                            if(level == 1){
                                $('#city').html('<option value='+cityCode+' selected="selected">市</option>').attr('data-name','市');
                                $('#district').html('<option value='+cityCode+' selected="selected">区</option>').attr('data-name','区');
                            }
                            if(level == 2){
                                $('#district').html('<option value='+cityCode+' selected="selected">区</option>').attr('data-name','区');
                            }
                        }
                        
                    } else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-选择城市', '/appclient/common/queryCity.htm', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-选择城市', '/appclient/common/queryCity.htm', '失败');
                }
            });
        });
    }

    function renderList(type, list) {
        var tmpl = template('optionTmpl', {
                list: list,
                type: type
            }),
            $province = $('#province'),
            $city = $("#city"),
            $district = $('#district');
        switch (type) {
            case 'province':
                if(!_flag && _re.cityCode){
                    var n = 0;
                    for(var i = 0 ; i < list.length ; i++){
                        if(_re.cityCode.substr(0,3) == list[i].cityCode.substr(0,3)){
                            n = i;
                        }
                    }
                    $province.html(tmpl).attr('data-name',list[n].cityName).val(list[n].cityCode);
                    getList('city' , 1 , list[n].cityCode);
                }else{
                    $province.html(tmpl).attr('data-name',list[0].cityName);
                    getList('city' , 1 , $province.val());
                }
                break;
            case 'city':
                if(!_flag && _re.cityCode){
                    var n = 0;
                    for(var i = 0 ; i < list.length ; i++){
                        if(_re.cityCode== list[i].cityCode){
                            n = i;
                        }
                    }
                    $city.html(tmpl).attr('data-name',list[n].cityName).val(list[n].cityCode);
                    getList('district' , 2 , list[n].cityCode);
                    _flag = true;
                }else{
                    $city.html(tmpl).attr('data-name',list[0].cityName);
                    getList('district' , 2 , $city.val());
                }
                break;
            case 'district':
                $district.html(tmpl).attr('data-name',list[0].cityName);
                break;
        }
    }

    function renderTempl(data){
        var _type = 'before';
        if(_query && typeof _query.type != 'undefined' && _query.type == 'saveAddress'){
            _type = 'after';
        }
        $mainBox.html(template('deliveryTmpl',{
            data : data,
            type : _type
        }));
    }

    function saveOrders(id){
        if(!common.getObj('payInfo')){
            var _data = common.getObj();
            DZ_COM.checkNetwork(domId, function() {
                $.ajax({
                    url: host.HOST_URL + "/appclient/baoxian/saveOrders.htm",
                    data: DZ_COM.convertParams({
                        id : id,
                        userId : _data.uid
                    }),
                    success: function(r) {
                        if (r.data && r.data.result && r.data.id) {
                            common.setObj('payInfo',r.data);
                            common.setObj('orderStatus','1');
                            common.setObj('payStatus','0');
                            payOrder();
                        } else {
                            if(r.data.message){
                                Daze.showMsg(r.data.message);
                            }
                        }
                        console.log(r);
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-提交订单', '/appclient/baoxian/saveOrders.htm', '成功');
                    },
                    error: function(r) {
                        DZ_COM.renderNetworkTip(domId, 1);
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-提交订单', '/appclient/baoxian/saveOrders.htm', '失败');
                    }
                });
            });
        }else{
            payOrder();
        }
    }

    function payOrder(){
        var _info = common.getObj('payInfo');
        if(!_info.id){
            return;
        }
        Daze.system.addObserver({
            name: 'daze_payStatus'
        });
        $.ajax({
            url: common.HOST_URL + '/server/app/bank/card/list.htm',
            data : {
                data:"{'providerId':'"+_re.uid+"'}"
            },
            dataType : 'json',
            type : 'post',
            success : function(r){
                Daze.showMsg({
                    type: 'loading',
                    visible: false
                });
                if(r.code == '0' && r.data && r.data.length > 0){
                    Daze.pushWindow({
                        appId : common.appId,
                        url : 'orderPay.html?type=ord'
                    });
                    common.setObj('bankCardList',r.data);
                }else{
                    common.setObj('bankCardList',[]);
                    Daze.pushWindow({
                        appId : common.appId,
                        url : 'cardAdd.html'
                    });
                }
            }
        });
    }


    function bindEvents() {
        var $province = $('#province'),
            $city = $("#city"),
            $district = $('#district');
        $mainBox.on({
            click : function(){
                saveAddress.call(this);
            }
        },'input[name=saveAddress]');

        // 选择省份
        $province.change(function () {
            console.log('province changed');
            $(this).attr('data-name',$(this).find('option:selected').html());
            getList('city', 1  , $(this).val());
        });

        // 选择城市
        $city.change(function () {
            console.log('city changed');
            $(this).attr('data-name',$(this).find('option:selected').html());
            getList('district', 2 , $(this).val());
        });

        //区域选择
        $district.change(function () {
            console.log('district changed');
            $(this).attr('data-name',$(this).find('option:selected').html());
        });

        $('input').on('blur',function(){
            this.value = this.value.replace(/\s/g,'');
        });

    }


    function saveAddress() {
        var _me = this,
            _reData = {
                result : 'reportOk'
            },
            data = validate();
        if (!data) {
            return false;
        }
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        DZ_COM.checkNetwork(domId, function() {
            $.ajax({
                url: host.HOST_URL + "/appclient/baoxian/report.htm",
                data: DZ_COM.convertParams(common.getObj('myReportDate')),
                success: function(r) {
                        console.log(r);
                    if (r.code == '0' && r.data && r.data.result) {
                        /*if(common.getObj('reReport')){
                            
                        }*/
                        Daze.system.postObserver({
                            name: 'daze_reRepotEvent',
                            eventData: _reData
                        });
                        common.setObj('_reRepotEvent',_reData);
                        Daze.system.postObserver({
                            name: 'daze_orderAdd',
                            eventData: {
                                result : 'addOk'
                            }
                        });
                        common.setObj('bjing','ed');
                        common.removeItem('reReport');
                        common.setObj('id',r.data.id);
                        storage.clearItem('bxlsit');
                        data.provinceName = $('select[name=provinceCode]').attr('data-name');
                        data.cityName = $('select[name=cityCode]').attr('data-name');
                        data.townName = $('select[name=townCode]').attr('data-name');
                        data.baoxianUnderwritingId = r.data.id;
                        data.userId = _re.uid;
                        DZ_COM.checkNetwork(domId, function() {
                            $.ajax({
                                url: host.HOST_URL + "/appclient/baoxian/peisong.htm",
                                data: DZ_COM.convertParams(data),
                                success: function(r) {
                                    console.log(r);
                                    if (r.code == '0' && r.data && r.data.result) {
                                        Daze.showMsg({
                                            type: 'loading',
                                            visible: false
                                        });
                                        Daze.system.postObserver({
                                            name: 'daze_saveAddress',
                                            eventData: {
                                                result : 'saveOk'
                                            }
                                        });
                                        common.setObj('saveAddress',{
                                            result : 'saveOk'
                                        });
                                        $(_me).addClass('disabled').attr('disabled','disabled');
                                        Daze.pushWindow('underWriting.html');
                                        //saveOrders(_re.baoxianUnderwritingReportId);
                                    } else {
                                        Daze.showMsg(r.msg);
                                    }
                                    ga_storage._trackEvent('汽车服务-橙牛车险管家-配送地址', 'appclient/baoxian/peisong.htm', '成功');
                                },
                                error: function(r) {
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: false
                                    });
                                    DZ_COM.renderNetworkTip(domId, 1);
                                    ga_storage._trackEvent('汽车服务-橙牛车险管家-配送地址', 'appclient/baoxian/peisong.htm', '失败');
                                }
                            });
                        });
                        //Daze.pushWindow("underWriting.html");
                    } else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-核保', '/appclient/baoxian/report.htm', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-核保', '/appclient/baoxian/report.htm', '失败');
                }
            });
        });
    }

    function getData() {
        var formData = tool.getFormDataAsObj($('form'));
        return formData;
    }

    function validate() {
        var data = getData(),
            phoneReg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/, // 11位手机号码
            valid = true;

        for (var i in data) {
            var value = data[i],
                $item = $('[name=' + i + ']'),
                require = $item.data('require'),
                nullMsg = $item.data('null'),
                errorMsg = $item.data('error'),
                ruleName = $item.data('rule') || '',
                rule = eval(ruleName);

            if (require) {
                if (!value) {
                    valid = false;
                    console.log(nullMsg);
                    Daze.showMsg(nullMsg);
                    break;
                } else if (ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            } else {
                if (value && ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            }
        }
        return valid ? data : false;
    }

    function renderHeader() {
        Daze.setTitle('确认配送信息');
    }
});
