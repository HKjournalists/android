/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'Bcode',
    'inputFoucs',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM,Bcode,InputFoucs) {
    var domId = 'mainBox',
        _re = common.getObj(),
        _flag = false,
        _query = tool.getQueryString(),
        _InputFoucs = null,
        $mainBox = $('#mainBox');
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        bindEvents();
        if(DZ_COM.getSystem() == 'android'){
           _InputFoucs = new InputFoucs();
        }
        getList('province',0);
        ga_storage._trackPageview('insurancefinal/cardAdd', "汽车服务-橙牛车险管家-设置付款方式");
    }

    function getList(type,level, cityCode) {
        DZ_COM.checkNetwork(domId, function() {
            var data = {
                level: level
            };
            if (cityCode) {
                data.cityCode = cityCode;
            }
            $.ajax({
                url: host.HOST_URL + "/appclient/common/queryCity.htm",
                data: DZ_COM.convertParams(data),
                success: function(r) {
                    if (r.code == '0') {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        renderList(type, r.data);
                    } else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-选择城市', '/appclient/common/queryCity.htm', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-选择城市', '/appclient/common/queryCity.htm', '失败');
                }
            });
        });
    }

    function renderList(type, list) {
        var tmpl = template('optionTmpl', {
                list: list,
                type: type
            }),
            $province = $('#province'),
            $city = $("#city");
        switch (type) {
            case 'province':
                if(!_flag && _re.cityCode){
                    var n = 0;
                    for(var i = 0 ; i < list.length ; i++){
                        if(_re.cityCode.substr(0,3) == list[i].cityCode.substr(0,3)){
                            n = i;
                        }
                    }
                    $province.html(tmpl).attr('data-name',list[n].cityName).val(list[n].cityCode);
                    getList('city' , 1 , list[n].cityCode);
                }else{
                    $province.html(tmpl).attr('data-name',list[0].cityName);
                    getList('city' , 1 , $province.val());
                }
                break;
            case 'city':
                if(!_flag && _re.cityCode){
                    var n = 0;
                    for(var i = 0 ; i < list.length ; i++){
                        if(_re.cityCode== list[i].cityCode){
                            n = i;
                        }
                    }
                    $city.html(tmpl).attr('data-name',list[n].cityName).val(list[n].cityCode);
                    _flag = true;
                }else{
                    $city.html(tmpl).attr('data-name',list[0].cityName);
                }
                break;
        }
    }

    function bindEvents() {
        var $province = $('#province'),
            $city = $("#city");
        $mainBox.on({
            click : function(){
                saveAddress();
            }
        },'input[name=saveCard]').on({
            change : function(){
                var _val = this.value;
                $mainBox.find('select[name=bankName]').html(template('optionTmplre', {
                    data : _val
                }));
            }
        },'select[name=bankCardType]');
        // 选择省份
        $province.change(function () {
            console.log('province changed');
            $(this).attr('data-name',$(this).find('option:selected').html());
            getList('city', 1  , $(this).val());
        });

        // 选择城市
        $city.change(function () {
            console.log('city changed');
            $(this).attr('data-name',$(this).find('option:selected').html());
        });
    }

    function renderHeader() {
        Daze.setTitle('添加银行卡');
    }

    function getData() {
        var formData = tool.getFormDataAsObj($('form'));
            formData['bankProvince'] = $('#province').attr('data-name');
            formData['bankCity'] = $('#city').attr('data-name');
        return formData;
    }

    function validate() {
        var data = getData(),
            _relu = {
                phoneReg : /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/ // 11位手机号码
            },
            valid = true;
        for (var i in data) {
            var value = data[i],
                $item = $('[name=' + i + ']'),
                require = $item.data('require'),
                nullMsg = $item.data('null'),
                errorMsg = $item.data('error'),
                ruleName = $item.data('rule') || '',
                rule = _relu[ruleName];

            if (require) {
                if(value == '-1'){
                    valid = false;
                    console.log(nullMsg);
                    Daze.showMsg(nullMsg);
                    break;
                }
                if (!value) {
                    valid = false;
                    console.log(nullMsg);
                    Daze.showMsg(nullMsg);
                    break;
                } else if (ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            } else {
                if (value && ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            }
        }
        return valid ? data : false;
    }

    function saveAddress() {
        var _me = this,
            data = validate(),
            bankName = data.bankName,
            _arr = [];
        if (!data) {
            return false;
        }
        delete data.bankName;
        for(var t in data){
            _arr.push(t+'='+data[t]);
        }
        _arr = Bcode.doEncode(_arr.join('&'));
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        $.ajax({
            url: common.HOST_URL + '/server/app/bank/card/put.htm',
            data : {
                data : "{'data' : '"+_arr+"','bankName' : '"+bankName+"' ,'providerId' : '"+_re.uid+"','bankCardType' : '"+data.bankCardType+"','token':'cao'}"
            },
            dataType : 'json',
            type : 'post',
            success : function(r){
                if(r.code == '0'){
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    var _list = common.getObj('bankCardList') || [],
                        _card = {
                            bankCardType: data.bankCardType,
                            bankName: bankName,
                            cardNo: '********'+data.bankCardNo.substr(data.bankCardNo.length-4,data.bankCardNo.length),
                            code: r.data
                        };
                    _list.push(_card);
                    common.setObj('bankCardList',_list);
                    $('form')[0].reset();
                    if(_query && _query.type && _query.type == 'add'){
                        Daze.popTo(-1);
                        Daze.system.postObserver({
                            name: 'daze_addBankCard',
                            eventData: {
                                result : 'addBankOk'
                            }
                        });
                    }else if(_query && _query.type && _query.type == 'addEmpty'){
                        Daze.system.postObserver({
                            name: 'daze_addBankCard',
                            eventData: {
                                result : 'addBankOk'
                            }
                        });
                        Daze.popTo(-3);
                    }else{
                        common.setObj("bankChecked",_card);
                        Daze.pushWindow({
                            appId : common.appId,
                            url : 'orderPay.html'
                        });
                    }
                }else{
                    Daze.showMsg(r.msg);
                }
            }
        });
    }
});
