require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'com/common',
    'common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, DZ_COM, common) {

    var domId = 'mainBox',
        $mainBox = $('#mainBox'),
        $keyword = $('#keyword'),
        $resultBox = $('#resultBox'),
        $searchBtn = $('#searchBtn'),
        $tips = $('#tips'),
        _keyword = '',
        pageNum = 1,
        pageSize = 20,
        totalPage = 1,
        _flag = {
            loadData : true,
            loading : true
        };

    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        bindEvents();
        ga_storage._trackPageview('insurancefinal/brand', "汽车服务-橙牛车险管家-选择品牌型号");
    }

    function bindEvents() {
        $(window).on('scroll resize' , function(){//自动加载
            if(_flag.loadData || _flag.loading || totalPage===0 || pageNum >= totalPage){
                return false;
            }
            var scrollTop = $(window).scrollTop(),  
                scrollHeight = $(document).height(), 
                windowHeight = $(window).height(); 
                if($mainBox.find('#resultBox dd').last().offset().top + 150 <= scrollTop+windowHeight){
                    console.log(pageNum , totalPage);
                    ++pageNum;
                    _flag.loadData = true;
                    vehicleModel();
                }
        });
        $keyword.on({
            keydown : function(e){
                var _val = $(this).val();
                var theEvent = e || window.event;    
                var code = theEvent.keyCode || theEvent.which || theEvent.charCode;    
                if (code == 13) {
                    if (_val.replace(/\s/g, '') === '') {
                        Daze.showMsg('请输入车型');
                        return;
                    }
                    if(_val===_keyword){
                        return;
                    }
                    pageNum = 1;
                    _keyword = _val;
                    vehicleModel();
                }  
            }
        });
        $searchBtn.on({
            click: function() {
                var _val = $keyword.val();
                if (_val.replace(/\s/g, '') === '') {
                    Daze.showMsg('请输入车型');
                    return;
                }
                if(_val===_keyword){
                    return;
                }
                _keyword = _val;
                pageNum = 1;
                vehicleModel();
            }
        });
        $mainBox.on({
            click: function() {
                $mainBox.find('.otherPrivce').removeClass('hidden');
            }
        }, '.tips').on({
            click: function() {
                $(this).closest('.otherPrivce').addClass('hidden');
            }
        }, '.closed').on({
            click: function() {
                var _modelName = $(this).closest('.otherPrivce').find('input[name=modelName]'),
                    _modelPrice = $(this).closest('.otherPrivce').find('input[name=modelPrice]'),
                    modelName = _modelName.val(),
                    modelPrice = _modelPrice.val();
                if (modelName === '') {
                    Daze.showMsg('请输入品牌型号');
                    return;
                }if (modelPrice === '') {
                    Daze.showMsg('请输入购车价格');
                    return;
                } else {
                    if (/^\d+(\.\d+)?$/g.test(modelPrice)) {
                        $(this).closest('.otherPrivce').addClass('hidden');
                        setData({
                            vehicleModelCode: ' ',
                            vehicleModelPrice: modelPrice,
                            vehicleModelName: modelName.toUpperCase()+' '+ modelPrice + '万元'
                        });
                    } else {
                        Daze.showMsg('您输入的价格有误');
                    }
                }
            }
        }, '.otherPrivce .btn');

        $resultBox.on({
            click: function() {
                var vehicleModelCode = $(this).attr('data-code'),
                    vehicleModelName = $(this).attr('data-name'),
                    price = $(this).attr('data-price');
                var data = {
                    vehicleModelCode: vehicleModelCode,
                    vehicleModelName: vehicleModelName,
                    vehicleModelPrice: price / 10000
                };
                setData(data);
            }
        }, 'dd');
    }


    /*
    *获取车型列表
     */
    function vehicleModel() {
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        _flag.loading = true;
        DZ_COM.checkNetwork(domId, function() {
            $.ajax({
                url: host.HOST_URL + "/appclient/common/vehicleModel.htm",
                data: DZ_COM.convertParams({
                    keyword: _keyword,
                    pageNum: pageNum,
                    pageSize: pageSize
                }),
                success: function(r) {
                    _flag.loading = false;
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if (r.code == '0') {
                        if (r.data && r.data.total) {
                            if (pageNum == 1) {
                                totalPage = Math.ceil(r.data.total / pageSize);
                                renderList(r.data.list);
                            } else {
                                renderMore(r.data.list);
                            }
                            if(pageNum >= totalPage){
                                _flag.loadData = true;
                            }else{
                                _flag.loadData = false;
                            }
                        }else{
                            totalPage = 0;
                            renderList([]);
                            $tips.addClass('hidden');
                            $mainBox.find('.tips').addClass('hidden').click();
                        }
                    } else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-查询车型', 'appclient/common/vehicleModel.htm', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-查询车型', 'appclient/common/vehicleModel.htm', '失败');
                }
            });
        });
    }

    function setData(obj) {
        var data = {
            vehicleModelCode: obj.vehicleModelCode,
            vehicleModelName: obj.vehicleModelName,
            vehicleModelPrice: obj.vehicleModelPrice
        };

        Daze.system.postObserver({
            name: 'daze_selectBrandEvent',
            eventData: data
        });

        // 兼容android
        common.setObj('vehicleModelCode', obj.vehicleModelCode);
        common.setObj('vehicleModelName', obj.vehicleModelName);
        common.setObj('vehicleModelPrice', obj.vehicleModelPrice);
        Daze.popTo(-1);
    }

    function renderHeader() {
        Daze.setTitle('选择车型');
    }

    /*
    *车型列表-查看更多
     */
    function renderMore(list) {
        //console.log(list);
        $resultBox.find('dl').append(template('moreList', {
            list: list
        }));
    }

    /*
    *渲染页面-车型列表
     */

    function renderList(list) {
        var data = {
            list: list
        };
        $tips.addClass('hidden');
        $mainBox.find('.tips').removeClass('hidden');
        $resultBox.html(template('brandListTmpl', data));
    }
});
