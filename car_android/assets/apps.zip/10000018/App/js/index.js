/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM) {
    var domId = 'mainBox',
        orderlists = [],
        _req = tool.getQueryString(),
        _reqs = common.getObj('bjing'),
        totalPage = 0,
        pageNum = 1,
        pageSize = 20,
        userInfo = {},
        _flag = {
            loadData : true,
            nothing : true,
            loading : true
        }
        $mainBox = $('#mainBox');

    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        DZ_COM.login(function () {
            init();
        });
    }, false);

    function init() {
        renderHeader();
        if(!tool.isEmpty(_req)&&_req.type=='1'){
            document.addEventListener('daze_reRepotEvent', function(e) {
                var data = e.eventData;
                if(DZ_COM.getSystem() == 'ios'){
                    location.reload();
                }
            });
            renderNewOrder();
            if(typeof _reqs != 'undefined' && _reqs == 'ed' ){
                $mainBox.find('#goToInsure').attr("disabled","disabled").addClass('disabled').val('您有保单在核保中...');
            }else{
                bindEvents();
            }
        }else{
            renderCache();
            bindEvents();
            document.addEventListener('daze_orderAdd', function(e) {
                var data = e.eventData;
                setOrderAdd(data);
            });

            Daze.system.addObserver({
                name: 'daze_orderAdd'
            });
        }

        document.addEventListener('daze_selectCityEvent', function(e) {
            var data = e.eventData;
            if (!data) {
                data = {
                    cityCode: common.getObj('cityCode'),
                    cityName: common.getObj('cityName')
                };
            }
            setCity(data);
        });

        document.addEventListener('daze_selectBrandEvent', function(e) {
            var data = e.eventData;
            if (!data) {
                data = {
                    vehicleModelCode: common.getObj('vehicleModelCode'),
                    vehicleModelName:common.getObj('vehicleModelName'),
                    vehicleModelPrice: common.getObj('vehicleModelPrice')
                };
            }
            setBrand(data);
        });

        ga_storage._trackPageview('insurancefinal/index', "汽车服务-橙牛车险管家-在线车险");
    }

    function renderNewOrder(){
        common.setUid();
        getCarList(function(){
            var carList = common.getObj('carList'),
                vehicleNum = common.getObj('vehicleNum'),
                vehicleHas = common.getObj('vehicleHas'),
                _city = null,
                _re = common.getObj();
            if(carList.length && !vehicleHas){
                renderTempl({
                    data : common.getObj(),
                    type : 'newOrder_vehicle'
                });
            }else{
                renderTempl({
                    data : common.getObj(),
                    type : 'newOrder'
                });
            }
            DZ_COM.getCurCity(function(){
                _city = storage.getCurCity();
                //alert(_re.cityName+',,,,'+_city.province+',,,'+_city.name+',,,,'+location.search);
                if(!_re.cityName && _city && _city.province && _city.name){
                    getCityList({level : 0},function(data){
                        var len = data.length , s = 0 , provinceId = 0;
                        if(len=== 0){return;}
                        for(; s < len ; s++){
                            if(data[s].cityName == _city.province){
                                provinceId = data[s].cityCode;
                            }
                        }
                        if(provinceId !== 0){
                            getCityList({
                                level : 1,
                                cityCode : provinceId
                            },function(_data){
                                var lens = _data.length,
                                    t = 0,
                                    _res = {};
                                if(lens=== 0){return;}
                                for(; t < lens ; t++){
                                    if(_data[t].cityName.indexOf(_city.name) > -1){
                                        _res = _data[t];
                                    }
                                }
                                if(_res.cityCode && _res.cityName){
                                    if(typeof common.getObj('cityName') != 'undefined'){return;}
                                    common.setObj('cityCode',_res.cityCode);
                                    common.setObj('cityName',_res.cityName);
                                    $('#city').val(_res.cityName).attr('data-code',_res.cityCode);
                                }
                            });
                        }
                    });
                }
            });
        });
    }

    function setOrderAdd(data){
        document.removeEventListener('daze_orderAdd', function(e) {
            setOrderAdd(e.data);
        });
        if(DZ_COM.getSystem() == 'ios'){
            if(data.result == "addOk"){
                common.setObj('reload','true');
                location.reload();
            }
        }
    }

    function getCityList(obj,callback) {
        obj = obj || {};
        DZ_COM.checkNetwork(null, function() {
            var data = {
                level: obj.level
            };
            if (obj.cityCode) {
                data.cityCode = obj.cityCode;
            }
            $.ajax({
                url: host.HOST_URL + "/appclient/common/queryCity.htm",
                data: DZ_COM.convertParams(data),
                success: function(r) {
                    if (r.code == 0) {
                        typeof callback != 'undefined' && callback.constructor == Function && callback(r.data);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-选择城市', '/appclient/common/queryCity.htm', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-选择城市', '/appclient/common/queryCity.htm', '失败');
                }
            });
        });
    }

    function getCarList(callback){
        if(!common.getObj('carList')){
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            DZ_COM.checkNetwork(domId, function() {
                $.ajax({
                    url: host.HOST_URL + "/vehicle/getList.htm",
                    //url: "http://192.168.10.3:9880/vehicle/getList.htm",
                    data: DZ_COM.convertParams({
                        userId: storage.getUserId(),
                        uid : storage.getUid()
                    }),
                    success: function(r) {
                        var _arr = [];
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        console.log(r);
                        if(r.data && r.data.list && r.data.list.length){
                            for(var i = 0 ,len = r.data.list.length ; i < len ; i++){
                                if(r.data.list[i].vehicleAuth && r.data.list[i].vehicleAuth.belong===true){
                                    _arr.push(r.data.list[i]);
                                }
                            }
                        }
                        common.setObj('carList',_arr);
                        typeof callback !== 'undefined' && callback.constructor === Function && callback();
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-获取认证车辆', '/vehicle/getList.htm', '成功');
                    },
                    error: function(r) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        common.setObj('carList',[]);
                        typeof callback !== 'undefined' && callback.constructor === Function && callback();
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-获取认证车辆', '/vehicle/getList.htm', '失败');
                    }
                });
            });
        }else{
            typeof callback !== 'undefined' && callback.constructor === Function && callback();
        }        
    }

    function renderCache(){
        var _list = storage.getItem('bxlistRepot'),
            bxlsit = storage.getItem('bxlsit');
        if(tool.isEmpty(bxlsit)){
            if(!tool.isEmpty(_list)){
                orderlists = _list;
                renderTempl({
                    data : orderlists,
                    type : 'list',
                    pageNum : 0
                });
                $(window).on('scroll resize' , function(){//自动加载
                    if(_flag.loadData){
                        return false;
                    }
                    var scrollTop = $(window).scrollTop(),  
                        scrollHeight = $(document).height(), 
                        windowHeight = $(window).height(); 
                        if($mainBox.find('.myList .items').last().offset().top - 150 <= scrollTop+windowHeight){
                            if(_flag.nothing || _flag.loading || totalPage===0 || pageNum >= totalPage){return false;}
                            Daze.showMsg({
                                type: 'loading',
                                visible: true,
                                text : '加载中...'
                            });
                            common.setUid();
                            pageNum++;
                            _flag.loading = true;
                            $.ajax({
                                url: host.HOST_URL + "/appclient/baoxian/listReport.htm",
                                data: DZ_COM.convertParams({
                                    userId: common.getObj('uid'),
                                    pageNum: pageNum,
                                    pageSize: pageSize
                                }),
                                success: function(r) {
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: false
                                    });
                                    if (r.code == '0' && r.data && r.data.list && r.data.list.length) {
                                        if(pageNum >= totalPage){
                                            _flag.loadData = true;
                                        }
                                        if(pageNum > totalPage){
                                            _flag.nothing = true;
                                            _flag.loading = true;
                                        }else{
                                            //console.log(orderlists);
                                            for(var m = 0 ; m < r.data.list.length ; m++){
                                                orderlists.push(r.data.list[m]);
                                            }
                                            //console.log(orderlists);
                                            $mainBox.find('.myList').append(template('moreList',{
                                                data : r.data.list,
                                                pageNum : pageNum-1 
                                            }));
                                            //moreList
                                            _flag.loading = false;
                                        }
                                    }
                                    ga_storage._trackEvent('汽车服务-橙牛车险管家-核保列表', '/appclient/baoxian/listReport.htm', '成功');
                                },
                                error: function(r) {
                                    Daze.showMsg({
                                        type: 'loading',
                                        visible: false
                                    });
                                    DZ_COM.renderNetworkTip(domId, 1);
                                    ga_storage._trackEvent('汽车服务-橙牛车险管家-核保列表', '/appclient/baoxian/listReport.htm', '失败');
                                }
                            });
                        }
                });
            }
        }else{
            renderNewOrder();
        }
        listReport();
    }

    function listReport(){
        common.setUid();
        if(tool.isEmpty(storage.getItem('bxlsit')) && tool.isEmpty(storage.getItem('bxlistRepot'))){
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
        }
        DZ_COM.checkNetwork(domId, function() {
            $.ajax({
                url: host.HOST_URL + "/appclient/baoxian/listReport.htm",
                data: DZ_COM.convertParams({
                    userId: common.getObj('uid'),
                    pageNum: pageNum,
                    pageSize: pageSize
                }),
                success: function(r) {
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    if (r.code == '0' && r.data && r.data.list) {
                        if(r.data.list.length){
                            totalPage = Math.ceil(r.data.total/pageSize);
                            if(totalPage > 0){
                                _flag.loadData = false;
                                _flag.nothing = false;
                                _flag.loading = false;
                            }
                            if(typeof common.getObj('reload') == 'undefined'){
                                common.setObj();
                            }
                            orderlists = r.data.list;
                            storage.setItem('bxlistRepot',r.data.list);
                            storage.clearItem('bxlsit');
                            renderTempl({
                                data : r.data.list,
                                type : 'list',
                                pageNum : 0
                            });
                        }else{
                            storage.clearItem('bxlistRepot');
                            if(tool.isEmpty(storage.getItem('bxlsit'))){
                                storage.setItem('bxlsit',{
                                    'has' : 'true'
                                });
                                common.setObj();
                                renderNewOrder();
                            }
                        }
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-核保列表', '/appclient/baoxian/listReport.htm', '成功');
                },
                error: function(r) {
                    Daze.showMsg({
                        type: 'loading',
                        visible: false
                    });
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-核保列表', '/appclient/baoxian/listReport.htm', '失败');
                }
            });
        });
    }

    function queryReport(){
        common.setObj();
        if(tool.isEmpty(storage.getItem('bxlsit'))){
            common.setUid();
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            DZ_COM.checkNetwork(domId, function() {
                $.ajax({
                    url: host.HOST_URL + "/appclient/baoxian/listReport.htm",
                    data: DZ_COM.convertParams({
                        userId: common.getObj('uid'),
                        pageNum: pageNum,
                        pageSize: pageSize
                    }),
                    success: function(r) {
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        if (r.code == '0' && r.data && r.data.list && r.data.list.length) {
                            renderTempl({
                                data : r.data.list,
                                type : 'list'
                            });
                            orderlists = r.data.list;
                            storage.setItem('bxlistRepot',r.data.list);
                            console.log(orderlists);
                        } else {
                            storage.setItem('bxlsit',{
                                'has' : 'true'
                            });
                            renderNewOrder();
                        }
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-核保列表', '/appclient/baoxian/listReport.htm', '成功');
                    },
                    error: function(r) {
                        DZ_COM.renderNetworkTip(domId, 1);
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-核保列表', '/appclient/baoxian/listReport.htm', '失败');
                    }
                });
            });
        }else{
            renderNewOrder();
        }
    }

    function bindEvents() {
        $mainBox.on('click', '.view-tpl p', function() {
            $(this).parent().find('.tpl').removeClass('hidden');
        }).on({
            click: function() {
                $(this).addClass('hidden');
                return false;
            }
        }, '.tpl').on({
            click: function() {
                Daze.system.addObserver({
                    name: 'daze_selectCityEvent'
                });
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'city.html'
                });
            }
        }, '.cityItem').on({
            click: function() {
                Daze.system.addObserver({
                    name: 'daze_selectBrandEvent'
                });
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'brand.html'
                });
            }
        }, '.brandItem').on({
            click: function() {
                var _click = $(this).data('click');
                if (_click) {
                    $mainBox.find('.reUpload').removeClass('hidden');
                } else {
                    uploadFile.call(this);
                }
            }
        }, '.itemxsz').on({
            click: function() {
                $(this).closest('.reUpload').addClass('hidden');
            }
        }, '.reUpload .closed').on({
            click: function() {
                $(this).closest('.reUpload').addClass('hidden');
                uploadFile.call($mainBox.find('.itemxsz'));
            }
        }, '.reUpload .btn').on({
            click: function() {
                fastReport();
            }
        }, '#goToInsure').on({
            click : function(){
                var _url = '',__url = '',__arr = [];
                if(typeof _req.cityId != 'undefined'){
                    for(var s in _req){
                        __arr.push(s+'='+_req[s]);
                    }
                }
                if(__arr.length > 0){
                    __url = '?'+__arr.join('&');
                }
                _url = __url!='' ? __url+'&type=1' : '?type=1';
                console.log(_url);
                common.setObj();
                Daze.pushWindow({
                    appId : common.appId,
                    url : "index.html"+_url
                });
            }
        },'#sendOrder').on({
            click : function(){
                    common.setObj();
                    common.setUid();
                var data = common.getObj(),
                    index = $(this).data('index'),
                    uid = data.uid,
                    baoxianBaseInfoId = $(this).data('baseinfoid');
                    getUserBaseInfo(uid,baoxianBaseInfoId,function(){
                        var _data = $.extend(data,userInfo,orderlists[index]);
                        common.setObj(_data);
                        common.setObj('baoxianBaseInfoId',baoxianBaseInfoId);
                        common.setObj('userInfo',userInfo);
                        Daze.pushWindow({
                            appId : common.appId,
                            url : 'underWriting.html'
                        });
                    });
            }
        },'div[data-btn=orderlist]').on({
            click : function(){
                var index = $(this).attr('data-index');
                if(typeof index === 'string' && index >= 0){
                    setVehicle(index);
                }else{
                    setVehicle();
                }
            }
        },'#chooseVehicle dd').on({
            click : function(){
                common.removeItem('vehicleHas');
                $('#chooseVehicle').removeClass('hidden');
                $('#newOrder').addClass('hidden');
            }
        },'.vehicleNumItem,form .otheritem').on({
            click : function(){
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'detailed.html'
                });
            }
        },'#detailed p');
    }

    function setVehicle(index){
        var _mydata = common.getObj('carList');
        if(typeof index != 'undefined'){
            $('.view-tpl,.itemxsz').addClass('hidden');
            $('.vehicleNumItem').removeClass('hidden');
            $('input[name=drivingUrl]').attr('data-require','false').val(_mydata[index]['vehicleAuth']['drivingLicenceUrl']);;
            $('input[name=vehicleNum]').val(_mydata[index]['vehicleNum']);
            /*$('input[name=vehicleModelCode]').val(_mydata[index].vehicleAuth.brandModel).attr({
                'data-price' : 20,
                'data-code' : _mydata[index].vehicleAuth.frameNum
            });*/
            common.setObj('drivingUrl',_mydata[index]['vehicleAuth']['drivingLicenceUrl']);
            common.setObj('vehicleNum', _mydata[index]['vehicleNum']);
           /* common.setObj('vehicleModelName', _mydata[index].vehicleAuth.brandModel);
            common.setObj('vehicleModelCode', _mydata[index].vehicleAuth.frameNum);
            common.setObj('vehicleModelPrice', 20);*/
        }else{
            $('.view-tpl,.brandItem,.itemxsz').removeClass('hidden');
            $('.vehicleNumItem').addClass('hidden');
            $('input[name=drivingUrl]').attr('data-require','true');
            $('input[name=vehicleNum],input[name=drivingUrl],input[name=vehicleModelCode]').val('');
            $('input[name=vehicleModelCode]').attr({
                'data-price' : '',
                'data-code' : ''
            });
            $('.itemxsz').attr('data-click','false').find('img').attr('src','images/takephoto.png')
            $('.itemxsz').find('input').val('');
            common.removeItem('drivingUrl');
            common.removeItem('vehicleModelName');
            common.removeItem('vehicleNum');
            common.removeItem('vehicleModelCode');
            common.removeItem('vehicleModelPrice');
        }
        $('#chooseVehicle').addClass('hidden');
        $('#newOrder').removeClass('hidden');
        common.setObj('vehicleHas',true);
    }

    function getUserBaseInfo(uid,baoxianBaseInfoId,callback){
        if(tool.isEmpty(userInfo)){
            Daze.showMsg({
                type: 'loading',
                visible: true
            });
            DZ_COM.checkNetwork(domId, function() {
                $.ajax({
                    url: host.HOST_URL + "/appclient/baoxian/userBaseInfo.htm",
                    data: DZ_COM.convertParams({
                        userId : uid,
                        id : baoxianBaseInfoId
                    }),
                    success: function(r) {
                        if (r.code == '0' && r.data) {
                            Daze.showMsg({
                                type: 'loading',
                                visible: false
                            });
                            userInfo = r.data;
                            callback&&callback();
                        } else {
                            //Daze.showMsg(r.msg);
                        }
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-基本信息', 'appclient/baoxian/userBaseInfo.htm', '成功');
                    },
                    error: function(r) {
                        DZ_COM.renderNetworkTip(domId, 1);
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-基本信息', 'appclient/baoxian/userBaseInfo.htm', '失败');
                    }
                });
            });
        }else{
            callback&&callback();
        }
    }

    function uploadFile() {
        var me = $(this);
        Daze.photo({
            type: 6
        }, function(o) {
            if (!o.url) {
                return false;
            }
            var $img = me.find('img');
            $img.attr('src', o.url);
            me.attr('data-click', 'true').find('input').val('已上传');
            $('input[name="drivingUrl"]').val(o.url);
            $mainBox.find('.reUpload').find('img').attr('src', o.url);
            common.setObj('drivingUrl', o.url);
        });
    }


    function renderHeader() {
        Daze.setTitle('在线车险');
    }

    function fastReport() {
        var data = validate();
        if (!data) {
            return false;
        }
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        data.vehicleModelCode = $('#brand').attr('data-code');
        data.vehicleModelName = $('#brand').val();
        data.userId = common.getObj('uid');
        data.id = common.getObj('baoxianBaseInfoId') || '';
        data.vehicleNum = common.getObj('vehicleNum') || ''
        DZ_COM.checkNetwork(domId, function() {
            $.ajax({
                url: host.HOST_URL + "/appclient/baoxian/fastReport.htm",
                data: DZ_COM.convertParams(data),
                success: function(r) {
                    if(r.code == '0' && r.data.id){
                        common.setObj('baoxianBaseInfoId', r.data.id);
                        DZ_COM.checkNetwork(domId, function() {
                            $.ajax({
                                url: host.HOST_URL + "/appclient/baoxian/company.htm",
                                data: DZ_COM.convertParams({
                                    cityCode : data.cityCode
                                }),
                                success: function(r) {
                                    if (r.code == '0' && r.data && r.data.list && r.data.list.length) {
                                        Daze.showMsg({
                                            type: 'loading',
                                            visible: false
                                        });
                                        common.setObj('companyInfo',r.data.list);
                                        common.companyList();
                                        Daze.system.addObserver({
                                            name: 'daze_reRepotEvent'
                                        });
                                        Daze.pushWindow({
                                            appId : common.appId,
                                            url : 'cardInfo.html'
                                        });
                                    } else {
                                       Daze.showMsg("暂无可承保公司");
                                    }
                                    ga_storage._trackEvent('汽车服务-橙牛车险管家-保险公司信息', 'appclient/baoxian/company.htm', '成功');
                                },
                                error: function(r) {
                                    DZ_COM.renderNetworkTip(domId, 1);
                                    ga_storage._trackEvent('汽车服务-橙牛车险管家-保险公司信息', 'appclient/baoxian/company.htm', '失败');
                                }
                            });
                        });
                    }else{
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-闪电报价', 'appclient/baoxian/fastReport.htm', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-闪电报价', 'appclient/baoxian/fastReport.htm', '失败');
                }
            });
        });
    }

    function getData() {
        var formData = tool.getFormDataAsObj($('form'));
        formData.cityCode = $('#city').attr('data-code');
        formData.price = $('#brand').attr('data-price');
        return formData;
    }

    function validate() {
        var data = getData(),
            valid = true;
        for (var i in data) {
            var value = data[i],
                $item = $('[name=' + i + ']'),
                require = $item.data('require'),
                nullMsg = $item.data('null'),
                errorMsg = $item.data('error'),
                ruleName = $item.data('rule') || '';

            if (require) {
                if (!value) {
                    valid = false;
                    console.log(nullMsg);
                    Daze.showMsg(nullMsg);
                    break;
                } else if (ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            } else {
                if (value && ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            }
        }
        return valid ? data : false;
    }

    function renderTempl(data) {
        $mainBox.html(template('indexTemplate',data));
    }

    function setCity(data) {
        document.removeEventListener('daze_selectCityEvent', function(e) {
            setCity(e.data);
        });
        $('#city').val(data.cityName).attr('data-code', data.cityCode);
    }

    function setBrand(data) {
        document.removeEventListener('daze_selectBrandEvent', function(e) {
            setBrand(e.data);
        });
        $('input[name=vehicleModelCode]').val(data.vehicleModelName).attr({
            'data-price' : data.vehicleModelPrice,
            'data-code' : data.vehicleModelCode
        });
    }

});
