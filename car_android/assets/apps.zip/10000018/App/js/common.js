/**
 * author:wj77998
 */
define([
    'com/storage',
    'com/tools'
], function (storage, tool) {
    'use strict';
    var obj = 'insurancefinal',
        _ord = "insureOrderList",
        config = {
        mode: 0, //模式：0 测试 /1 预发 /2 生产
        hostUrls: [
            "http://192.168.10.3:39080",
            "http://121.40.72.129:8080",
            "http://121.41.118.32"
        ]
    };
    return {
        HOST_URL: config.hostUrls[config.mode],
        appId : '10000018',
        addOrder : function(id,time){
            var ord = storage.getItem(_ord) || [];
            if(ord.length == 0){
                ord.push({
                    id : id,
                    time : time
                });
                storage.setItem(_ord,ord);
            }else{
                var _r = this.indexOrder(id);
                if(typeof _r != 'number' || _r == -1){
                    ord.push({
                        id : id,
                        time : time
                    });
                    storage.setItem(_ord,ord);
                }
            }
        },
        checkOrder : function(id,callback){
            var ord = storage.getItem(_ord) || [],
                time = '',
                 _r = this.indexOrder(id);
            if(typeof _r == 'number' && _r >= 0){
                time = ord[_r].time;
                typeof callback != 'undefined' && callback.constructor == Function && callback(id,time,_r);
            }

        },
        delOrder : function(id){
            var r = this.indexOrder(id),
                ord = storage.getItem(_ord) || [];
            if(typeof r == 'number' && r >= 0){
                ord.splice(r,1);
                storage.setItem(_ord,ord);
            }
        },
        indexOrder : function(id){
            var ord = storage.getItem(_ord) || [],
                _arr = [];
            if(ord.length == 0 ){
                return false;
            }
            for(var t = 0 ; t < ord.length;t++){
                _arr.push(ord[t].id);
            }
            return _arr.indexOf(id);
        },
        removeItem: function(item) {
            var _re = this.getObj();
            if (item in _re) {
                delete _re[item];
                   this.setObj(_re);
            }
        },
        getObj: function(item) {
            var _re = storage.getGlobalData()[obj] || {};
            if (item) {
                if (typeof _re[item] != 'undefined') {
                    return _re[item];
                } else {
                    return undefined;
                }
            } else {
                return _re;
            }
        },
        setObj: function(a, b) {
            var _re = this.getObj();
            if (!a) {
                storage.removeInfo(obj);
            } else {
                if (typeof a == 'object') {
                    storage.storeInfo(obj, a);
                } else {
                    _re[a] = b;
                    storage.storeInfo(obj, _re);
                }
            }
        },
        setUid : function(){
            this.setObj('uid',storage.getUid());
        },
        listFn : function(data){
            var _re = {
                basic : [],
                mass : [],
                luxury : []
            };
            for(var i = 0 ; i < data.length ; i++){
                if(data[i].type == '0'){
                    _re.basic.push(data[i]);
                }else if(data[i].type == '1'){
                    _re.mass.push(data[i]);
                }else if(data[i].type == '2'){
                    _re.luxury.push(data[i]);
                }
            }
            return [_re.basic,_re.mass,_re.luxury];
        },
        companyList : function(){
            var obj = this.getObj('companyInfo'),
                re = ['太平洋车险','人保车险','阳光车险','天平车险','华安车险','永诚车险'],
                _arr = [];
            for(var s = 0 ; s < re.length; s++){
                for(var i = 0 ; i < obj.length ; i++){
                    if(obj[i].name == re[s]){
                        _arr.push(obj[i]);
                        obj.splice(i,1);
                    }
                }
            }
            for(var t = 0 ; t < obj.length ; t++){
                if(obj[t].name != '太平车险'){
                    _arr.push(obj[t]);
                }
            }
            if(_arr.length > 0){
                this.setObj("companyInfo",_arr);
            }
        }
    };
});
