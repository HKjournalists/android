/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM) {
    var domId = 'mainBox',
        _re = common.getObj(),
        $mainBox = $('#mainBox');
        document.addEventListener("DazeJSObjReady", function() {
            console.log("DazeJSObjReady");
            init();
        }, false);

    function init() {
        /*_re.idCardUrl = 'http://img.junrongtang.com/car_service_fine/1508041751560.jpg';
        _re.guohu = true;
        _re.guohuDate = '2015-10-16';
        common.setObj(_re);*/
        console.log(_re); 
        renderTempl();
        if(typeof common.getObj('bjing') != 'undefined' && common.getObj('bjing') == 'ed' ){
            $mainBox.find('#goToInsure').attr("disabled","disabled").addClass('disabled').val('您有保单在核保中...');
        }else{
            bindEvents();
        }
        //checkIdCard();
        renderHeader(); 

        if(tool.isEmpty(common.getObj('mobile'))){
            DZ_COM.checkNetwork(domId, function() {
                $.ajax({
                    url: host.HOST_URL + "/user/getUserInfo.htm",
                    data: DZ_COM.convertParams({
                        uid: _re.uid
                    }),
                    success: function(r) {
                        if (r.code == '0') {
                            cash = r.data.userInfo.accounts[0].userName;
                            common.setObj('mobile', cash);
                            $mainBox.find('input[name=mobile]').val(cash);
                        } else {
                            Daze.showMsg(r.msg);
                        }
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-基本信息', '/user/getUserInfo.htm', '成功');
                    },
                    error: function(r) {
                        DZ_COM.renderNetworkTip(null, 1);
                        ga_storage._trackEvent('汽车服务-橙牛车险管家-基本信息', '/user/getUserInfo.htm', '失败');
                    }
                });
            });
        }

        document.addEventListener('daze_insureBrandEvent', function(e) {
            var data = e.eventData;
            if (!data) {
                data = {
                    baoxianCompanyCode : common.getObj('baoxianCompanyCode'),
                    baoxianCompanyName : common.getObj('baoxianCompanyName'),
                    baoxianCompanyPic : common.getObj('baoxianCompanyPic'),
                    baoxianCompanyRemark : common.getObj('baoxianCompanyRemark')
                };
            }
            setInsureBrand(data);
        });

        document.addEventListener('daze_reRepotEvent', function(e) {
            var data = e.eventData;
            if(DZ_COM.getSystem() == 'ios'){
                location.reload();
            }
        });

        ga_storage._trackPageview('insurancefinal/cardInfo', "汽车服务-橙牛车险管家-在线车险");
    }

    function bindEvents() {
        $mainBox.on('click', '.view-tpl p', function() {
            $(this).parent().find('.tpl').removeClass('hidden');
        }).on({
            click: function() {
                $(this).addClass('hidden');
                return false;
            }
        }, '.tpl').on({
            click: function() {
                var _click = $(this).data('click');
                if (_click) {
                    $mainBox.find('.reUpload').removeClass('hidden');
                } else {
                    uploadFile.call(this);
                }
            }
        }, '.itemsfz').on({
            click: function() {
                $(this).closest('.reUpload').addClass('hidden');
            }
        }, '.reUpload .closed').on({
            click: function() {
                $(this).closest('.reUpload').addClass('hidden');
                uploadFile.call($mainBox.find('.itemsfz'));
            }
        }, '.reUpload .btn').on({
            click : function(){
                var _lg = $(this).hasClass('active');
                $(this).toggleClass('active').find('input[type=hidden]').val(!_lg ? 1 : '');
            }
        },'.itembx').on({
            click : function(){
                var $this = $(this),$_for = $('#'+$(this).attr('data-for')),_has = $this.hasClass('active');
                $this.toggleClass('active').closest('.itemInput').find('input').val($this.hasClass('active') ? $this.attr("data-true") : $this.attr("data-false"));
                $_for.toggleClass('hidden',_has).find('input').attr('data-require',!_has);
            }
        },'.itemInput .ghzt').on({
            click: function() {
                goToInsure();
            }
        }, '#goToInsure').on({
            click : function(){
                if($(this).attr('data-click') == 'false'){return;}
                Daze.system.addObserver({
                    name: 'daze_insureBrandEvent'
                });
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'insureBrand.html'
                });
            }
        },'#changeBrand').on({
            blur : function(){
                this.value = this.value.replace(/\s/g, '');
            }
        },'input[name=idCardName],input[name=idCardNum]');
        /*.on({
            click : function(){
                var index = $(this).index();
                $('.itemsfz,.cardInfotips').toggleClass('hidden',Boolean(index));
                $('.itemrenderId').toggleClass('hidden',!Boolean(index));
                $('input[name="idCardUrl"]').attr('data-require',!Boolean(index));
                $('input[name=idCardName],input[name=idCardNum]').attr('data-require',Boolean(index));
                $(this).addClass('active').siblings('span').removeClass('active');
            }
        },'#itemPhoto span')*/
    }


    /*
    *判断身份证图片或者身份证信息是否存在  
    */    
    function checkIdCard(){
        var $_btn = $('#itemPhoto span');
        if($('input[name="idCardName"]').val() != "" && $('input[name="idCardNum"]').val() != ""){
            $_btn.eq(1).trigger('click');
        }else{
            $_btn.eq(0).trigger('click');
        }   
    }

    /*
    *上传身份证
    */
    function uploadFile() {
        var me = $(this);
        Daze.photo({
            type: 6
        }, function(o) {
            if (!o.url) {
                return false;
            }
            var $img = me.find('img');
            $img.attr('src', o.url);
            me.attr('data-click', 'true').find('.cardPhoto').text('已上传').removeClass('caption');
            $('input[name="idCardUrl"]').val(o.url);
            $mainBox.find('.reUpload').find('img').attr('src', o.url);
            common.setObj('idCardUrl', o.url);
        });
    }

    /*
    *选择保险公司回调
    */
    function setInsureBrand(data) {
        document.removeEventListener('daze_insureBrandEvent', function(e) {
            setInsureBrand(e.data);
        });
        console.log(data);
        var $el = $mainBox.find('#changeBrand');
        if(!_re.baoxianCompanyName){
            $el.find('.pics').removeClass('hidden');
            $el.find('.infos').removeClass('hidden');
            $el.find('.nochoose').addClass('hidden');
        }
        $el.find('img').attr('src',data.baoxianCompanyPic);
        $el.find('.infos .body1').html(data.baoxianCompanyName);
        $el.find('.infos .caption').html(data.baoxianCompanyRemark);
        DZ_COM.confirm({
            title : "是否续保",
            content : "是否和您上一年的保险公司相同",
            'yesBtn' : '是',
            'noBtn' : '否',
            yesFn : function(){
                $('input[name=xubao]').val('true').parent().next().find('.ghzt').addClass('active');
            },
            noFn : function(){
                $('input[name=xubao]').val('false').parent().next().find('.ghzt').removeClass('active');
            }
        });
    }

    function renderHeader() {
        Daze.setTitle('在线车险');
    }

    function goToInsure(){
        var data = validate(),
            _data = common.getObj();
        if (!data) {
            return false;
        }
        Daze.showMsg({
            type: 'loading',
            visible: true
        });
        _data = $.extend(_data,data);
        common.setObj(_data);
        data.id = _data.baoxianBaseInfoId;
        data.userId = _data.uid;
        delete data.isone;
        DZ_COM.checkNetwork(domId, function() {
            $.ajax({
                url: host.HOST_URL + "/appclient/baoxian/fixUserInfo.htm",
                data: DZ_COM.convertParams(data),
                success: function(r) {
                    if (r.code == '0' && r.data.result) {
                        Daze.system.addObserver({
                            name: 'daze_reRepotEvent'
                        });
                        Daze.system.addObserver({
                            name: 'daze_insureBrandEvent'
                        });
                        Daze.showMsg({
                            type: 'loading',
                            visible: false
                        });
                        Daze.pushWindow({
                            appId : common.appId,
                            url : 'insure.html'
                        });
                    } else {
                        Daze.showMsg(r.msg);
                    }
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-补齐基本信息', '/appclient/baoxian/fixUserInfo', '成功');
                },
                error: function(r) {
                    DZ_COM.renderNetworkTip(domId, 1);
                    ga_storage._trackEvent('汽车服务-橙牛车险管家-补齐基本信息', '/appclient/baoxian/fixUserInfo', '失败');
                }
            });
        });
    }

    function getData() {
        var formData = tool.getFormDataAsObj($('form'));
        return formData;
    }

    function validate() {
        var data = getData(),
            phoneReg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/,
            idCardNameReg = /^[\u2E80-\u9FFF]+$/,
            idCardReg = /(^\d{15}$)|(^\d{17}([0-9]|X|x)$)/,
            valid = true;
        if(!common.getObj('baoxianCompanyName')){
            Daze.showMsg('请选择保险公司');
            return;
        }
        /*if($('#itemPhoto span.active').index() === 0){
            data.idCardNum = '';
            data.idCardName = '';
        }*/
        for (var i in data) {
            var value = data[i],
                $item = $('[name=' + i + ']'),
                require = $item.data('require'),
                nullMsg = $item.data('null'),
                errorMsg = $item.data('error'),
                ruleName = $item.data('rule') || '',
                rule = eval(ruleName);

            if (require) {
                if (!value) {
                    valid = false;
                    console.log(nullMsg);
                    Daze.showMsg(nullMsg);
                    break;
                } else if (ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            } else {
                if (value && ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            }
        }
        return valid ? data : false;
    }

    function renderTempl() {
        //初始化写入
        var data = common.getObj();
        $mainBox.html(template('cardInfoTmpl', {
            data: data
        }));
    }
});
