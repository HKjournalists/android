/**
 * author:wj77998
 */
require([
    'lib/zepto.min',
    'lib/tpl.min',
    'com/host',
    'com/tools',
    'com/storage',
    'common',
    'com/common',
    'com/GALocalStorage'
], function (a, b, host, tool, storage, common, DZ_COM) {
    var domId = 'mainBox',
        _re = common.getObj(),
        _req = common.getObj('bjing'),
        _reportData = null,
        $mainBox = $('#mainBox');
    document.addEventListener("DazeJSObjReady", function() {
        console.log("DazeJSObjReady");
        init();
    }, false);

    function init() {
        renderHeader();
        renderTempl();
        if(typeof _req != 'undefined' && _req == 'ed' ){
            $mainBox.find('#goToInsure').attr("disabled","disabled").addClass('disabled').val('您有保单在核保中...');
        }else{
            bindEvents();
        }

        document.addEventListener('daze_insureBrandEvent', function(e) {
            var data = e.eventData;
            if (!data) {
                data = {
                    baoxianCompanyCode : common.getObj('baoxianCompanyCode'),
                    baoxianCompanyName : common.getObj('baoxianCompanyName'),
                    baoxianCompanyPic : common.getObj('baoxianCompanyPic'),
                    baoxianCompanyRemark : common.getObj('baoxianCompanyRemark')
                };
            }
            setinsureBrand(data);
        });

        document.addEventListener('daze_reRepotEvent', function(e) {
            var data = e.eventData;
            if (!data) {
                data = common.getObj('_reRepotEvent');
            }
            if(data && typeof data.result !='undefined' && data.result=='reportOk'){
                common.removeItem('_reRepotEvent');
                if(DZ_COM.getSystem() == 'ios'){
                    location.reload();
                }
            }
        });

        ga_storage._trackPageview('insurancefinal/insure', "汽车服务-橙牛车险管家-在线车险");
    }

    function bindEvents() {
        $mainBox.on({
            click : function(){
                var $_this = $(this),
                    _click = $(this).data('click'),
                    $span = $(this).children('span'),
                    $input = $(this).children('input'),
                    arr = [$_this.data('false'),$_this.data('true')];
                    if(!_click){
                        return;
                    }
                $span.toggleClass('active');
                $input.val($span.hasClass('active'));
                $_this.closest('.itemThree').find('.itemzt').text(arr[Number($span.hasClass('active'))]);
                if($(this).data('name') == 'syx'){
                    $mainBox.find('#itemOther').toggleClass('hidden' , !$span.hasClass('active'));
                    setForm($span.hasClass('active'));
                }
            }
        },'.itemThree .dir').on({
            click : function(){
                var num = 0,
                    def = -1,
                    len = 0,
                    must = 0,
                    $input = null
                if($(this).hasClass('disabled')){
                    return;
                }
                if($('input[name=syx]').val() == 'true'){
                    $input = $('#itemOther select');
                    len = $input.length;
                    $input.each(function(index){
                        if(this.value == -1){
                            ++def;
                            Daze.showMsg(this.children[0].innerHTML);
                            return false;
                        }else if(this.value == 0){
                            ++num;
                        }else{
                            if($(this).attr('data-must') == 'true'){
                                ++must;
                            }
                        }
                    });
                    if(def === -1){
                        if(must === 0){
                            Daze.showMsg("车损险和三者险必投一项");
                            return;
                        }else{
                            goToInsure();
                        }
                    }
                }else{
                    DZ_COM.confirm({
                        title : "不投保商业险？",
                        content : "点击确定进行核保",
                        yesFn : function(){
                            goInsure();
                        },
                        noFn : function(){
                            $('div[data-name=syx]').find('.ghzt').trigger('click');
                        }
                    });
                }
            }
        },'#goToInsure').on({
            change : function(){
                var _select = $mainBox.find('select'),
                    num = 0,
                    len = _select.length,
                    bjmp = 0;
                if(this.value <= '0'){
                    var _for = $(this).attr('data-for'),
                        _input = $('input[name='+_for+']');
                        _input.val('false');
                }else{
                    var _for = $(this).attr('data-for'),
                        _input = $('input[name='+_for+']'),
                        _def = _input.attr('data-default'),
                        lens = $('#itembjmp .active').length;
                        if(lens ===1 && _def == 'true'){
                            _input.val('true');
                        }
                }
                _select.each(function(){
                    var __for = $(this).attr('data-for'),
                        __input = $('input[name='+__for+']'),
                        _def = __input.attr('data-default');
                    if(this.value > 0 && _def == 'true'){
                        ++num;
                    }
                });
                if(num === 0){
                    bjmp = $('#itembjmp .ghzt.active').length;
                    if(bjmp === 1){
                        $('#itembjmp .dir').trigger('click');
                    }
                }

            }
        },'select').on({
            click : function(){
                if($(this).attr('data-click') == 'false'){return;}
                Daze.system.addObserver({
                    name: 'daze_insureBrandEvent'
                });
                Daze.pushWindow({
                    appId : common.appId,
                    url : 'insureBrand.html'
                });
            }
        },'#changeBrand').on({
            click : function(){
                $mainBox.find('#insureReportList').addClass('hidden');
                $(this).closest('.content').removeAttr('style');
            }
        },'#goDown').on({
            click : function(){
                goInsure();
            }
        },'#goInsure').on({
            click : function(){
                var bjmp = $mainBox.find('#itembjmp .ghzt.active').length;
                $('#itemOther select').each(function(){
                    this.value = -1;
                });
                if(bjmp === 1){
                    $mainBox.find('#itembjmp .dir').trigger('click');
                }
            }
        },'#resetProject').on({
            click : function(){
                var num = 0,
                    $_this = $(this),
                    _itemzt = $_this.prev().find('.itemzt'),
                    $this = $_this.find('.ghzt'),
                    _act = $this.hasClass('active'),
                    $input = $_this.find('input');
                if(!_act){
                    $input.each(function(){
                        var _for = $(this).attr('data-for'),
                            _def = $(this).attr('data-default'),
                            _val = $('select[name='+_for+']').val();
                            if(_val > 0 && _def=='true'){
                                ++num;
                                $(this).val('true');
                            }
                    });
                    if(num > 0){
                        $this.addClass('active');
                        _itemzt.html($_this.attr('data-true'));
                    }
                }else{
                    $input.each(function(){
                        $(this).val('false');
                    });
                    $this.removeClass('active');
                    _itemzt.html($_this.attr('data-false'));
                }
            }
        },'#itembjmp .dir');
    }

    function goInsure(){
        var data = validate(),
            _data = common.getObj();
        if (!data) {
            return false;
        }
        data.baoxianCompanyName = _data.baoxianCompanyName;
        data.baseInfoId = _data.baoxianBaseInfoId;
        data.baoxianCompanyCode = _data.baoxianCompanyCode;
        if(common.getObj('reReport')){
            data.id = '';
        }else{
            data.id = common.getObj('id') || '';
        }
        data.userId = _data.uid;
        data.xubao = _data.xubao;
        _reportData = data; 
        console.log(data); 
        common.setObj('myReportDate',_reportData);
        $mainBox.find('#goToInsure').addClass('disabled').val('您有保单在核保中...');
        $mainBox.find('#insureReportList').addClass('hidden');
        Daze.system.addObserver({
            name: 'daze_reRepotEvent'
        });
        Daze.pushWindow({
            appId : common.appId,
            url : 'delivery.html'
        });
    }

    function renderHeader() {
        Daze.setTitle('投保方案');
    }

    function setinsureBrand(data) {
        document.removeEventListener('daze_insureBrandEvent', function(e) {
            setinsureBrand(e.data);
        });
        console.log(data);
        var $el = $mainBox.find('#changeBrand');
        $el.find('img').attr('src',data.baoxianCompanyPic);
        $el.find('.infos .body1').html(data.baoxianCompanyName);
        $el.find('.infos .caption').html(data.baoxianCompanyRemark);
    }

    function setForm(type){
        var $box = $mainBox.find('#itemOther'),
            $select = $box.find('select'),
            bjmp = $mainBox.find('#itembjmp .ghzt.active').length;
        if(type){
            $select.each(function(){
                $(this).val($(this).data('default'));
            });
            if(bjmp === 0){
                setTimeout(function(){
                    $mainBox.find('#itembjmp .dir').trigger('click');
                },10);
            }
        }else{
            $select.each(function(){
                $(this).val(0);
            });
            if(bjmp === 1){
                $mainBox.find('#itembjmp .dir').trigger('click');
            }
        }
    }

    function goToInsure(){
        var data = validate(),
            _data = common.getObj();
        if (!data) {
            return false;
        }
        data.baoxianCompanyName = _data.baoxianCompanyName;
        data.baseInfoId = _data.baoxianBaseInfoId;
        data.baoxianCompanyCode = _data.baoxianCompanyCode;
        data.id = common.getObj('id') || '';
        data.userId = _data.uid;
        $mainBox.find('#insureReportList').removeClass('hidden').html(template('insureReport', {
            data: data
        })).find('.content').css({
            height : (function(){
                var _H = $(window).height(),
                _h = $('#insureReportList .content').height();
                return _h > _H * 0.9 ? _H*0.9 : _h ;
            }()),
            marginTop : (function(){
                var _H = $(window).height(),
                _h = $('#insureReportList .content').height(),
                __h = _h > _H * 0.9 ? _H*0.9 : _h ;
                return -__h*0.5
            }()),
            top : (function(){
                var _H = $(window).height();
                return _H*0.5
            }())
        });
        data.xubao = _data.xubao;
        _reportData = data; 
        console.log(data);  
    }

    function getData() {
        var formData = tool.getFormDataAsObj($('form'));
        return formData;
    }

    function validate() {
        var data = getData(),
            valid = true;
        for (var i in data) {
            var value = data[i],
                $item = $('[name=' + i + ']'),
                require = $item.data('require'),
                nullMsg = $item.data('null'),
                errorMsg = $item.data('error'),
                ruleName = $item.data('rule') || '',
                rule = eval(ruleName);

            if (require) {
                if (!value) {
                    valid = false;
                    console.log(nullMsg);
                    Daze.showMsg(nullMsg);
                    break;
                } else if (ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            } else {
                if (value && ruleName && !rule.test(value)) {
                    valid = false;
                    console.log(errorMsg);
                    Daze.showMsg(errorMsg);
                    break;
                }
            }
        }
        return valid ? data : false;
    }

    function renderTempl() {
        //初始化写入
        $mainBox.html(template('insureTmpl', {
            data: _re
        }));
        setForm(true);
    }
});
