require([
    'lib/zepto.min',
    'com/host',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, host, storage, common) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    var $btn = $('#btn');

    function init() {
        // 数据统计
        countHandler();
        bindEvents();

        ga_storage._trackPageview('activity/1ForNJ', "活动-一元年检");
    }

    function bindEvents() {
        $btn.click(function () {
            // 设置当前服务为机动车年检
            storage.storeInfo('curServiceOfBMW', {
                id: 2,
                name: '机动车年检'
            });

            // 设置当前城市为苏州
            setCurCity();

            Daze.pushWindow({
                appId: '10000012',
                url: 'supplier-detail.html?id=96a8a012-c3b5-11e4-9491-d89d67271244'
            });

            ga_storage._trackEvent('活动-一元年检', '点击', '我要办年检');
        });
    }

    function setCurCity() {
        var curCity = {
            "id": 83,
            "name": "苏州",
            "province": "江苏"
        };
        storage.storeInfo('curCity', curCity);

        //传递城市信息到客户端
        Daze.system.postObserver({
            name: 'cityChange',
            eventData: curCity
        });
    }

    function countHandler() {
        $.ajax({
            url: host.HOST_URL + '/activity/addVisitCount.htm',
            type: 'post',
            data: common.convertParams({
                type: 31
            }),
            success: function (r) {
                if (r.code == 0) {
                    console.log(r.data && r.data.result);
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-一元年检', 'activity/addVisitCount.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-一元年检', 'activity/addVisitCount.htm', '失败');
            }
        });
    }
});