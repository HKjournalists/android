require([
    'lib/zepto.min',
    'com/GALocalStorage'
], function (a) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    var $showServiceDetail = $('#showServiceDetail');

    function init() {
        bindEvents();
        ga_storage._trackPageview('activity/rescue', "活动-办理车务送道路救援");
    }

    function bindEvents() {
        $showServiceDetail.click(function () {
            Daze.pushWindow({
                appId: '10000011',
                url: 'service-detail.html'
            });
        })
    }
});