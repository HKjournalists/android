require([
    'lib/zepto.min',
    'com/host',
    'com/storage',
    'com/common',
    'com/GALocalStorage'
], function (a, host, storage, common) {
    document.addEventListener("DazeJSObjReady", function () {
        console.log("DazeJSObjReady");
        init();
    }, false);

    var $shareToMoments = $('#shareToMoments');

    function init() {
        // 数据统计
        countHandler();
        bindEvents();

        ga_storage._trackPageview('activity/washing-car', "活动-免费办违章，再送1升油");
    }

    function bindEvents() {
        document.addEventListener('logoutEvent', function () {
            storage.removeInfo('pid');
        });

        $shareToMoments.click(function () {
            var uid = storage.getUid();
            if (uid) {
                shareHandler();
            }
            else {
                common.login(function () {
                    shareHandler();
                });
            }
            ga_storage._trackEvent('活动-免费办违章，再送1升油', '点击', '分享到朋友圈');
        });
    }

    function shareHandler() {
        Daze.share({
            from: 32,
            type: 32,
            to: '2'
        }, function (resp) {
            if (resp.isSuccess) {
                getUserInfo();
            }
        });
    }

    function getUserInfo() {
        $.ajax({
            url: host.HOST_URL + '/user/hasQualified.htm',
            type: 'post',
            data: common.convertParams({
                uid: storage.getUid(),
                type: 32
            }),
            success: function (r) {
                if (r.code == 0) {
                    var canShare = r.data && r.data.canShare;
                    if (!canShare) {
                        Daze.showMsg(r.data.msg);
                    }
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-免费办违章，再送1升油', 'user/hasQualified.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-免费办违章，再送1升油', 'user/hasQualified.htm', '失败');
            }
        });
    }

    function countHandler() {
        $.ajax({
            url: host.HOST_URL + '/activity/addVisitCount.htm',
            type: 'post',
            data: common.convertParams({
                type: 31
            }),
            success: function (r) {
                if (r.code == 0) {
                    console.log(r.data && r.data.result);
                }
                else {
                    Daze.showMsg(r.msg);
                }
                ga_storage._trackEvent('活动-免费办违章，再送1升油', 'activity/addVisitCount.htm', '成功');
            },
            error: function () {
                ga_storage._trackEvent('活动-免费办违章，再送1升油', 'activity/addVisitCount.htm', '失败');
            }
        });
    }
})
;